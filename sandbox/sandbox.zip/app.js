async function getFetchDatas(url) {
	const response = await fetch(encodeURI(url), {
	  method: "GET",
	  headers: {
		"Content-Type": "application/json",
	  },
	});
  
	return await response.json();
  }

go.onclick = async (e) => {
	e.preventDefault();
     const jsonObj = await getFetchDatas("http://localhost:8029/mario/v1.0/metrics?$query=versionFull");
	 resultat.value = JSON.stringify(jsonObj);
};