"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.serverConfig = void 0;
/**
 * Configuration class.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Configuration class. -----------------------------------!");
const constants_1 = require("../constants");
const helpers_1 = require("../helpers");
const messages_1 = require("../messages");
const helpers_2 = require("../db/helpers");
const __1 = require("..");
const enums_1 = require("../enums");
const fs_1 = __importDefault(require("fs"));
const util_1 = __importDefault(require("util"));
const update_json_1 = __importDefault(require("./update.json"));
const postgres_1 = __importDefault(require("postgres"));
const triggers_1 = require("../db/createDb/triggers");
const logger_1 = require("../logger");
const log_1 = require("../log");
const createDb_1 = require("../db/createDb");
const dataAccess_1 = require("../db/dataAccess");
// class to logCreate configs environements
class Configuration {
    static configs = {};
    static filePath;
    static jsonConfiguration;
    static ports = [];
    static queries = {};
    constructor() {
        process.stdout.write(`${(0, constants_1.color)(31 /* EColor.FgRed */)} ${"=".repeat(24)} ${(0, constants_1.color)(36 /* EColor.FgCyan */)} ${`START ${constants_1.APP_NAME} version : ${constants_1.APP_VERSION} [${constants_1.NODE_ENV}]`} ${(0, constants_1.color)(37 /* EColor.FgWhite */)} ${new Date().toLocaleDateString()} : ${new Date().toLocaleTimeString()} ${(0, constants_1.color)(31 /* EColor.FgRed */)} ${"=".repeat(24)}${(0, constants_1.color)(0 /* EColor.Reset */)}\n`);
        const file = __dirname + `/configuration.json`;
        Configuration.filePath = file.toString();
        if ((0, helpers_1.isTest)())
            this.readConfigFile();
    }
    // Read string (or default configuration file) as configuration file
    readConfigFile(input) {
        log_1.log.booting("Read config", input ? "content" : Configuration.filePath);
        try {
            // load File
            const fileContent = input || fs_1.default.readFileSync(Configuration.filePath, "utf8");
            // decrypt file
            Configuration.jsonConfiguration = JSON.parse((0, helpers_1.decrypt)(fileContent));
            if (this.validJSONConfig(Configuration.jsonConfiguration)) {
                if ((0, helpers_1.isTest)()) {
                    Configuration.configs[constants_1.ADMIN] = this.formatConfig(constants_1.ADMIN);
                }
                else {
                    Object.keys(Configuration.jsonConfiguration).forEach((element) => {
                        Configuration.configs[element] = this.formatConfig(element);
                    });
                }
                Configuration.configs[constants_1.TEST] = this.createConfigFileTest();
            }
            else {
                log_1.log.error(messages_1.errors.configFileError);
                process.exit(112);
            }
            // rewrite file (to update config modification except in test mode)
            if (!(0, helpers_1.isTest)())
                this.writeConfig();
        }
        catch (error) {
            log_1.log.error("Config is not correct", error["message"]);
            process.exit(111);
        }
    }
    // verify if configuration file Exist
    configFileExist() {
        return fs_1.default.existsSync(Configuration.filePath);
    }
    // create config tests entry
    createConfigFileTest() {
        return this.formatConfig({ name: "test",
            port: Configuration.configs[constants_1.ADMIN].port,
            "pg": {
                "host": Configuration.configs[constants_1.ADMIN].pg.host,
                "port": Configuration.configs[constants_1.ADMIN].pg.port,
                "user": "stean",
                "password": "stean",
                "database": "test",
                "retry": 2
            },
            "apiVersion": enums_1.EVersion.v1_1,
            "nb_page": 1000,
            "extensions": [enums_1.EExtensions.base, enums_1.EExtensions.multiDatastream, enums_1.EExtensions.lora, enums_1.EExtensions.logs, enums_1.EExtensions.users],
            "options": [enums_1.EOptions.canDrop]
        });
    }
    // return infos routes
    getInfos = (ctx, name) => {
        const protocol = ctx.request.headers["x-forwarded-proto"]
            ? ctx.request.headers["x-forwarded-proto"].toString()
            : Configuration.configs[name].options.includes(enums_1.EOptions.forceHttps)
                ? "https"
                : ctx.protocol;
        // make linkbase
        let linkBase = ctx.request.headers["x-forwarded-host"]
            ? `${protocol}://${ctx.request.headers["x-forwarded-host"].toString()}`
            : ctx.request.header.host
                ? `${protocol}://${ctx.request.header.host}`
                : "";
        // make rootName
        if (!linkBase.includes(name))
            linkBase += "/" + name;
        const version = Configuration.configs[name].apiVersion;
        return {
            protocol: protocol,
            linkBase: linkBase,
            version: version,
            root: process.env.NODE_ENV?.trim() === "test" ? `proxy/${version}` : `${linkBase}/${version}`,
            model: `https://app.diagrams.net/?lightbox=1&edit=_blank#U${linkBase}/${version}/draw`
        };
    };
    // return infos routes for all services
    getInfosForAll(ctx) {
        const result = {};
        this.getConfigs().forEach((conf) => {
            result[conf] = this.getInfos(ctx, conf);
        });
        return result;
    }
    isConfig(name) {
        return Configuration.configs.hasOwnProperty(name);
    }
    getConfig(name) {
        return Configuration.configs[name];
    }
    getConfigs() {
        return Object.keys(Configuration.configs).filter(e => e !== constants_1.ADMIN);
    }
    // verify is valid config
    validJSONConfig(input) {
        if (!input.hasOwnProperty(constants_1.ADMIN))
            return false;
        if (!input[constants_1.ADMIN].hasOwnProperty("pg"))
            return false;
        const admin = input[constants_1.ADMIN]["pg"];
        if (!admin.hasOwnProperty("host"))
            return false;
        if (!admin.hasOwnProperty("user"))
            return false;
        if (!admin.hasOwnProperty("password"))
            return false;
        if (!admin.hasOwnProperty("database"))
            return false;
        return true;
    }
    // Write an encrypt config file in json file
    writeConfig() {
        log_1.log.booting("Write config", Configuration.filePath);
        const result = {};
        Object.entries(Configuration.configs).forEach(([k, v]) => {
            if (k !== constants_1.TEST)
                result[k] = Object.keys(v).reduce((obj, key) => { obj[key] = v[key]; return obj; }, {});
        });
        fs_1.default.writeFile(
        // encrypt only in production mode
        Configuration.filePath, (0, helpers_1.isProduction)() === true
            ? (0, helpers_1.encrypt)(JSON.stringify(result, null, 4))
            : JSON.stringify(result, null, 4), (err) => {
            if (err) {
                log_1.log.error(logger_1.formatLog.error(err));
                return false;
            }
        });
        return true;
    }
    async executeMultipleQueries(configName, queries, infos) {
        await (0, helpers_1.asyncForEach)(queries, async (query) => {
            await exports.serverConfig
                .connection(configName)
                .unsafe(query)
                .catch((error) => {
                log_1.log.error(logger_1.formatLog.error(error));
                return false;
            });
        });
        log_1.log.create(`${infos} : [${configName}]`, constants_1._OK);
        return true;
    }
    async executeQueries(title) {
        try {
            await (0, helpers_1.asyncForEach)(Object.keys(Configuration.queries), async (connectName) => {
                await this.executeMultipleQueries(connectName, Configuration.queries[connectName], title);
            });
        }
        catch (error) {
            log_1.log.error(error);
        }
        return true;
    }
    hashCode(s) {
        return s.split("").reduce((a, b) => {
            a = (a << 5) - a + b.charCodeAt(0);
            return a & a;
        }, 0);
    }
    // return the connection
    connection(name) {
        if (!Configuration.configs[name].connection)
            this.createDbConnectionFromConfigName(name);
        return Configuration.configs[name].connection || this.createDbConnection(Configuration.configs[name].pg);
    }
    // return postgres.js connection with ADMIN rights
    adminConnection() {
        const input = Configuration.configs[constants_1.ADMIN].pg;
        return (0, postgres_1.default)(`postgres://${input.user}:${input.password}@${input.host}:${input.port || 5432}/${constants_1.DEFAULT_DB}`, {
            debug: constants_1._DEBUG,
            connection: {
                application_name: `${constants_1.APP_NAME} ${constants_1.APP_VERSION}`
            }
        });
    }
    // return postgres.js connection from Connection
    createDbConnection(input) {
        return (0, postgres_1.default)(`postgres://${input.user}:${input.password}@${input.host}:${input.port || 5432}/${input.database}`, {
            debug: constants_1._DEBUG,
            max: 2000,
            connection: {
                application_name: `${constants_1.APP_NAME} ${constants_1.APP_VERSION}`
            },
        });
    }
    createDbConnectionFromConfigName(input) {
        const temp = this.createDbConnection(Configuration.configs[input].pg);
        Configuration.configs[input].connection = temp;
        return temp;
    }
    addToQueries(connectName, query) {
        (0, constants_1.addToStrings)(Configuration.queries[connectName], query);
    }
    clearQueries() {
        Configuration.queries = {};
    }
    async relogCreateTrigger(configName) {
        await (0, helpers_1.asyncForEach)((0, triggers_1.triggers)(configName), async (query) => {
            const name = query.split(" */")[0].split("/*")[1].trim();
            await exports.serverConfig.connection(configName).unsafe(query).then(() => {
                log_1.log.create(`[${configName}] ${name}`, constants_1._OK);
            }).catch((error) => {
                log_1.log.error(error);
                return false;
            });
        });
        return true;
    }
    // initialisation serve NOT IN TEST
    async afterAll() {
        // Updates database after init
        if (update_json_1.default && update_json_1.default[enums_1.EUpdate.afterAll] && Object.entries(update_json_1.default[enums_1.EUpdate.afterAll]).length > 0) {
            this.clearQueries();
            Object.keys(Configuration.configs)
                .filter((e) => e != constants_1.ADMIN)
                .forEach(async (connectName) => {
                update_json_1.default[enums_1.EUpdate.afterAll].forEach((operation) => { this.addToQueries(connectName, operation); });
            });
            await this.executeQueries(enums_1.EUpdate.afterAll);
        }
        if (update_json_1.default && update_json_1.default[enums_1.EUpdate.decoders] && Object.entries(update_json_1.default[enums_1.EUpdate.decoders]).length > 0) {
            this.clearQueries();
            Object.keys(Configuration.configs)
                .filter((e) => e != constants_1.ADMIN && Configuration.configs[e].extensions.includes(enums_1.EExtensions.lora))
                .forEach((connectName) => {
                Object.keys(update_json_1.default[enums_1.EUpdate.decoders]).forEach((name) => {
                    const hash = this.hashCode(update_json_1.default[enums_1.EUpdate.decoders][name]);
                    this.addToQueries(connectName, `UPDATE decoder SET code='${update_json_1.default[enums_1.EUpdate.decoders][name]}', hash = '${hash}' WHERE name = '${name}' AND hash <> '${hash}' `);
                });
            });
        }
        await this.executeQueries(enums_1.EUpdate.decoders);
        return true;
    }
    // initialisation serve NOT IN TEST
    async init(input) {
        if (this.configFileExist() === true || input) {
            this.readConfigFile(input);
            console.log(log_1.log.message(messages_1.infos.configuration, messages_1.infos.loaded + constants_1._OK));
            let status = true;
            const errFile = fs_1.default.createWriteStream(constants_1._ERRORFILE, { flags: "w" });
            log_1.log.booting(messages_1.infos.logFile, constants_1._ERRORFILE);
            errFile.write(`## Start : ${(0, constants_1.TIMESTAMP)()} \n`);
            await (0, helpers_1.asyncForEach)(
            // Start connection ALL entries in config file
            Object.keys(Configuration.configs).filter(e => e.toUpperCase() !== constants_1.TEST.toUpperCase()), async (key) => {
                try {
                    await this.addToServer(key);
                }
                catch (error) {
                    log_1.log.error(error);
                    status = false;
                }
            });
            (0, constants_1.setReady)(status);
            if (status === true) {
                this.afterAll();
            }
            console.log(log_1.log.message(`${constants_1.APP_NAME} version : ${constants_1.APP_VERSION}`, `ready ${(status === true) ? constants_1._OK : constants_1._NOTOK}`));
            return status;
            // no configuration file so First install    
        }
        else {
            console.log(log_1.log.message("file", Configuration.filePath + constants_1._NOTOK));
            const port = 8029;
            if (!Configuration.ports.includes(port))
                __1.app.listen(port, () => {
                    Configuration.ports.push(port);
                    log_1.log.booting(`${(0, constants_1.color)(33 /* EColor.FgYellow */)}First launch]${(0, constants_1.color)(32 /* EColor.FgGreen */)}${messages_1.infos.ListenPort}`, port);
                });
            return true;
        }
    }
    // return config name from config name
    getConfigNameFromDatabase(input) {
        if (input !== "all") {
            const aliasName = Object.keys(Configuration.configs).filter((configName) => Configuration.configs[configName].pg.database === input)[0];
            if (aliasName)
                return aliasName;
            throw new Error(`No configuration found for ${input} name`);
        }
    }
    getConfigForExcelExport = (name) => {
        const result = Object.assign({}, Configuration.configs[name].pg);
        result["password"] = "*****";
        ["name", "apiVersion", "port", "date_format", "webSite", "nb_page", "forceHttps", "highPrecision", "canDrop", "logFile", "alias", "extensions"].forEach(e => {
            result[e] = Configuration.configs[name][e];
        });
        return result;
    };
    getConfigNameFromName = (name) => {
        if (name) {
            if (Object.keys(Configuration.configs).includes(name))
                return name;
            Object.keys(Configuration.configs).forEach((configName) => {
                if (Configuration.configs[configName].alias.includes(name))
                    return configName;
            });
        }
    };
    getModelVersion = (name) => {
        switch (name) {
            case "v1.1":
            case "1.1":
                return enums_1.EVersion.v1_1;
            default:
                return enums_1.EVersion.v1_0;
        }
    };
    // return IconfigFile Formated for IconfigFile object or name found in json file
    formatConfig(input, name) {
        if (typeof input === "string") {
            name = input;
            input = Configuration.jsonConfiguration[input];
        }
        const options = input["options"]
            ? (0, helpers_1.unique)([...String(input["options"]).split(",")])
            : [];
        const extensions = input["extensions"]
            ? (0, helpers_1.unique)(["base", ...String(input["extensions"]).split(",")])
            : ["base"];
        if (input["extensions"]["users"])
            extensions.includes("users");
        // TO REMOVE AFTER ALL SERVICES CLEAN
        // const formatOldConfig = () => {
        //   if (stringToBoolean(input["stripNull"])) {
        //     options.push(EOptions.stripNull)
        //     delete input["stripNull" as keyobj]
        //   }
        //   if (stringToBoolean(input["canDrop"])) {
        //     options.push(EOptions.canDrop)
        //     delete input["canDrop" as keyobj]
        //   }
        //   if (stringToBoolean(input["forceHttps"])) {
        //     options.push(EOptions.forceHttps)
        //     delete input["forceHttps" as keyobj]
        //   }
        // }
        // formatOldConfig();
        const goodDbName = name
            ? name
            : input["pg"] && input["pg"]["database"] ? input["pg"]["database"] : `ERROR` || "ERROR";
        const version = goodDbName === constants_1.ADMIN ? enums_1.EVersion.v1_1 : String(input["apiVersion"]).trim();
        const returnValue = {
            name: goodDbName,
            port: goodDbName === constants_1.ADMIN
                ? input["port"] || 8029
                : input["port"] || Configuration.configs[constants_1.ADMIN].port || 8029,
            pg: {
                host: input["pg"] && input["pg"]["host"] ? String(input["pg"]["host"]) : `ERROR`,
                port: input["pg"] && input["pg"]["port"] ? input["pg"]["port"] : 5432,
                user: input["pg"] && input["pg"]["user"] ? input["pg"]["user"] : `ERROR`,
                password: input["pg"] && input["pg"]["password"] ? input["pg"]["password"] : `ERROR`,
                database: name && name === "test" ? "test" : input["pg"] && input["pg"]["database"] ? input["pg"]["database"] : `ERROR`,
                retry: input["retry"] ? +input["retry"] : 2,
            },
            apiVersion: this.getModelVersion(version),
            date_format: input["date_format"] || "DD/MM/YYYY hh:mi:ss",
            webSite: input["webSite"] || "no web site",
            nb_page: input["nb_page"] ? +input["nb_page"] : 200,
            alias: input["alias"] ? (0, helpers_1.unikeList)(String(input["alias"]).split(",")) : [],
            extensions: extensions,
            options: options,
            connection: undefined,
        };
        if (Object.values(returnValue).includes("ERROR"))
            throw new TypeError(`${messages_1.errors.inConfigFile} [${util_1.default.inspect(returnValue, {
                showHidden: false,
                depth: null,
            })}]`);
        return returnValue;
    }
    // Add config to configuration file
    async addConfig(addJson) {
        try {
            const addedConfig = this.formatConfig(addJson);
            Configuration.jsonConfiguration[addedConfig.name] = addedConfig;
            if (!(0, helpers_1.isTest)()) {
                await this.addToServer(addedConfig.name);
                this.writeConfig();
            }
            (0, helpers_1.hidePassword)(addedConfig);
            return addedConfig;
        }
        catch (error) {
            return undefined;
        }
    }
    // process to add an entry in server
    async addToServer(key) {
        return await this.isDbExist(key, true)
            .then(async (res) => {
            if (res === true) {
                await dataAccess_1.userAccess.post(key, {
                    username: Configuration.configs[key].pg.user,
                    email: "steandefault@email.com",
                    password: Configuration.configs[key].pg.password,
                    database: Configuration.configs[key].pg.database,
                    canPost: true,
                    canDelete: true,
                    canCreateUser: true,
                    canCreateDb: true,
                    superAdmin: false,
                    admin: false
                });
                if (![constants_1.ADMIN, constants_1.TEST].includes(key))
                    (0, helpers_2.createIndexes)(key);
                log_1.log.booting(`${(0, constants_1.color)(35 /* EColor.FgMagenta */)}Database => ${(0, constants_1.color)(33 /* EColor.FgYellow */)}[${key}] ${(0, constants_1.color)(39 /* EColor.FgFadeWhite */)} on line`, res ? constants_1._WEB : constants_1._NOTOK);
                const port = Configuration.configs[key].port;
                if (port > 0) {
                    if (Configuration.ports.includes(port))
                        log_1.log.booting(`${(0, constants_1.color)(35 /* EColor.FgMagenta */)}[${key}] ${(0, constants_1.color)(32 /* EColor.FgGreen */)}${messages_1.infos.addPort}`, port);
                    else
                        __1.app.listen(port, () => {
                            Configuration.ports.push(port);
                            log_1.log.booting(`${(0, constants_1.color)(33 /* EColor.FgYellow */)}[${key}] ${(0, constants_1.color)(32 /* EColor.FgGreen */)}${messages_1.infos.ListenPort}`, port);
                        });
                }
            }
            return res;
        })
            .catch((error) => {
            log_1.log.error(messages_1.errors.unableFindCreate, Configuration.configs[key].pg.database);
            log_1.log.error(error);
            process.exit(111);
        });
    }
    // test in boolean exist if not and logCreate is true then logCreate DB
    async tryToCreateDB(connectName) {
        log_1.log.booting("Try create Database", Configuration.configs[connectName].pg.database);
        return await (0, createDb_1.createDatabase)(connectName)
            .then(async () => {
            log_1.log.booting(`${messages_1.infos.db} ${messages_1.infos.create} [${Configuration.configs[connectName].pg.database}]`, constants_1._OK);
            this.createDbConnectionFromConfigName(connectName);
            return true;
        })
            .catch((err) => {
            ;
            log_1.log.error((0, messages_1.msg)(messages_1.infos.create, messages_1.infos.db), err.message);
            return false;
        });
    }
    // verify if database exist and if create is true create database if not exist.
    async isDbExist(connectName, create) {
        log_1.log.booting(messages_1.infos.dbExist, Configuration.configs[connectName].pg.database);
        return await this.connection(connectName) `select 1+1 AS result`.then(async () => {
            const listTempTables = await this.connection(connectName) `SELECT array_agg(table_name) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE 'temp%';`;
            const tables = listTempTables[0]["array_agg"];
            if (tables != null)
                log_1.log.booting(`DELETE temp table(s) ==> \x1b[33m${connectName}\x1b[32m`, await this.connection(connectName).begin(sql => {
                    tables.forEach(async (table) => {
                        await sql.unsafe(`DROP TABLE ${table}`);
                    });
                }).then(() => constants_1._OK)
                    .catch((err) => err.message));
            if (update_json_1.default[enums_1.EUpdate.triggers] && update_json_1.default[enums_1.EUpdate.triggers] === true && connectName !== constants_1.ADMIN)
                await this.relogCreateTrigger(connectName);
            if (update_json_1.default[enums_1.EUpdate.beforeAll] && Object.entries(update_json_1.default[enums_1.EUpdate.beforeAll]).length > 0) {
                if (update_json_1.default[enums_1.EUpdate.beforeAll] && Object.entries(update_json_1.default[enums_1.EUpdate.beforeAll]).length > 0) {
                    console.log(logger_1.formatLog.head(enums_1.EUpdate.beforeAll));
                    try {
                        Object.keys(Configuration.configs)
                            .filter((e) => e != constants_1.ADMIN)
                            .forEach((connectName) => {
                            update_json_1.default[enums_1.EUpdate.beforeAll].forEach((operation) => {
                                this.addToQueries(connectName, operation);
                            });
                        });
                        await this.executeQueries(enums_1.EUpdate.beforeAll);
                        // RelogCreate triggers for this service
                    }
                    catch (error) {
                        log_1.log.error(logger_1.formatLog.error(error));
                    }
                }
            }
            return true;
        })
            .catch(async (err) => {
            let returnResult = false;
            // Password authentication failed 
            if (err["code"] === "28P01") {
                if (!(0, helpers_1.isTest)()) {
                    if (connectName === constants_1.TEST)
                        await (0, helpers_2.createService)(createDb_1.testDatas);
                    else
                        await this.tryToCreateDB(connectName);
                }
                //database does not exist
            }
            else if (err["code"] === "3D000" && create == true) {
                console.log(logger_1.formatLog.debug((0, messages_1.msg)(messages_1.infos.tryCreate, messages_1.infos.db), Configuration.configs[connectName].pg.database));
                // If not in tdd tests create test DB for documentation
                if (!(0, helpers_1.isTest)()) {
                    if (connectName === constants_1.TEST)
                        await (0, helpers_2.createService)(createDb_1.testDatas);
                    else
                        await this.tryToCreateDB(connectName);
                }
            }
            else
                log_1.log.error(logger_1.formatLog.error(err));
            return returnResult;
        });
    }
}
exports.serverConfig = new Configuration();
