"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.asDataArray = void 0;
/**
 * asDataArray.
 *
 * @copyright 2020-present Inrae
 * @review 27-01-2024
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- asDataArray. -----------------------------------!");
const _1 = require(".");
const constants_1 = require("../../constants");
const helpers_1 = require("../../helpers");
const asDataArray = (input) => {
    const names = input.toPgQuery()?.keys.map((e) => (0, helpers_1.removeAllQuotes)(e)) || [];
    // create names
    if (input.includes)
        input.includes.forEach((include) => { names.push(include.entity); });
    // Return SQL query  
    return (0, _1.asJson)({
        query: `SELECT (ARRAY[${constants_1._NEWLINE}\t${names
            .map((e) => (0, helpers_1.addSimpleQuotes)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(e)))
            .join(`,${constants_1._NEWLINE}\t`)}]) AS "component", count(*) AS "dataArray@iot.count", jsonb_agg(allkeys) AS "dataArray" FROM (SELECT json_build_array(${constants_1._NEWLINE}\t${names.map((e) => (0, helpers_1.addDoubleQuotes)(e)).join(`,${constants_1._NEWLINE}\t`)}) AS allkeys \n\tFROM (${input.toString()}) AS p) AS l`,
        singular: false,
        strip: false,
        count: false,
    });
};
exports.asDataArray = asDataArray;
