"use strict";
/**
 * multiDatastreamKeys.
*
* @copyright 2020-present Inrae
* @author mario.adam@inrae.fr
*
*/
Object.defineProperty(exports, "__esModule", { value: true });
exports.multiDatastreamKeys = void 0;
const multiDatastreamKeys = (inputID) => `SELECT 
    jsonb_agg(tmp.units -> 'name') AS keys 
FROM 
    (
        SELECT 
            jsonb_array_elements("unitOfMeasurements") AS units 
        FROM 
            "multidatastream" 
        WHERE 
            id = ${inputID}
    ) AS tmp`;
exports.multiDatastreamKeys = multiDatastreamKeys;
