"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.interval = void 0;
const interval = (input) => input.interval
    ?
        `WITH src as (${input.toString()}), 
range_values AS (
    SELECT 
        min(srcdate) as minval, 
        max(srcdate) as maxval 
    FROM 
        src
), 
time_range AS (
    SELECT 
        generate_series( minval :: timestamp, maxval :: timestamp, '${input.interval || "1 day"}' :: interval ):: TIMESTAMP WITHOUT TIME ZONE as step 
    FROM 
        range_values
) 
SELECT 
    ${input.intervalColumns ? input.intervalColumns.join(", ") : ''} 
FROM 
    src RIGHT JOIN time_range on srcdate = step`
    : input.toString();
exports.interval = interval;
