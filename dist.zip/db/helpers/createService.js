"use strict";
/**
 * createService
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- createService -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.createService = void 0;
const _1 = require(".");
const configuration_1 = require("../../configuration");
const helpers_1 = require("../../helpers");
const models_1 = require("../../models");
const helpers_2 = require("../../models/helpers");
const helper_1 = require("../../routes/helper");
const log_1 = require("../../log");
const prepareDatas = (dataInput, entity) => {
    if (entity === "Observations") {
        if (!dataInput["resultTime"] && dataInput["phenomenonTime"])
            dataInput["resultTime"] = dataInput["phenomenonTime"];
        if (!dataInput["phenomenonTime"] && dataInput["resultTime"])
            dataInput["phenomenonTime"] = dataInput["resultTime"];
    }
    return dataInput;
};
const getConvertedData = async (url) => {
    return fetch(url, { method: 'GET', headers: {}, }).then((response) => response.json());
};
const addToServiceFromUrl = async (url, ctx) => {
    while (url) {
        try {
            const datas = await getConvertedData(url);
            await (0, _1.addToService)(ctx, datas);
            return datas["@iot.nextLink"];
        }
        catch (error) {
            console.log(error);
            return "";
        }
    }
    return "";
};
const createService = async (dataInput, ctx) => {
    console.log(log_1.log.whereIam());
    if (dataInput && dataInput["create"]) {
        configuration_1.serverConfig.addConfig(dataInput["create"]);
    }
    const results = {};
    const serviceName = dataInput["create"]["name"];
    const config = configuration_1.serverConfig.getConfig(serviceName);
    const mess = `Database [${serviceName}]`;
    const createDB = async () => {
        try {
            await (0, _1.createDatabase)(serviceName);
            results[`Create ${mess}`] = "\u2714\uFE0F\uFE0F" /* EChar.ok */;
        }
        catch (error) {
            results[`Create ${mess}`] = "\u274C" /* EChar.notOk */;
            console.log(error);
        }
    };
    await (0, _1.executeAdmin)((0, helper_1.sqlStopDbName)((0, helpers_1.addSimpleQuotes)(serviceName))).then(async () => {
        await (0, _1.executeAdmin)(`DROP DATABASE IF EXISTS ${serviceName}`).then(async () => {
            results[`Drop ${mess}`] = "\u2714\uFE0F\uFE0F" /* EChar.ok */;
            await createDB();
        }).catch((error) => {
            results[`Drop ${mess}`] = "\u274C" /* EChar.notOk */;
            log_1.log.error(error);
        });
    }).catch(async (err) => {
        if (err["code"] === "3D000") {
            await createDB();
        }
    });
    const tmp = models_1.models.filteredModelFromConfig(config);
    await (0, helpers_1.asyncForEach)(Object.keys(tmp).filter((elem) => tmp[elem].createOrder > 0).sort((a, b) => (tmp[a].createOrder > tmp[b].createOrder ? 1 : -1)), async (entityName) => {
        if (dataInput[entityName]) {
            const goodEntity = models_1.models.getEntity(config, entityName);
            if (goodEntity) {
                try {
                    const sqls = dataInput[entityName].map((element) => `INSERT INTO ${(0, helpers_1.addDoubleQuotes)(goodEntity.table)} ${(0, helpers_2.createInsertValues)(config, prepareDatas(element, goodEntity.name), goodEntity.name)}`);
                    await (0, _1.executeSqlValues)(configuration_1.serverConfig.getConfig(serviceName), sqls.join(";")).then((res) => {
                        results[entityName] = "\u2714\uFE0F\uFE0F" /* EChar.ok */;
                    }).catch((error) => {
                        log_1.log.errorMsg(error);
                        results[entityName] = "\u274C" /* EChar.notOk */;
                    });
                }
                catch (error) {
                    log_1.log.errorMsg(error);
                    results[entityName] = "\u274C" /* EChar.notOk */;
                }
            }
        }
    });
    if (ctx && dataInput["create"]["imports"]) {
        await (0, helpers_1.asyncForEach)(dataInput["create"]["imports"], async (url) => {
            url = `${url}&$top=1000`;
            while (url + "") {
                url = await addToServiceFromUrl(url, ctx);
            }
        });
    }
    return results;
};
exports.createService = createService;
