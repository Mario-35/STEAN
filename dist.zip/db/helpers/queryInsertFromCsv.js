"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.queryInsertFromCsv = void 0;
/**
 * queryInsertFromCsv.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- queryInsertFromCsv. -----------------------------------!");
const logger_1 = require("../../logger");
const _1 = require(".");
const constants_1 = require("../../constants");
async function queryInsertFromCsv(ctx, paramsFile) {
    console.log(logger_1.formatLog.whereIam());
    const sqlRequest = await (0, _1.columnsNameFromHydrasCsv)(paramsFile);
    if (sqlRequest) {
        const stream = await (0, _1.streamCsvFile)(ctx, paramsFile, sqlRequest);
        console.log(logger_1.formatLog.debug(`COPY TO ${paramsFile.tempTable}`, stream > 0 ? constants_1._OK : constants_1._NOTOK));
        if (stream > 0) {
            const fileImport = paramsFile.filename.split("/").reverse()[0];
            const dateImport = new Date().toLocaleString();
            // stream finshed so COPY
            const scriptSql = [];
            // make import query
            Object.keys(paramsFile.columns).forEach((myColumn, index) => {
                const csvColumn = paramsFile.columns[myColumn];
                scriptSql.push(`INSERT INTO "${ctx.model.Observations.table}" 
          ("${csvColumn.stream.type?.toLowerCase()}_id", "featureofinterest_id", "phenomenonTime", "resultTime", "result", "resultQuality")
            SELECT 
            ${csvColumn.stream.id}, 
            ${csvColumn.stream.FoId},  
            ${sqlRequest.dateSql}, 
            ${sqlRequest.dateSql},
            json_build_object('value', 
            CASE "${paramsFile.tempTable}".value${csvColumn.column}
              WHEN '---' THEN NULL 
              ELSE CAST(REPLACE(value${csvColumn.column},',','.') AS float) 
            END),
            '{"import": "${fileImport}","date": "${dateImport}"}'  
           FROM "${paramsFile.tempTable}" ON CONFLICT DO NOTHING returning 1`);
            });
            return {
                count: stream,
                query: scriptSql
            };
        }
    }
}
exports.queryInsertFromCsv = queryInsertFromCsv;
;
