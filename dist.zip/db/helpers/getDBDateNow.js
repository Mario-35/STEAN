"use strict";
/**
 * getDBDateNow
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- getDBDateNow -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDBDateNow = void 0;
const _1 = require(".");
const getDBDateNow = async (config) => await (0, _1.executeSqlValues)(config, "SELECT current_timestamp;").then((res) => res[0]);
exports.getDBDateNow = getDBDateNow;
