"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createIndexes = void 0;
const configuration_1 = require("../../configuration");
const constants_1 = require("../../constants");
const helpers_1 = require("../../helpers");
const log_1 = require("../../log");
const logger_1 = require("../../logger");
const exe = async (name, queries) => {
    await (0, helpers_1.asyncForEach)(queries, async (query) => {
        await configuration_1.serverConfig
            .connection(name)
            .unsafe(query)
            .catch((error) => {
            log_1.log.error(logger_1.formatLog.error(error));
            return false;
        });
    });
    log_1.log.create(`Indexes : [${name}]`, constants_1._OK);
    return true;
};
const createIndexes = (name) => {
    const sqls = [`WITH datastreams AS (
        select distinct "datastream_id" AS id from observation
        ),
        datas AS (
            SELECT 
                "datastream_id" AS id,
                min("phenomenonTime") AS pmin ,
                max("phenomenonTime") AS pmax,
                min("resultTime") AS rmin,
                max("resultTime") AS rmax
            FROM observation, datastreams where  "datastream_id" = datastreams.id group by "datastream_id"
        )
        UPDATE "datastream" SET 
            "_phenomenonTimeStart" =  datas.pmin ,
            "_phenomenonTimeEnd" = datas.pmax,
            "_resultTimeStart" = datas.rmin,
            "_resultTimeEnd" = datas.rmax
        FROM datas where "datastream".id = datas.id`,
        `WITH multidatastreams AS (
            select distinct "multidatastream_id" AS id from observation
        ),
        datas AS (
            SELECT 
                "multidatastream_id" AS id,
                min("phenomenonTime") AS pmin ,
                max("phenomenonTime") AS pmax,
                min("resultTime") AS rmin,
                max("resultTime") AS rmax
            FROM observation, multidatastreams where "multidatastream_id" = multidatastreams.id group by "multidatastream_id"
        )
        UPDATE "multidatastream" SET 
            "_phenomenonTimeStart" =  datas.pmin ,
            "_phenomenonTimeEnd" = datas.pmax,
            "_resultTimeStart" = datas.rmin,
            "_resultTimeEnd" = datas.rmax
        FROM datas where "multidatastream".id = datas.id
        `
    ];
    exe(name, sqls);
};
exports.createIndexes = createIndexes;
