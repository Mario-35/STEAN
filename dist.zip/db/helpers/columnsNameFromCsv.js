"use strict";
/**
 * columnsNameFromCsv
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- columnsNameFromCsv -----------------------------------!");
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.columnsNameFromCsv = void 0;
const fs_1 = __importDefault(require("fs"));
const readline_1 = __importDefault(require("readline"));
const log_1 = require("../../log");
const columnsNameFromCsv = async (filename) => {
    console.log(log_1.log.whereIam());
    const fileStream = fs_1.default.createReadStream(filename);
    const rl = readline_1.default.createInterface({
        input: fileStream,
        crlfDelay: Infinity,
    });
    // Note: we use the crlfDelay option to recognize all instances of CR LF
    // ('\r\n') in filename as a single line break.
    for await (const line of rl) {
        try {
            const cols = line
                .split(";")
                .map((e) => e.replace(/\./g, "").toLowerCase());
            fileStream.destroy();
            return cols;
        }
        catch (error) {
            log_1.log.errorMsg(error);
        }
    }
};
exports.columnsNameFromCsv = columnsNameFromCsv;
