"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateFields = void 0;
/**
 * addToService
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
console.log("!----------------------------------- addToService -----------------------------------!");
const helpers_1 = require("../../helpers");
const generateFields = (input) => {
    let fields = [];
    if ((0, helpers_1.isGraph)(input)) {
        const table = input.ctx.model[input.parentEntity ? input.parentEntity : input.entity].table;
        fields = [
            `(SELECT ${table}."description" FROM ${table} WHERE ${table}."id" = ${input.parentId ? input.parentId : input.id}) AS title, `,
        ];
    }
    return fields;
};
exports.generateFields = generateFields;
