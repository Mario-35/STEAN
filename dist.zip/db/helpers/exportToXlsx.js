"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.exportToXlsx = void 0;
/**
 * exportToXlsx.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- exportToXlsx. -----------------------------------!");
const exceljs_1 = __importDefault(require("exceljs"));
const configuration_1 = require("../../configuration");
const log_1 = require("../../log");
const helpers_1 = require("../../helpers");
const models_1 = require("../../models");
const enums_1 = require("../../enums");
const addConfigToExcel = async (workbook, config) => {
    const worksheet = workbook.addWorksheet("Config");
    const cols = [
        { key: "key", header: "key" },
        { key: "value", header: "value" }
    ];
    worksheet.columns = cols;
    worksheet.columns.forEach((sheetColumn) => {
        sheetColumn.font = {
            size: 12,
        };
        sheetColumn.width = 30;
    });
    worksheet.getRow(1).font = {
        bold: true,
        size: 13,
    };
    Object.keys(config).forEach((item) => {
        worksheet.addRow({ key: item, value: typeof config[item] === "object" ? Array(config[item]).toString() : config[item] });
    });
};
const addToExcel = async (workbook, name, input) => {
    if (input && input[0]) {
        const worksheet = workbook.addWorksheet(name);
        const cols = [];
        Object.keys(input[0]).forEach((temp) => { cols.push({ key: temp, header: temp }); });
        worksheet.columns = cols;
        worksheet.columns.forEach((sheetColumn) => { sheetColumn.font = { size: 12, }; sheetColumn.width = 30; });
        if (Object.values(input).length > 0) {
            worksheet.getRow(1).font = { bold: true, size: 13, };
            Object.values(input).forEach((item) => { worksheet.addRow(item); });
        }
    }
};
// Create column List
const createColumnsList = async (ctx, entity) => {
    const columnList = [];
    await (0, helpers_1.asyncForEach)(Object.keys(ctx.model[entity].columns), async (column) => {
        const createQuery = (input) => `select distinct ${input} AS "${column}" from "${ctx.model[entity].table}" LIMIT 200`;
        if (ctx.model[entity].columns[column].create !== "") {
            // IF JSON create column-key  note THAT is limit 200 firts items
            if (models_1.models.isColumnType(ctx.config, ctx.model[entity], column, "json")) {
                const tempSqlResult = await configuration_1.serverConfig.connection(ctx.config.name).unsafe(createQuery(`jsonb_object_keys("${column}")`))
                    .catch(async (e) => {
                    if (e.code === "22023") {
                        const tempSqlResult = await configuration_1.serverConfig.connection(ctx.config.name).unsafe(createQuery(`jsonb_object_keys("${column}"[0])`)).catch(async (e) => {
                            if (e.code === "42804") {
                                const tempSqlResult = await configuration_1.serverConfig.connection(ctx.config.name).unsafe(createQuery(`jsonb_object_keys(jsonb_array_elements("${column}"))`));
                                if (tempSqlResult && tempSqlResult.length > 0)
                                    tempSqlResult.forEach((e) => { columnList.push(`jsonb_array_elements("${column}")->>'${e[column]}' AS "${column}-${e[column]}"`); });
                            }
                            else
                                log_1.log.errorMsg(e);
                        });
                        if (tempSqlResult && tempSqlResult.length > 0)
                            tempSqlResult.forEach((e) => { columnList.push(`"${column}"[0]->>'${e[column]}' AS "${column}-${e[column]}"`); });
                    }
                    else
                        log_1.log.errorMsg(e);
                });
                if (tempSqlResult && tempSqlResult.length > 0)
                    tempSqlResult.forEach((e) => { columnList.push(`"${column}"->>'${e[column]}' AS "${column}-${e[column]}"`); });
            }
            else
                columnList.push(`"${column}"`);
        }
    });
    return columnList;
};
const exportToXlsx = async (ctx) => {
    // CReate new workBook
    const workbook = new exceljs_1.default.Workbook();
    workbook.creator = "Me";
    workbook.lastModifiedBy = "Her";
    workbook.created = new Date(Date.now());
    workbook.modified = new Date(Date.now());
    // Get configs infos
    addConfigToExcel(workbook, configuration_1.serverConfig.getConfigForExcelExport(ctx.config.name));
    // Loop on entities
    await (0, helpers_1.asyncForEach)(Object.keys((0, enums_1.filterEntities)(ctx.config.extensions)).filter((entity) => ctx.model[entity].table !== ""), async (entity) => {
        const cols = await createColumnsList(ctx, entity);
        const temp = await configuration_1.serverConfig.connection(ctx.config.name).unsafe(`select ${cols} from "${ctx.model[entity].table}" LIMIT 200`);
        await addToExcel(workbook, entity, temp);
    });
    // Save file
    ctx.status = 200;
    ctx.response.attachment(`${ctx.config.name}.xlsx`);
    await workbook.xlsx.write(ctx.res);
    // Close all
    ctx.res.end();
};
exports.exportToXlsx = exportToXlsx;
