"use strict";
/**
* createUser
*
* @copyright 2020-present Inrae
* @author mario.adam@inrae.fr
*
*/
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUser = void 0;
const log_1 = require("../../log");
const dataAccess_1 = require("../dataAccess");
// onsole.log("!----------------------------------- createUser -----------------------------------!");
const createUser = async (config) => {
    return new Promise(async function (resolve, reject) {
        await dataAccess_1.userAccess.post(config.name, {
            username: config.pg.user,
            email: "TWOdefault@email.com",
            password: config.pg.password,
            database: config.pg.database,
            canPost: true,
            canDelete: true,
            canCreateUser: true,
            canCreateDb: true,
            superAdmin: false,
            admin: false
        })
            .then(() => { resolve(`${config.pg.user} ${"\u2714\uFE0F\uFE0F" /* EChar.ok */}`); })
            .catch((err) => {
            log_1.log.errorMsg(err);
            reject(err);
        });
    });
};
exports.createUser = createUser;
