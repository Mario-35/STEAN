"use strict";
/**
 * createTable
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- createTable -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTable = void 0;
const configuration_1 = require("../../configuration");
const log_1 = require("../../log");
const helpers_1 = require("../../helpers");
const createTable = async (configName, tableEntity, doAfter) => {
    if (!tableEntity)
        return {};
    console.log(log_1.log.head(`CreateTable [${tableEntity.table}] for ${configName}`));
    const space = 5;
    const tab = () => " ".repeat(space);
    const tabIeInsert = [];
    const tableConstraints = [];
    const returnValue = {};
    let insertion = "";
    if (!configuration_1.serverConfig.connection(configName)) {
        log_1.log.errorMsg("connection Error");
        return { error: "connection Error" };
    }
    Object.keys(tableEntity.columns).forEach((column) => {
        if (tableEntity.columns[column].create.trim() != "")
            tabIeInsert.push(`${(0, helpers_1.addDoubleQuotes)(column)} ${tableEntity.columns[column].create}`);
    });
    insertion = tabIeInsert.join(", ");
    if (tableEntity.constraints) {
        Object.keys(tableEntity.constraints).forEach((constraint) => {
            if (tableEntity.constraints)
                tableConstraints.push(`ALTER TABLE ONLY ${(0, helpers_1.addDoubleQuotes)(tableEntity.table)} ADD CONSTRAINT ${(0, helpers_1.addDoubleQuotes)(constraint)} ${tableEntity.constraints[constraint]};`);
        });
    }
    if (tableEntity.table.trim() != "")
        returnValue[String(`Create table ${(0, helpers_1.addDoubleQuotes)(tableEntity.table)}`)] =
            await configuration_1.serverConfig.connection(configName).unsafe(`CREATE TABLE ${(0, helpers_1.addDoubleQuotes)(tableEntity.table)} (${insertion});`)
                .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
                .catch((error) => error.message);
    const indexes = tableEntity.indexes;
    const tabTemp = [];
    // CREATE INDEXES
    if (indexes)
        Object.keys(indexes).forEach((index) => {
            tabTemp.push(`CREATE INDEX "${index}" ${indexes[index]}`);
        });
    if (tabTemp.length > 0)
        returnValue[`${tab()}Create indexes for ${tableEntity.name}`] =
            await configuration_1.serverConfig.connection(configName).unsafe(tabTemp.join(";"))
                .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
                .catch((error) => error.message);
    // CREATE CONSTRAINTS
    if (tableEntity.constraints && tableConstraints.length > 0)
        returnValue[`${tab()}Create constraints for ${tableEntity.table}`] =
            await configuration_1.serverConfig.connection(configName).unsafe(tableConstraints.join(" "))
                .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
                .catch((error) => error.message);
    // CREATE SOMETHING AFTER
    if (tableEntity.after) {
        if (tableEntity.after.toUpperCase().startsWith("INSERT"))
            returnValue[`${tab()}Something to do after for ${tableEntity.table}`] =
                await configuration_1.serverConfig.connection(configName).unsafe(tableEntity.after)
                    .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
                    .catch((error) => {
                    log_1.log.errorMsg(error);
                    return error.message;
                });
    }
    // CREATE SOMETHING AFTER (migration)
    if (doAfter) {
        returnValue[`${tab()} doAfter ${tableEntity.table}`] = await configuration_1.serverConfig.connection(configName).unsafe(doAfter)
            .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
            .catch((error) => error.message);
    }
    return returnValue;
};
exports.createTable = createTable;
