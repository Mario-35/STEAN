"use strict";
/**
 * executeSql
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- executeSql -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeSql = void 0;
const configuration_1 = require("../../configuration");
const log_1 = require("../../log");
const helpers_1 = require("../../helpers");
const executeSqlOne = async (config, query) => {
    configuration_1.serverConfig.writeLog(log_1.log.query(query));
    return new Promise(async function (resolve, reject) {
        await configuration_1.serverConfig.connection(config.name).unsafe(query).then((res) => {
            resolve(res);
        }).catch((err) => {
            if (!(0, helpers_1.isTest)() && +err["code"] === 23505)
                configuration_1.serverConfig.writeLog(log_1.log.queryError(query, err));
            reject(err);
        });
    });
};
const executeSqlMulti = async (config, query) => {
    configuration_1.serverConfig.writeLog(log_1.log.query(query));
    return new Promise(async function (resolve, reject) {
        await configuration_1.serverConfig.connection(config.name).begin(sql => query.map((e) => sql.unsafe(e)))
            .then((res) => {
            resolve(res);
        }).catch((err) => {
            if (!(0, helpers_1.isTest)() && +err["code"] === 23505)
                configuration_1.serverConfig.writeLog(log_1.log.queryError(query, err));
            reject(err);
        });
    });
};
const executeSql = async (config, query) => typeof query === "string"
    ? executeSqlOne(config, query)
    : executeSqlMulti(config, query);
exports.executeSql = executeSql;
