"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeAdmin = void 0;
/**
 * executeAdmin.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- executeAdmin. -----------------------------------!");
const configuration_1 = require("../../configuration");
const constants_1 = require("../../constants");
const log_1 = require("../../log");
const executeAdmin = async (query) => {
    log_1.log.query(query);
    return new Promise(async function (resolve, reject) {
        await configuration_1.serverConfig.connection(constants_1.ADMIN).unsafe(query).then((res) => {
            resolve(res);
        }).catch((err) => {
            reject(err);
        });
    });
};
exports.executeAdmin = executeAdmin;
