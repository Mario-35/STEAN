"use strict";
/**
 * executeSqlValues
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- executeSqlValues. -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeSqlValues = void 0;
const configuration_1 = require("../../configuration");
const log_1 = require("../../log");
const helpers_1 = require("../../helpers");
const executeSqlValues = async (config, query) => {
    log_1.log.query(`${query}`);
    if (typeof query === "string") {
        return new Promise(async function (resolve, reject) {
            await configuration_1.serverConfig.connection(typeof config === "string" ? config : config.name).unsafe(query).values().then((res) => {
                resolve(res[0]);
            }).catch((err) => {
                if (!(0, helpers_1.isTest)() && +err["code"] === 23505)
                    log_1.log.queryError(query, err);
                reject(err);
            });
        });
    }
    else {
        return new Promise(async function (resolve, reject) {
            let result = {};
            await (0, helpers_1.asyncForEach)(query, async (sql) => {
                await configuration_1.serverConfig.connection(typeof config === "string" ? config : config.name).unsafe(sql).values().then((res) => {
                    result = { ...result, ...res[0] };
                }).catch((err) => {
                    if (!(0, helpers_1.isTest)() && +err["code"] === 23505)
                        log_1.log.queryError(query, err);
                    reject(err);
                });
            });
            resolve(result);
        });
    }
};
exports.executeSqlValues = executeSqlValues;
