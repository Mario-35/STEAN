"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeKeyFromUrl = void 0;
/**
 * removeKeyFromUrl.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- removeKeyFromUrl. -----------------------------------!");
const helpers_1 = require("../../helpers");
/**
 *
 * @param input url string
 * @param keys array of keys to remove
 * @returns clean url string
 * */
const removeKeyFromUrl = (input, keys) => {
    // Clean input
    input = decodeURIComponent(input);
    if (!input.includes("?"))
        return input;
    const firstSplit = input.split("?");
    const returnValue = [];
    firstSplit[1].split("&").forEach((element) => {
        if (element.includes("=")) {
            const temp = element.split("=");
            if (!(keys.includes(temp[0]) || keys.includes(`${temp[0].replace("$", "")}`)))
                returnValue.push(element);
        }
    });
    return (0, helpers_1.cleanUrl)(`${firstSplit[0]}?${returnValue[0] && returnValue[0].startsWith("$") ? "" : "$"}${returnValue.join("&")}`);
};
exports.removeKeyFromUrl = removeKeyFromUrl;
