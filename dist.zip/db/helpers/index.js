"use strict";
/**
 * Index Helpers
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Index Helpers -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.exportService = exports.columnsNameFromHydrasCsv = exports.createIndexes = exports.streamCsvFile = exports.columnsNameFromCsv = exports.queryInsertFromCsv = exports.removeKeyFromUrl = exports.getDBDateNow = exports.executeSqlValues = exports.executeSql = exports.executeAdmin = exports.dateToDateWithTimeZone = exports.createUser = exports.createTable = exports.createService = exports.createDatabase = exports.addToService = void 0;
const exportToJson_1 = require("./exportToJson");
const exportToXlsx_1 = require("./exportToXlsx");
var addToService_1 = require("./addToService");
Object.defineProperty(exports, "addToService", { enumerable: true, get: function () { return addToService_1.addToService; } });
var createDb_1 = require("../createDb");
Object.defineProperty(exports, "createDatabase", { enumerable: true, get: function () { return createDb_1.createDatabase; } });
var createService_1 = require("./createService");
Object.defineProperty(exports, "createService", { enumerable: true, get: function () { return createService_1.createService; } });
var createTable_1 = require("./createTable");
Object.defineProperty(exports, "createTable", { enumerable: true, get: function () { return createTable_1.createTable; } });
var createUser_1 = require("./createUser");
Object.defineProperty(exports, "createUser", { enumerable: true, get: function () { return createUser_1.createUser; } });
var dateToDateWithTimeZone_1 = require("./dateToDateWithTimeZone");
Object.defineProperty(exports, "dateToDateWithTimeZone", { enumerable: true, get: function () { return dateToDateWithTimeZone_1.dateToDateWithTimeZone; } });
var executeAdmin_1 = require("./executeAdmin");
Object.defineProperty(exports, "executeAdmin", { enumerable: true, get: function () { return executeAdmin_1.executeAdmin; } });
var executeSql_1 = require("./executeSql");
Object.defineProperty(exports, "executeSql", { enumerable: true, get: function () { return executeSql_1.executeSql; } });
var executeSqlValues_1 = require("./executeSqlValues");
Object.defineProperty(exports, "executeSqlValues", { enumerable: true, get: function () { return executeSqlValues_1.executeSqlValues; } });
var getDBDateNow_1 = require("./getDBDateNow");
Object.defineProperty(exports, "getDBDateNow", { enumerable: true, get: function () { return getDBDateNow_1.getDBDateNow; } });
var removeKeyFromUrl_1 = require("./removeKeyFromUrl");
Object.defineProperty(exports, "removeKeyFromUrl", { enumerable: true, get: function () { return removeKeyFromUrl_1.removeKeyFromUrl; } });
var queryInsertFromCsv_1 = require("./queryInsertFromCsv");
Object.defineProperty(exports, "queryInsertFromCsv", { enumerable: true, get: function () { return queryInsertFromCsv_1.queryInsertFromCsv; } });
var columnsNameFromCsv_1 = require("./columnsNameFromCsv");
Object.defineProperty(exports, "columnsNameFromCsv", { enumerable: true, get: function () { return columnsNameFromCsv_1.columnsNameFromCsv; } });
var streamCsvFile_1 = require("./streamCsvFile");
Object.defineProperty(exports, "streamCsvFile", { enumerable: true, get: function () { return streamCsvFile_1.streamCsvFile; } });
var createIndexes_1 = require("./createIndexes");
Object.defineProperty(exports, "createIndexes", { enumerable: true, get: function () { return createIndexes_1.createIndexes; } });
var columnsNameFromHydrasCsv_1 = require("./columnsNameFromHydrasCsv");
Object.defineProperty(exports, "columnsNameFromHydrasCsv", { enumerable: true, get: function () { return columnsNameFromHydrasCsv_1.columnsNameFromHydrasCsv; } });
const exportService = async (ctx) => { return (ctx.url.includes("xls")) ? (0, exportToXlsx_1.exportToXlsx)(ctx) : (0, exportToJson_1.exportToJson)(ctx); };
exports.exportService = exportService;
