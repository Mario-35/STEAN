"use strict";
/**
* createRole
*
* @copyright 2020-present Inrae
* @author mario.adam@inrae.fr
*
*/
// onsole.log("!----------------------------------- createRole -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRole = void 0;
const configuration_1 = require("../../configuration");
const helpers_1 = require("../../helpers");
const constants_1 = require("../constants");
const createRole = async (config) => {
    const connection = configuration_1.serverConfig.connection(config.name);
    return new Promise(async function (resolve, reject) {
        await connection.unsafe(`SELECT COUNT(*) FROM pg_user WHERE usename = ${(0, helpers_1.addSimpleQuotes)(config.pg.user)};`)
            .then(async (res) => {
            if (res[0].count == 0) {
                await connection.unsafe(`CREATE ROLE ${config.pg.user} WITH PASSWORD ${(0, helpers_1.addSimpleQuotes)(config.pg.password)} ${constants_1._RIGHTS}`)
                    .catch((err) => {
                    reject(err);
                });
            }
            else {
                await connection.unsafe(`ALTER ROLE ${config.pg.user} WITH PASSWORD ${(0, helpers_1.addSimpleQuotes)(config.pg.password)}  ${constants_1._RIGHTS}`)
                    .catch((err) => {
                    reject(err);
                });
            }
        });
        resolve(`${config.pg.user} ${"\u2714\uFE0F\uFE0F" /* EChar.ok */}`);
    });
};
exports.createRole = createRole;
