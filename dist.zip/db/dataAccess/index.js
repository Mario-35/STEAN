"use strict";
/**
 * dataAccess index
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- dataAccess index -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.userAccess = exports.apiAccess = void 0;
var apiAccess_1 = require("./apiAccess");
Object.defineProperty(exports, "apiAccess", { enumerable: true, get: function () { return apiAccess_1.apiAccess; } });
var userAccess_1 = require("./userAccess");
Object.defineProperty(exports, "userAccess", { enumerable: true, get: function () { return userAccess_1.userAccess; } });
