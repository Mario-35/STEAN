"use strict";
/**
 * Constants for DataBase
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Constants for DataBase -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports._SELFLINK = exports._NAVLINK = exports._ID = exports._RIGHTS = void 0;
exports._RIGHTS = "SUPERUSER CREATEDB NOCREATEROLE INHERIT LOGIN NOREPLICATION NOBYPASSRLS CONNECTION LIMIT -1";
exports._ID = '@iot.id';
exports._NAVLINK = '@iot.navigationLink';
exports._SELFLINK = '@iot.selfLink';
