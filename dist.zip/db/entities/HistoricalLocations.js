"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HistoricalLocations = void 0;
const logger_1 = require("../../logger");
const common_1 = require("./common");
class HistoricalLocations extends common_1.Common {
    constructor(ctx) {
        console.log(logger_1.formatLog.whereIam());
        super(ctx);
    }
}
exports.HistoricalLocations = HistoricalLocations;
