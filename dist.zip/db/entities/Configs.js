"use strict";
/**
 * Configs entity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Configs entity -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.Configs = void 0;
const common_1 = require("./common");
const configuration_1 = require("../../configuration");
const helpers_1 = require("../../helpers");
const helpers_2 = require("../helpers");
const constants_1 = require("../../constants");
const authentication_1 = require("../../authentication");
const log_1 = require("../../log");
class Configs extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
    async getAll() {
        console.log(log_1.log.whereIam());
        let can = (0, authentication_1.userAuthenticated)(this.ctx);
        if (can) {
            can = (this.ctx.user.PDCUAS[4] === true);
            if (this.ctx.user.PDCUAS[5] === true)
                can = true;
        }
        // Return result If not authorised    
        if (!can)
            return this.formatReturnResult({
                body: (0, helpers_1.hidePassword)(configuration_1.serverConfig.getConfig(this.ctx.config.name))
            });
        // Return result
        return this.formatReturnResult({
            body: (0, helpers_1.hidePassword)(configuration_1.serverConfig.getConfigs().map((elem) => ({
                [elem]: { ...configuration_1.serverConfig.getConfig(elem) }
            })))
        });
    }
    async getSingle(idInput) {
        console.log(log_1.log.whereIam());
        // Return result If not authorised
        if (!(0, authentication_1.userAuthenticated)(this.ctx))
            this.ctx.throw(401);
        // Return result
        return this.formatReturnResult({
            body: (0, helpers_1.hideKeysInJson)(configuration_1.serverConfig.getConfig(typeof idInput === "string" ? idInput : this.ctx.config.name), ["entities"]),
        });
    }
    async post(dataInput) {
        console.log(log_1.log.whereIam());
        if (dataInput && dataInput["create"] && dataInput["create"]["name"]) {
            return this.formatReturnResult({
                body: await (0, helpers_2.createService)(dataInput, this.ctx),
            });
        }
        else if (dataInput && dataInput["add"] && dataInput["add"]["name"]) {
            return this.formatReturnResult({
                body: await (0, helpers_2.addToService)(this.ctx, dataInput),
            });
        }
        if (!(0, authentication_1.userAuthenticated)(this.ctx))
            this.ctx.throw(401);
        if (dataInput)
            return this.formatReturnResult({
                body: await configuration_1.serverConfig.addConfig(dataInput),
            });
    }
    // Update an item
    async update(idInput, dataInput) {
        (0, constants_1.setDebug)(true);
        console.log(log_1.log.whereIam());
        console.log(idInput);
        console.log(dataInput);
    }
    // Delete an item
    async delete(idInput) {
        console.log(log_1.log.whereIam(idInput));
        // This function not exists
        return;
    }
}
exports.Configs = Configs;
