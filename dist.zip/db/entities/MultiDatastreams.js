"use strict";
/**
 * MultiDatastreams entity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- MultiDatastreams entity -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.MultiDatastreams = void 0;
const common_1 = require("./common");
const messages_1 = require("../../messages/");
const log_1 = require("../../log");
class MultiDatastreams extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
    formatDataInput(input) {
        console.log(log_1.log.whereIam());
        if (!input)
            this.ctx.throw(400, { code: 400, detail: messages_1.errors.noData });
        const temp = this.getKeysValue(input, ["FeaturesOfInterest", "foi"]);
        if (temp)
            input["_default_foi"] = temp;
        if (input["multiObservationDataTypes"] && input["unitOfMeasurements"] && input["ObservedProperties"]) {
            if (input["multiObservationDataTypes"].length != input["unitOfMeasurements"].length)
                this.ctx.throw(400, {
                    code: 400,
                    detail: (0, messages_1.msg)(messages_1.errors.sizeListKeysUnitOfMeasurements, input["unitOfMeasurements"].length, input["multiObservationDataTypes"].length),
                });
            if (input["multiObservationDataTypes"].length != input["ObservedProperties"].length)
                this.ctx.throw(400, {
                    code: 400,
                    detail: (0, messages_1.msg)(messages_1.errors.sizeListKeysObservedProperties, input["ObservedProperties"].length, input["multiObservationDataTypes"].length),
                });
        }
        if (input && input["multiObservationDataTypes"] && input["multiObservationDataTypes"] != null)
            input["multiObservationDataTypes"] = JSON.stringify(input["multiObservationDataTypes"])
                .replace("[", "{")
                .replace("]", "}");
        if (input["observationType"]) {
            if (!this.ctx.model.MultiDatastreams.columns["observationType"].verify?.list.includes(input["observationType"]))
                this.ctx.throw(400, { code: 400, detail: messages_1.errors["observationType"] });
        }
        else
            input["observationType"] =
                this.ctx.model.MultiDatastreams.columns["observationType"].verify?.default;
        return input;
    }
}
exports.MultiDatastreams = MultiDatastreams;
