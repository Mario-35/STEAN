"use strict";
/**
 * Datastreams entity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Datastreams entity -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.Datastreams = void 0;
const log_1 = require("../../log");
const messages_1 = require("../../messages");
const common_1 = require("./common");
class Datastreams extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
    formatDataInput(input) {
        console.log(log_1.log.whereIam());
        if (input) {
            const colName = "observationType";
            if (input[colName]) {
                if (!this.ctx.model.Datastreams.columns[colName].verify?.list.includes(input[colName]))
                    this.ctx.throw(400, { code: 400, detail: messages_1.errors[colName] });
            }
            else
                input[colName] = this.ctx.model.Datastreams.columns[colName].verify?.default;
        }
        return input;
    }
}
exports.Datastreams = Datastreams;
