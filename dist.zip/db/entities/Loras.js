"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Loras = void 0;
/**
 * Loras entity.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Loras entity. -----------------------------------!");
const common_1 = require("./common");
const index_1 = require("../../helpers/index");
const constants_1 = require("../../constants");
const messages_1 = require("../../messages/");
const enums_1 = require("../../enums");
const queries_1 = require("../queries");
const lora_1 = require("../../lora");
const helpers_1 = require("../helpers");
const constants_2 = require("../constants");
const log_1 = require("../../log");
class Loras extends common_1.Common {
    synonym = {};
    stean = {};
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
    // prepare datas to lora input
    async prepareInputResult(dataInput) {
        console.log(log_1.log.whereIam());
        const result = {};
        const listKeys = ["deveui", "DevEUI", "sensor_id", "frame"];
        if ((0, index_1.notNull)(dataInput["payload_deciphered"]))
            this.stean["frame"] = dataInput["payload_deciphered"].toUpperCase();
        Object.entries(dataInput).forEach(([k, v]) => (result[listKeys.includes(k) ? k.toLowerCase() : k] = listKeys.includes(k) ? v.toUpperCase() : v));
        if (!isNaN(dataInput["timestamp"]))
            result["timestamp"] = new Date(dataInput["timestamp"] * 1000).toISOString();
        return result;
    }
    createListQuery(input, columnListString) {
        console.log(log_1.log.whereIam());
        const tempList = columnListString.split("COLUMN");
        return tempList[0].concat('"', input.join(`"${tempList[1]}${tempList[0]}"`), '"', tempList[1]);
    }
    // Override post
    async post(dataInput, silent) {
        console.log(log_1.log.whereIam());
        const addToStean = (key) => (this.stean[key] = dataInput[key]);
        if (dataInput)
            this.stean = await this.prepareInputResult(dataInput);
        if (this.stean["frame"] === "000000000000000000")
            this.ctx.throw(400, { code: 400, detail: messages_1.errors.frameNotConform });
        function gedataInputtDate() {
            if (dataInput["datetime"])
                return String(dataInput["datetime"]);
            if (dataInput["phenomenonTime"])
                return String(dataInput["phenomenonTime"]);
            if (dataInput["timestamp"])
                return String(new Date(dataInput["timestamp"] * 1000));
        }
        // search for MultiDatastream
        if ((0, index_1.notNull)(dataInput["MultiDatastream"])) {
            if (!(0, index_1.notNull)(this.stean["deveui"])) {
                if (silent)
                    return this.formatReturnResult({ body: messages_1.errors.deveuiMessage });
                else
                    this.ctx.throw(400, { code: 400, detail: messages_1.errors.deveuiMessage });
            }
            addToStean("MultiDatastream");
            return await super.post(this.stean);
        }
        // search for Datastream 
        if ((0, index_1.notNull)(dataInput["Datastream"])) {
            if (!(0, index_1.notNull)(dataInput["deveui"])) {
                if (silent)
                    return this.formatReturnResult({ body: messages_1.errors.deveuiMessage });
                else
                    this.ctx.throw(400, { code: 400, detail: messages_1.errors.deveuiMessage });
            }
            addToStean("Datastream");
            return await super.post(this.stean);
        }
        // search for deveui
        if (!(0, index_1.notNull)(this.stean["deveui"])) {
            if (silent)
                return this.formatReturnResult({ body: messages_1.errors.deveuiMessage });
            else
                this.ctx.throw(400, { code: 400, detail: messages_1.errors.deveuiMessage });
        }
        const stream = await (0, helpers_1.executeSql)(this.ctx.config, (0, queries_1.streamFromDeveui)(this.stean["deveui"])).then((res) => {
            if (res[0]["multidatastream"] != null)
                return res[0]["multidatastream"][0];
            if (res[0]["datastream"] != null)
                return res[0]["datastream"][0];
            this.ctx.throw(400, { code: 400, detail: (0, messages_1.msg)(messages_1.errors.deveuiNotFound, this.stean["deveui"]) });
        });
        console.log(log_1.log.debug("stream", stream));
        // search for frame and decode payload if found
        if ((0, index_1.notNull)(this.stean["frame"])) {
            const temp = await (0, lora_1.decodeloraDeveuiPayload)(this.ctx, this.stean["deveui"], this.stean["frame"]);
            console.log("ssssssssssssssssssssssssssssssssssssssssssssssssssss");
            console.log(temp);
            if (!temp)
                return this.ctx.throw(400, { code: 400, detail: "Error" });
            if (temp && temp.error) {
                if (silent)
                    return this.formatReturnResult({ body: temp.error });
                else
                    this.ctx.throw(400, { code: 400, detail: temp.error });
            }
            this.stean["decodedPayload"] = temp["result"];
            console.log("==========================================================");
            console.log(this.stean["decodedPayload"]);
            if (this.stean["decodedPayload"].valid === false)
                this.ctx.throw(400, { code: 400, detail: messages_1.errors.InvalidPayload });
        }
        const searchMulti = (0, queries_1.multiDatastreamFromDeveui)(this.stean["deveui"]);
        this.stean["formatedDatas"] = {};
        if (stream["multidatastream"]) {
            if (this.stean["decodedPayload"] && (0, index_1.notNull)(this.stean["decodedPayload"]["datas"]))
                Object.keys(this.stean["decodedPayload"]["datas"]).forEach((key) => {
                    this.stean["formatedDatas"][key.toLowerCase()] =
                        this.stean["decodedPayload"]["datas"][key];
                });
            // convert all keys in lowercase
            if ((0, index_1.notNull)(dataInput["data"]))
                Object.keys(dataInput["data"]).forEach((key) => {
                    this.stean["formatedDatas"][key.toLowerCase()] = dataInput["data"][key];
                });
            if (!(0, index_1.notNull)(this.stean["formatedDatas"])) {
                if (silent)
                    return this.formatReturnResult({ body: messages_1.errors.dataMessage });
                else
                    this.ctx.throw(400, { code: 400, detail: messages_1.errors.dataMessage });
            }
        }
        else {
            if (this.stean["decodedPayload"] && this.stean["decodedPayload"]["datas"]) {
                this.stean["formatedDatas"] = this.stean["decodedPayload"]["datas"];
            }
            else if (!this.stean["value"]) {
                if (silent)
                    return this.formatReturnResult({ body: messages_1.errors.dataMessage });
                else
                    this.ctx.throw(400, { code: 400, detail: messages_1.errors.dataMessage });
            }
        }
        console.log(log_1.log.debug("Formated datas", this.stean["formatedDatas"]));
        this.stean["date"] = gedataInputtDate();
        if (!this.stean["date"]) {
            if (silent)
                return this.formatReturnResult({ body: messages_1.errors.noValidDate });
            else
                this.ctx.throw(400, { code: 400, detail: messages_1.errors.noValidDate });
        }
        if (stream["multidatastream"]) {
            console.log(log_1.log.debug("multiDatastream", stream));
            const listOfSortedValues = {};
            stream["keys"].forEach((element) => {
                listOfSortedValues[element] = null;
                const searchStr = element.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
                if (this.stean["formatedDatas"][searchStr])
                    listOfSortedValues[element] = this.stean["formatedDatas"][searchStr];
                else
                    Object.keys(this.stean["formatedDatas"]).forEach((subElem) => {
                        if (element.toUpperCase().includes(subElem.toUpperCase()))
                            listOfSortedValues[element] = this.stean["formatedDatas"][subElem];
                        else if (this.synonym[element])
                            this.synonym[element].forEach((key) => {
                                if (key.toUpperCase().includes(subElem.toUpperCase()))
                                    listOfSortedValues[element] = this.stean["formatedDatas"][subElem];
                            });
                    });
            });
            console.log(log_1.log.debug("Values", listOfSortedValues));
            if (Object.values(listOfSortedValues).filter((word) => word != null).length < 1) {
                const errorMessage = `${messages_1.errors.dataNotCorresponding} [${stream["keys"]}] with [${Object.keys(this.stean["formatedDatas"])}]`;
                if (silent)
                    return this.formatReturnResult({ body: errorMessage });
                else
                    this.ctx.throw(400, { code: 400, detail: errorMessage });
            }
            const getFeatureOfInterest = (0, index_1.getBigIntFromString)(dataInput["FeatureOfInterest"]);
            const temp = listOfSortedValues;
            if (temp && typeof temp == "object") {
                const tempLength = Object.keys(temp).length;
                console.log(log_1.log.debug("data : Keys", `${tempLength} : ${stream["keys"].length}`));
                if (tempLength != stream["keys"].length) {
                    const errorMessage = (0, messages_1.msg)(messages_1.errors.sizeListKeys, String(tempLength), stream["keys"].length);
                    if (silent)
                        return this.formatReturnResult({ body: errorMessage });
                    else
                        this.ctx.throw(400, { code: 400, detail: errorMessage });
                }
            }
            const resultCreate = `'${JSON.stringify({
                value: Object.values(listOfSortedValues),
                valueskeys: (0, constants_1.ESCAPE_SIMPLE_QUOTE)(JSON.stringify(listOfSortedValues)),
                payload: this.stean["frame"],
            })}'::jsonb`;
            const insertObject = {
                featureofinterest_id: getFeatureOfInterest
                    ? `SELECT COALESCE((SELECT "id" FROM "featureofinterest" WHERE "id" = ${getFeatureOfInterest}), ${getFeatureOfInterest})`
                    : `(SELECT multidatastream1._default_foi FROM multidatastream1)`,
                multidatastream_id: "(SELECT multidatastream1.id FROM multidatastream1)",
                phenomenonTime: `to_timestamp('${this.stean["timestamp"]}','${enums_1.EDatesType.dateWithOutTimeZone}')::timestamp`,
                resultTime: `to_timestamp('${this.stean["timestamp"]}','${enums_1.EDatesType.dateWithOutTimeZone}')::timestamp`,
                result: resultCreate,
            };
            const searchDuplicate = Object.keys(insertObject)
                .slice(0, -1)
                .map((elem) => `"${elem}" = ${insertObject[elem]} AND `)
                .concat(`"result" = ${resultCreate}`)
                .join("");
            const sql = `WITH "${constants_1.VOIDTABLE}" AS (SELECT srid FROM "${constants_1.VOIDTABLE}" LIMIT 1)
                , multidatastream1 AS (SELECT id, thing_id, _default_foi, ${searchMulti} LIMIT 1)
                , myValues ( "${Object.keys(insertObject).join(constants_1.DOUBLEQUOTEDCOMA)}") AS (values (${Object.values(insertObject).join()}))
                , searchDuplicate AS (SELECT * FROM "${this.ctx.model.Observations.table}" WHERE ${searchDuplicate})
                , observation1 AS (INSERT INTO  "${this.ctx.model.Observations.table}" ("${Object.keys(insertObject).join(constants_1.DOUBLEQUOTEDCOMA)}") SELECT * FROM myValues WHERE NOT EXISTS (SELECT * FROM searchDuplicate)
                                  AND (SELECT id FROM multidatastream1) IS NOT NULL
                                  RETURNING *)
                , result1 AS (SELECT (SELECT observation1.id FROM observation1)
                , (SELECT multidatastream1."keys" FROM multidatastream1)
                , (SELECT searchDuplicate.id AS duplicate FROM  searchDuplicate)
                , ${this.createListQuery(Object.keys(insertObject), "(SELECT observation1.COLUMN FROM observation1), ")} (SELECT multidatastream1.id FROM multidatastream1) AS multidatastream, (SELECT multidatastream1.thing_id FROM multidatastream1) AS thing)
                 SELECT coalesce(json_agg(t), '[]') AS result FROM result1 AS t`;
            return await (0, helpers_1.executeSqlValues)(this.ctx.config, sql).then(async (res) => {
                // TODO MULTI 
                const tempResult = res[0][0];
                if (tempResult.id != null) {
                    const result = {
                        phenomenonTime: `"${tempResult.phenomenonTime}"`,
                        resultTime: `"${tempResult.resultTime}"`,
                        result: tempResult["result"]["value"],
                    };
                    result[constants_2._ID] = tempResult.id;
                    result[constants_2._SELFLINK] = `${this.ctx.decodedUrl.root}/Observations(${tempResult.id})`;
                    Object.keys(this.ctx.model["Observations"].relations).forEach((word) => {
                        result[`${word}${constants_2._NAVLINK}`] = `${this.ctx.decodedUrl.root}/Observations(${tempResult.id})/${word}`;
                    });
                    return this.formatReturnResult({ body: result, query: sql, });
                }
                else {
                    if (silent)
                        return this.formatReturnResult({ body: messages_1.errors.observationExist });
                    else
                        this.ctx.throw(409, {
                            code: 409,
                            detail: messages_1.errors.observationExist,
                            link: `${this.ctx.decodedUrl.root}/Observations(${[
                                tempResult.duplicate,
                            ]})`,
                        });
                }
            });
        }
        else if (stream["datastream"]) {
            console.log(log_1.log.debug("datastream", stream["datastream"]));
            const getFeatureOfInterest = (0, index_1.getBigIntFromString)(dataInput["FeatureOfInterest"]);
            const searchFOI = await (0, helpers_1.executeSql)(this.ctx.config, getFeatureOfInterest
                ? `SELECT coalesce((SELECT "id" FROM "${this.ctx.model.FeaturesOfInterest.table}" WHERE "id" = ${getFeatureOfInterest}), ${getFeatureOfInterest}) AS id `
                : stream["_default_foi"] ? `SELECT id FROM "${this.ctx.model.FeaturesOfInterest.table}" WHERE id = ${stream["_default_foi"]}` : "");
            if (searchFOI[0].length < 1) {
                if (silent)
                    return this.formatReturnResult({ body: messages_1.errors.noFoi });
                else
                    this.ctx.throw(400, { code: 400, detail: messages_1.errors.noFoi });
            }
            const value = this.stean["value"]
                ? this.stean["value"]
                : this.stean["decodedPayload"]["datas"]
                    ? this.stean["decodedPayload"]["datas"]
                    : this.stean["data"]["Data"]
                        ? this.stean["data"]["Data"]
                        : undefined;
            if (!value) {
                if (silent)
                    return this.formatReturnResult({ body: messages_1.errors.noValue });
                else
                    this.ctx.throw(400, { code: 400, detail: messages_1.errors.noValue });
            }
            const resultCreate = `'${JSON.stringify({ value: value })}'::jsonb`;
            const insertObject = {
                featureofinterest_id: "(SELECT datastream1._default_foi from datastream1)",
                datastream_id: "(SELECT datastream1.id from datastream1)",
                phenomenonTime: `to_timestamp('${this.stean["timestamp"]}','${enums_1.EDatesType.dateWithOutTimeZone}')::timestamp`,
                resultTime: `to_timestamp('${this.stean["timestamp"]}}','${enums_1.EDatesType.dateWithOutTimeZone}')::timestamp`,
                result: resultCreate,
            };
            const searchDuplicate = Object.keys(insertObject)
                .slice(0, -1)
                .map((elem) => `"${elem}" = ${insertObject[elem]} AND `)
                .concat(`"result" = ${resultCreate}`)
                .join("");
            console.log(log_1.log.debug("searchDuplicate", searchDuplicate));
            const sql = `WITH "${constants_1.VOIDTABLE}" AS (SELECT srid FROM "${constants_1.VOIDTABLE}" LIMIT 1)
               , datastream1 AS (SELECT id, _default_foi, thing_id FROM "${this.ctx.model.Datastreams.table}" WHERE id =${stream["id"]})
               , myValues ( "${Object.keys(insertObject).join(constants_1.DOUBLEQUOTEDCOMA)}") AS (values (${Object.values(insertObject).join()}))
               , searchDuplicate AS (SELECT * FROM "${this.ctx.model.Observations.table}" WHERE ${searchDuplicate})
               , observation1 AS (INSERT INTO  "${this.ctx.model.Observations.table}" ("${Object.keys(insertObject).join(constants_1.DOUBLEQUOTEDCOMA)}") SELECT * FROM myValues
                                WHERE NOT EXISTS (SELECT * FROM searchDuplicate)
                               AND (SELECT id from datastream1) IS NOT NULL
                               RETURNING *)
               , result1 AS (SELECT 
                    (SELECT observation1.id FROM observation1),
                    (SELECT searchDuplicate.id AS duplicate FROM searchDuplicate),
                    ${this.createListQuery(Object.keys(insertObject), "(SELECT observation1.COLUMN from observation1), ")} (SELECT datastream1.id from datastream1) AS datastream, (SELECT datastream1.thing_id from datastream1) AS thing)
                SELECT coalesce(json_agg(t), '[]') AS result FROM result1 AS t`;
            return await (0, helpers_1.executeSql)(this.ctx.config, sql).then(async (res) => {
                const tempResult = res[0]["result"][0];
                if (tempResult.id != null) {
                    const result = {
                        phenomenonTime: `"${tempResult.phenomenonTime}"`,
                        resultTime: `"${tempResult.resultTime}"`,
                        result: tempResult["result"]["value"],
                    };
                    result[constants_2._ID] = tempResult.id;
                    result[constants_2._SELFLINK] = `${this.ctx.decodedUrl.root}/Observations(${tempResult.id})`;
                    Object.keys(this.ctx.model["Observations"].relations).forEach((word) => {
                        result[`${word}${constants_2._NAVLINK}`] = `${this.ctx.decodedUrl.root}/Observations(${tempResult.id})/${word}`;
                    });
                    return this.formatReturnResult({
                        body: result,
                        query: sql,
                    });
                }
                else {
                    if (silent)
                        return this.formatReturnResult({ body: messages_1.errors.observationExist });
                    else
                        this.ctx.throw(409, {
                            code: 409,
                            detail: messages_1.errors.observationExist,
                            link: `${this.ctx.decodedUrl.root}/Observations(${[
                                tempResult.duplicate,
                            ]})`,
                        });
                }
            });
        }
    }
}
exports.Loras = Loras;
