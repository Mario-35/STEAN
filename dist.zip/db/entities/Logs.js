"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logs = void 0;
const logger_1 = require("../../logger");
const common_1 = require("./common");
class Logs extends common_1.Common {
    constructor(ctx) {
        console.log(logger_1.formatLog.whereIam());
        super(ctx);
    }
}
exports.Logs = Logs;
