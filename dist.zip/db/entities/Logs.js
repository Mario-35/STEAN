"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logs = void 0;
/**
 * Logs entity.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Logs entity. -----------------------------------!");
const log_1 = require("../../log");
const common_1 = require("./common");
class Logs extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
}
exports.Logs = Logs;
