"use strict";
/**
 * Locations entity.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Locations entity -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.Locations = void 0;
const log_1 = require("../../log");
const common_1 = require("./common");
class Locations extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
}
exports.Locations = Locations;
