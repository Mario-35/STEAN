"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Observations = void 0;
/**
 * Observations entity.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Observations entity. -----------------------------------!");
const common_1 = require("./common");
const helpers_1 = require("../helpers");
const helpers_2 = require("../../helpers");
const messages_1 = require("../../messages");
const queries_1 = require("../queries");
const enums_1 = require("../../enums");
const log_1 = require("../../log");
class Observations extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
    // Prepare odservations 
    async prepareInputResult(dataInput) {
        console.log(log_1.log.whereIam());
        // IF MultiDatastream
        if ((dataInput["MultiDatastream"] && dataInput["MultiDatastream"] != null) || (this.ctx.odata.parentEntity && this.ctx.odata.parentEntity.startsWith("MultiDatastream"))) {
            // get search ID
            const searchID = dataInput["MultiDatastream"] && dataInput["MultiDatastream"] != null
                ? BigInt(dataInput["MultiDatastream"]["@iot.id"])
                : (0, helpers_2.getBigIntFromString)(this.ctx.odata.parentId);
            if (!searchID)
                this.ctx.throw(404, { code: 404, detail: (0, messages_1.msg)(messages_1.errors.noFound, "MultiDatastreams"), });
            // Search uint keys
            const tempSql = await (0, helpers_1.executeSqlValues)(this.ctx.config, (0, queries_1.multiDatastreamsUnitsKeys)(searchID));
            const multiDatastream = tempSql[0];
            if (dataInput["result"] && typeof dataInput["result"] == "object") {
                console.log(log_1.log.debug("result : keys", `${Object.keys(dataInput["result"]).length} : ${multiDatastream.length}`));
                if (Object.keys(dataInput["result"]).length != multiDatastream.length) {
                    this.ctx.throw(400, {
                        code: 400,
                        detail: (0, messages_1.msg)(messages_1.errors.sizeResultUnitOfMeasurements, String(Object.keys(dataInput["result"]).length), multiDatastream.length),
                    });
                }
                dataInput["result"] = { value: Object.values(dataInput["result"]), valueskeys: dataInput["result"], };
            }
        }
        else if ((dataInput["Datastream"] && dataInput["Datastream"] != null) || (this.ctx.odata.parentEntity && this.ctx.odata.parentEntity.startsWith("Datastream"))) {
            if (dataInput["result"] && typeof dataInput["result"] != "object")
                dataInput["result"] = this.ctx.config.extensions.includes(enums_1.EExtensions.resultNumeric)
                    ? dataInput["result"]
                    : { value: dataInput["result"] };
        }
        else if (this.ctx.request.method === "POST") {
            this.ctx.throw(404, { code: 404, detail: messages_1.errors.noStream });
        }
        return dataInput;
    }
    formatDataInput(input) {
        console.log(log_1.log.whereIam());
        if (input)
            if (!input["resultTime"] && input["phenomenonTime"])
                input["resultTime"] = input["phenomenonTime"];
        return input;
    }
    // Override post to prepare datas before use super class
    async post(dataInput) {
        console.log(log_1.log.whereIam());
        if (dataInput)
            dataInput = await this.prepareInputResult(dataInput);
        if (dataInput["import"]) {
        }
        else
            return await super.post(dataInput);
    }
    // Override update to prepare datas before use super class
    async update(idInput, dataInput) {
        console.log(log_1.log.whereIam());
        if (dataInput)
            dataInput = await this.prepareInputResult(dataInput);
        if (dataInput)
            dataInput["validTime"] = await (0, helpers_1.getDBDateNow)(this.ctx.config);
        return await super.update(idInput, dataInput);
    }
}
exports.Observations = Observations;
