"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Users = void 0;
const common_1 = require("./common");
const logger_1 = require("../../logger");
const configuration_1 = require("../../configuration");
const helpers_1 = require("../../helpers");
const messages_1 = require("../../messages/");
const enums_1 = require("../../enums");
const constants_1 = require("../../constants");
const helpers_2 = require("../helpers");
const models_1 = require("../../models");
class Users extends common_1.Common {
    constructor(ctx) {
        console.log(logger_1.formatLog.whereIam());
        super(ctx);
    }
    // Override get all to return all users only if rights are good
    async getAll() {
        console.log(logger_1.formatLog.whereIam());
        if (this.ctx.user?.PDCUAS[enums_1.EnumUserRights.SuperAdmin] === true || this.ctx.user?.PDCUAS[enums_1.EnumUserRights.Admin] === true) {
            const temp = await (0, helpers_2.executeSqlValues)(configuration_1.serverConfig.getConfig(constants_1.ADMIN), `SELECT ${models_1.models.getSelectColumnList(models_1.models.DBAdmin(configuration_1.serverConfig.getConfig(constants_1.ADMIN)).Users)} FROM "user" ORDER BY "id"`);
            return this.formatReturnResult({
                body: (0, helpers_1.hidePassword)(temp),
            });
        }
        else
            this.ctx.throw(401, { code: 401, detail: messages_1.errors[401] });
    }
    // Override to creste a new config and load it 
    async post(dataInput) {
        console.log(logger_1.formatLog.whereIam());
        if (dataInput)
            return this.formatReturnResult({
                body: await configuration_1.serverConfig.addConfig(dataInput),
            });
    }
}
exports.Users = Users;
