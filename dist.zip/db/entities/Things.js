"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Things = void 0;
const logger_1 = require("../../logger");
const common_1 = require("./common");
// http://docs.opengeospatial.org/is/15-078r6/15-078r6.html#25
class Things extends common_1.Common {
    constructor(ctx) {
        console.log(logger_1.formatLog.whereIam());
        super(ctx);
    }
}
exports.Things = Things;
