"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Things = void 0;
/**
 * Things entity.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Things entity. -----------------------------------!");
const log_1 = require("../../log");
const common_1 = require("./common");
// http://docs.opengeospatial.org/is/15-078r6/15-078r6.html#25
class Things extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
}
exports.Things = Things;
