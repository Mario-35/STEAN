"use strict";
/**
 * Common class entity
 *f
 * @copyright 2020-present Inrae
 * @review 29-01-2024
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Common class entity -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.Common = void 0;
const index_1 = require("../../helpers/index");
const helpers_1 = require("../helpers");
const messages_1 = require("../../messages");
const log_1 = require("../../log");
// Common class
class Common {
    ctx;
    nextLinkBase;
    linkBase;
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        this.ctx = ctx;
        this.nextLinkBase = (0, helpers_1.removeKeyFromUrl)(`${this.ctx.decodedUrl.root}/${this.ctx.href.split(`${ctx.config.apiVersion}/`)[1]}`, ["top", "skip"]);
        this.linkBase = `${this.ctx.decodedUrl.root}/${this.constructor.name}`;
    }
    // Get a key value
    getKeyValue(input, key) {
        let result = undefined;
        if (input[key]) {
            result = input[key]["@iot.id"] ? input[key]["@iot.id"] : input[key];
            delete input[key];
        }
        return result;
    }
    // Get a list of key values
    getKeysValue(input, keys) {
        keys.forEach((key) => {
            const temp = this.getKeyValue(input, key);
            if (temp)
                return temp;
        });
        return undefined;
    }
    // Only for override
    formatDataInput(input) {
        return input;
    }
    // create a blank ReturnResult
    formatReturnResult(args) {
        console.log(log_1.log.whereIam());
        return {
            ...{
                id: undefined,
                nextLink: args.nextLink ? args.nextLink : undefined,
                prevLink: args.prevLink ? args.prevLink : undefined,
                body: undefined,
                total: undefined,
            },
            ...args,
        };
    }
    // Create the nextLink
    nextLink = (resLength) => {
        if (this.ctx.odata.limit < 1)
            return;
        const max = this.ctx.odata.limit > 0
            ? +this.ctx.odata.limit
            : +this.ctx.config.nb_page;
        if (resLength >= max)
            return `${encodeURI(this.nextLinkBase)}${this.nextLinkBase.includes("?") ? "&" : "?"}$top=${this.ctx.odata.limit}&$skip=${this.ctx.odata.skip + this.ctx.odata.limit}`;
    };
    // Create the prevLink
    prevLink = (resLength) => {
        if (this.ctx.odata.limit < 1)
            return;
        const prev = this.ctx.odata.skip - this.ctx.odata.limit;
        if (((this.ctx.config.nb_page && resLength >= this.ctx.config.nb_page) || this.ctx.odata.limit) && prev >= 0)
            return `${encodeURI(this.nextLinkBase)}${this.nextLinkBase.includes("?") ? "&" : "?"}$top=${this.ctx.odata.limit}&$skip=${prev}`;
    };
    // Return all items
    async getAll() {
        console.log(log_1.log.whereIam());
        // create query
        const sql = this.ctx.odata.getSql();
        // Return results
        if (sql)
            switch (this.ctx.odata.returnFormat) {
                case index_1.returnFormats.sql:
                    return this.formatReturnResult({ body: sql });
                case index_1.returnFormats.graph:
                    return await (0, helpers_1.executeSqlValues)(this.ctx.config, sql).then(async (res) => {
                        return (res[0].length > 0) ? this.formatReturnResult({ body: res[0] }) : this.formatReturnResult({ body: "nothing" });
                    });
                default:
                    return await (0, helpers_1.executeSqlValues)(this.ctx.config, sql).then(async (res) => {
                        return (res[0] > 0) ?
                            this.formatReturnResult({ id: isNaN(res[0][0]) ? undefined : +res[0], nextLink: this.nextLink(res[0]), prevLink: this.prevLink(res[0]), body: res[1], }) : this.formatReturnResult({ body: res[0] == 0 ? [] : res[0] });
                    }).catch((err) => this.ctx.throw(400, { code: 400, detail: err.message }));
            }
    }
    // Return one item
    async getSingle(_idInput) {
        console.log(log_1.log.whereIam());
        // create query
        const sql = this.ctx.odata.getSql();
        // Return results
        switch (this.ctx.odata.returnFormat) {
            case index_1.returnFormats.sql:
                return this.formatReturnResult({ body: sql });
            default:
                return await (0, helpers_1.executeSqlValues)(this.ctx.config, sql).then((res) => {
                    if (this.ctx.odata.query.select && this.ctx.odata.onlyValue === true)
                        return this.formatReturnResult({
                            body: String(res[this.ctx.odata.query.select[0] == "id" ? "@iot.id" : 0]),
                        });
                    if (res[0] > 0)
                        return this.formatReturnResult({
                            id: +res[0],
                            nextLink: this.nextLink(res[0]),
                            prevLink: this.prevLink(res[0]),
                            body: res[1][0],
                        });
                }).catch((err) => this.ctx.throw(400, { code: 400, detail: err }));
        }
    }
    // Execute multilines SQL in one query
    async addWultipleLines(dataInput) {
        console.log(log_1.log.whereIam());
        // stop save to log cause if datainput too big 
        if (this.ctx.log)
            this.ctx.log.datas = { datas: messages_1.infos.MultilinesNotSaved };
        // create queries
        const sqls = Object(dataInput).map((datas) => {
            const modifiedDatas = this.formatDataInput(datas);
            if (modifiedDatas) {
                const sql = this.ctx.odata.postSql(modifiedDatas);
                if (sql)
                    return sql;
            }
        });
        // return results
        const results = [];
        // execute query
        await (0, helpers_1.executeSqlValues)(this.ctx.config, sqls.join(";")).then((res) => results.push(res[0]))
            .catch((err) => {
            log_1.log.error(log_1.log.error(err));
            this.ctx.throw(400, { code: 400, detail: err["detail"] });
        });
        // Return results
        return this.formatReturnResult({
            body: results,
        });
    }
    // Post an item
    async post(dataInput) {
        console.log(log_1.log.whereIam());
        // Format datas
        dataInput = this.formatDataInput(dataInput);
        if (!dataInput)
            return;
        // create query
        const sql = this.ctx.odata.postSql(dataInput);
        // Return results
        if (sql)
            switch (this.ctx.odata.returnFormat) {
                case index_1.returnFormats.sql:
                    return this.formatReturnResult({ body: sql });
                default:
                    return await (0, helpers_1.executeSqlValues)(this.ctx.config, sql)
                        .then((res) => {
                        if (res[0]) {
                            if (res[0].duplicate)
                                this.ctx.throw(409, {
                                    code: 409,
                                    detail: `${this.constructor.name} already exist`,
                                    link: `${this.linkBase}(${[res[0].duplicate]})`,
                                });
                            return this.formatReturnResult({
                                body: res[0][0],
                                query: sql,
                            });
                        }
                    })
                        .catch((err) => {
                        const code = (0, messages_1.getErrorCode)(err, 400);
                        this.ctx.throw(code, { code: code, detail: err.message });
                    });
            }
    }
    // Update an item
    async update(idInput, dataInput) {
        console.log(log_1.log.whereIam());
        // Format datas
        dataInput = this.formatDataInput(dataInput);
        if (!dataInput)
            return;
        // create Query
        const sql = this.ctx.odata.patchSql(dataInput);
        // Return results
        if (sql)
            switch (this.ctx.odata.returnFormat) {
                case index_1.returnFormats.sql:
                    return this.formatReturnResult({ body: sql });
                default:
                    return await (0, helpers_1.executeSqlValues)(this.ctx.config, sql)
                        .then((res) => {
                        if (res[0]) {
                            return this.formatReturnResult({
                                body: res[0][0],
                                query: sql,
                            });
                        }
                    })
                        .catch((err) => {
                        const code = (0, messages_1.getErrorCode)(err, 400);
                        this.ctx.throw(code, { code: code, detail: err.message });
                    });
            }
    }
    // Delete an item
    async delete(idInput) {
        console.log(log_1.log.whereIam());
        // create Query
        const sql = `DELETE FROM ${(0, index_1.addDoubleQuotes)(this.ctx.model[this.constructor.name].table)} WHERE "id" = ${idInput} RETURNING id`;
        // Return results
        if (sql)
            switch (this.ctx.odata.returnFormat) {
                case index_1.returnFormats.sql:
                    return this.formatReturnResult({ body: sql });
                default:
                    return this.formatReturnResult({ id: await (0, helpers_1.executeSqlValues)(this.ctx.config, sql).then((res) => res[0]).catch(() => BigInt(0)) });
            }
    }
}
exports.Common = Common;
