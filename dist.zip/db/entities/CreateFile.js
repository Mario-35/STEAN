"use strict";
/**
 * CreateFile entity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- CreateFile entity -----------------------------------!");
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateFile = void 0;
const common_1 = require("./common");
const helpers_1 = require("../helpers");
const messages_1 = require("../../messages/");
const entities = __importStar(require("../entities/index"));
const helpers_2 = require("../../helpers");
const fs_1 = require("fs");
const stream_1 = require("stream");
const configuration_1 = require("../../configuration");
const log_1 = require("../../log");
class CreateFile extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
    streamCsvFileInPostgreSqlFileInDatastream = async (ctx, paramsFile) => {
        console.log(log_1.log.head("streamCsvFileInPostgreSqlFileInDatastream"));
        const headers = await (0, helpers_1.columnsNameFromCsv)(paramsFile.filename);
        if (!headers) {
            ctx.throw(400, {
                code: 400,
                detail: messages_1.errors.noHeaderCsv + paramsFile.filename,
            });
        }
        const createDataStream = async () => {
            const nameOfFile = paramsFile.filename.split("/").reverse()[0];
            const copyCtx = Object.assign({}, ctx.odata);
            const tempId = ctx.odata.id.toString();
            ctx.odata.entity = this.ctx.model.Datastreams.name;
            // IMPORTANT TO ADD instead update
            ctx.odata.id = "";
            ctx.odata.returnFormat = helpers_2.returnFormats.json;
            ctx.log = undefined;
            // @ts-ignore
            const objectDatastream = new entities[this.ctx.model.Datastreams.name](ctx);
            const myDatas = {
                name: `${this.ctx.model.Datastreams.name} import file ${nameOfFile}`,
                description: "Description in meta ?",
                observationType: "http://www.opengis.net/def/observation-type/ogc-omxml/2.0/swe-array-observation",
                Thing: { "@iot.id": tempId },
                unitOfMeasurement: {
                    name: headers.join(),
                    symbol: "csv",
                    definition: "https://www.rfc-editor.org/rfc/pdfrfc/rfc4180.txt.pdf",
                },
                ObservedProperty: {
                    name: `is Generik ${nameOfFile}`,
                    description: "KOIKE observe",
                    definition: "http://www.qudt.org/qudt/owl/1.0.0/quantity/Instances.html#AreaTemperature",
                },
                Sensor: {
                    name: `Nom du Kapteur${nameOfFile}`,
                    description: "Capte heures a la seconde",
                    encodingType: "application/pdf",
                    metadata: "https://time.com/datasheets/capteHour.pdf",
                },
            };
            try {
                return await objectDatastream.post(myDatas);
            }
            catch (error) {
                // ctx.odata.where = `"name" ~* '${nameOfFile}'`;
                ctx.odata.query.where.init(`"name" ~* '${nameOfFile}'`);
                const returnValueError = await objectDatastream.getAll();
                ctx.odata = copyCtx;
                if (returnValueError) {
                    returnValueError.body = returnValueError.body
                        ? returnValueError.body[0]
                        : {};
                    if (returnValueError.body)
                        await (0, helpers_1.executeSqlValues)(ctx.config, `DELETE FROM "${this.ctx.model.Observations.table}" WHERE "datastream_id" = ${returnValueError.body["@iot.id"]}`);
                    return returnValueError;
                }
            }
            finally {
                ctx.odata = copyCtx;
            }
        };
        const returnValue = await createDataStream();
        const controller = new AbortController();
        const readable = (0, fs_1.createReadStream)(paramsFile.filename);
        const cols = [];
        headers.forEach((value) => cols.push(`"${value}" varchar(255) NULL`));
        const createTable = `CREATE TABLE public."${paramsFile.tempTable}" (
        id serial4 NOT NULL,
        "date" varchar(255) NULL,
        "hour" varchar(255) NULL,
        ${cols}, 
        CONSTRAINT ${paramsFile.tempTable}_pkey PRIMARY KEY (id));`;
        await (0, helpers_1.executeSqlValues)(ctx.config, createTable);
        const writable = configuration_1.serverConfig.connection(ctx.config.name).unsafe(`COPY ${paramsFile.tempTable}  (${headers.join(",")}) FROM STDIN WITH(FORMAT csv, DELIMITER ';'${paramsFile.header})`).writable();
        return await new Promise(async (resolve, reject) => {
            readable
                .pipe((0, stream_1.addAbortSignal)(controller.signal, await writable))
                .on('close', async () => {
                // TODO DATES !!!!
                const sql = `INSERT INTO "${this.ctx.model.Observations.table}" 
                    ("datastream_id", "phenomenonTime", "resultTime", "result") 
                    SELECT '${String(returnValue.body["@iot.id"])}', '2021-09-17T14:56:36+02:00', '2021-09-17T14:56:36+02:00', json_build_object('value',ROW_TO_JSON(p)) FROM (SELECT * FROM ${paramsFile.tempTable}) AS p`;
                await configuration_1.serverConfig.connection(this.ctx.config.name).unsafe(sql);
                resolve(returnValue["body"]);
            })
                .on('error', (err) => {
                log_1.log.errorMsg('ABORTED-STREAM');
                reject(err);
            });
            // await finished(stream);
        });
    };
    async getAll() {
        this.ctx.throw(400, { code: 400 });
    }
    async getSingle(idInput) {
        console.log(log_1.log.whereIam(idInput));
        this.ctx.throw(400, { code: 400 });
    }
    async post(dataInput) {
        console.log(log_1.log.whereIam(dataInput));
        if (this.ctx.datas) {
            const myColumns = [];
            return this.formatReturnResult({
                body: await this.streamCsvFileInPostgreSqlFileInDatastream(this.ctx, {
                    tempTable: `temp${Date.now().toString()}`,
                    filename: this.ctx.datas["file"],
                    columns: myColumns,
                    header: ", HEADER",
                    stream: [], // only for interface
                }),
            });
        }
        else {
            log_1.log.errorMsg("No Datas");
            return;
        }
    }
}
exports.CreateFile = CreateFile;
