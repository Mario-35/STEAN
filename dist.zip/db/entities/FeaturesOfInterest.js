"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FeaturesOfInterest = void 0;
/**
 * FeaturesOfInterest entity.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- FeaturesOfInterest entity. -----------------------------------!");
const logger_1 = require("../../logger");
const common_1 = require("./common");
class FeaturesOfInterest extends common_1.Common {
    constructor(ctx) {
        console.log(logger_1.formatLog.whereIam());
        super(ctx);
    }
}
exports.FeaturesOfInterest = FeaturesOfInterest;
