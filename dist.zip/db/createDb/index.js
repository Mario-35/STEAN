"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.testDatas = exports.createDatabase = void 0;
/**
 * createDatabase.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- createDatabase. -----------------------------------!");
var createDatabase_1 = require("./createDatabase");
Object.defineProperty(exports, "createDatabase", { enumerable: true, get: function () { return createDatabase_1.createDatabase; } });
var tests_1 = require("./tests");
Object.defineProperty(exports, "testDatas", { enumerable: true, get: function () { return tests_1.testDatas; } });
