"use strict";
/**
 * createSTDB
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- createSTDB -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.createDatabase = void 0;
const helpers_1 = require("../helpers");
const configuration_1 = require("../../configuration");
const helpers_2 = require("../../helpers");
const constants_1 = require("../constants");
const enums_1 = require("../../enums");
const triggers_1 = require("./triggers");
const models_1 = require("../../models");
const log_1 = require("../../log");
const createRole_1 = require("../helpers/createRole");
const constants_2 = require("../../constants");
const createDatabase = async (configName) => {
    console.log(log_1.log.head("createDatabase", configName));
    // init result
    const config = configuration_1.serverConfig.getConfig(configName).pg;
    const returnValue = { "Start create Database": config.database };
    const adminConnection = configuration_1.serverConfig.adminConnection();
    // Test connection Admin
    if (!adminConnection) {
        returnValue["DROP Error"] = "No Admin connection";
        return returnValue;
    }
    // create blank DATABASE
    await adminConnection.unsafe(`CREATE DATABASE ${config.database}`)
        .then(async () => {
        returnValue[`Create Database`] = `${config.database} ${"\u2714\uFE0F\uFE0F" /* EChar.ok */}`;
        // create USER if not exist
        await adminConnection.unsafe(`SELECT COUNT(*) FROM pg_user WHERE usename = ${(0, helpers_2.addSimpleQuotes)(config.user)};`)
            .then(async (res) => {
            if (res[0].count == 0) {
                returnValue[`CREATE ROLE ${config.user}`] = await adminConnection.unsafe(`CREATE ROLE ${config.user} WITH PASSWORD ${(0, helpers_2.addSimpleQuotes)(config.password)} ${constants_1._RIGHTS}`)
                    .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
                    .catch((err) => err.message);
            }
            else {
                await adminConnection.unsafe(`ALTER ROLE ${config.user} WITH PASSWORD ${(0, helpers_2.addSimpleQuotes)(config.password)}  ${constants_1._RIGHTS}`)
                    .then(() => {
                    returnValue[`Create/Alter ROLE`] = `${config.user} ${"\u2714\uFE0F\uFE0F" /* EChar.ok */}`;
                })
                    .catch((err) => {
                    log_1.log.errorMsg(err);
                });
            }
        });
    }).catch((err) => {
        log_1.log.errorMsg(err);
    });
    const dbConnection = configuration_1.serverConfig.connection(configName);
    if (!dbConnection) {
        returnValue["DROP Error"] = `No DB connection ${"\u274C" /* EChar.notOk */}`;
        return returnValue;
    }
    // create postgis
    returnValue[`Create postgis`] = await dbConnection.unsafe('CREATE EXTENSION IF NOT EXISTS postgis')
        .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
        .catch((err) => err.message);
    // create tablefunc
    returnValue[`Create tablefunc`] = await dbConnection.unsafe('CREATE EXTENSION IF NOT EXISTS tablefunc')
        .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
        .catch((err) => err.message);
    // Get complete model
    const DB = models_1.models.DBFull(configName);
    // loop to create each table
    await (0, helpers_2.asyncForEach)(Object.keys(DB), async (keyName) => {
        const res = await (0, helpers_1.createTable)(configName, DB[keyName], undefined);
        Object.keys(res).forEach((e) => log_1.log.create(e, res[e]));
    });
    // loop to create each table
    await (0, helpers_2.asyncForEach)((0, triggers_1.triggers)(configName), async (query) => {
        const name = query.split(" */")[0].split("/*")[1].trim();
        await configuration_1.serverConfig.connection(configName).unsafe(query)
            .then(() => {
            log_1.log.create(name, "\u2714\uFE0F\uFE0F" /* EChar.ok */);
        }).catch((error) => {
            console.log(error);
            process.exit(111);
        });
    });
    // If only numeric extension
    if (configuration_1.serverConfig.getConfig(configName).extensions.includes(enums_1.EExtensions.highPrecision)) {
        await dbConnection.unsafe(`ALTER TABLE ${(0, helpers_2.addDoubleQuotes)(DB.Observations.table)} ALTER COLUMN 'result' TYPE float4 USING null;`)
            .catch((error) => {
            log_1.log.errorMsg(error);
            return error;
        });
        await dbConnection.unsafe(`ALTER TABLE ${(0, helpers_2.addDoubleQuotes)(DB.HistoricalLocations.table)} ALTER COLUMN '_result' TYPE float4 USING null;`)
            .catch((error) => {
            log_1.log.errorMsg(error);
            return error;
        });
    }
    returnValue[`Create Role`] = await (0, createRole_1.createRole)(configuration_1.serverConfig.getConfig(constants_2.ADMIN))
        .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
        .catch((err) => err.message);
    returnValue[`Create user`] = await (0, helpers_1.createUser)(configuration_1.serverConfig.getConfig(constants_2.ADMIN))
        .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
        .catch((err) => err.message);
    await dbConnection.unsafe(`SELECT COUNT(*) FROM pg_user WHERE usename = ${(0, helpers_2.addSimpleQuotes)(config.user)};`)
        .then(() => { returnValue["ALL finished ..."] = "\u2714\uFE0F\uFE0F" /* EChar.ok */; })
        .catch((err) => err.message);
    return returnValue;
};
exports.createDatabase = createDatabase;
