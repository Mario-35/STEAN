 #/
 # Stean Install Bash.
 #
 # @copyright 2024-present Inrae
 # @author mario.adam@inrae.fr
 # version 0.1
 #
 #/

clear
APIDEST=api
APIBak=apiBak
FILEAPP=./$APIDEST/index.js
FILEDIST=./dist.zip
FILEDISTOLD=./distOld.zip
FILEKEY=./$APIDEST/configuration/.key
FILECONFIG=./$APIDEST/configuration/configuration.json

# Script to install Node.js using Node on Ubuntu without sudo

echo "Installing Stean..."

# Function to install Node
install_node() {
    echo "Installing Node..."
    sudo apt install nodejs
}

# Function to install postgresql-postgis
install_pg() {
    echo "Installing postgresql-postgis ..."
    sudo apt install postgis postgresql-14-postgis-3
}

# Function to install pm2
install_pm2() {
    echo "Installing pm2..."
    sudo npm install pm2@latest -g
}

# Function to install unzip
install_unzip() {
    echo "Installing unzip..."
    sudo apt-get install unzip
}

save_dist() {
    if [ -f "$FILEDIST" ]; then
        rm $FILEDISTOLD
        mv $FILEDIST $FILEDISTOLD
    fi
}

# Function to get stean
download_stean() {
    echo "Downloading stean..."
    save_dist
    curl -o $FILEDIST -L https://github.com/Mario-35/STEAN/raw/main/dist.zip
}

# Function to create run.sh
create_run() {
    echo "Create run.sh"
    cp ./$APIDEST/scripts/run.sh .
    sudo chmod -R 777 run.sh
}

# Function to install stean
install_stean() {
    stop_stean
    # remove bak
    rm -r $APIBak
    # save actual to bak
    mv $APIDEST $APIBak
    # unzip actual
    unzip -qq $FILEDIST -d $APIDEST/  
    # Save config
    if [ -f ./$APIBak/configuration/configuration.json ]; then
        echo "confifuration exist."
        cp ./$APIBak/configuration/configuration.json ./$APIDEST/configuration/configuration.json
    fi
    # Save key
    if [ -f ./$APIBak/configuration/.key ]; then
        echo "Key exists."
        cp ./$APIBak/configuration/.key ./$APIDEST/configuration/.key
    fi
    save_dist
    create_run
    cd $APIDEST
    npm install --silent --omit=dev
    cd ..
}

stop_stean() {
    pm2 stop index
    pm2 kill
}

#------------------------------------------------------------------
#|                        START                                   |
#------------------------------------------------------------------

# Check if PostgreSQL  is installed
if ! command -v psql --version &> /dev/null
then
    echo "PostgreSQL is Not installed."
    install_pg
    if ! command -v psql --version &> /dev/null
    then
        exit
    fi
else
    echo "PostgreSQL is installed."
fi


# Check if Node is installed
if ! command -v node &> /dev/null
then
    install_node
else
    echo "Node is already installed."
fi

# Check if pm2 is installed
if ! command -v pm2 &> /dev/null
then
    install_pm2
else
    echo "pm2 is already installed."
fi

# Check if unzip is installed
if ! command -v unzip &> /dev/null
then
    install_unzip
else
    echo "unzip is already installed."
fi


if [ -f $FILEDIST ];
then
    echo "$FILEDIST is already present."
    while true; do
        read -p "Do you wish to use it " yn
        case $yn in
            [Yy]* ) break;;
            [Nn]* ) download_stean; break;;
            * ) echo "Please answer yes or no.";;
        esac
    done
else
    download_stean
fi

install_stean
sh ./run.sh