"use strict";
/**
 * Log class
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Log class -----------------------------------!");
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.log = void 0;
const util_1 = __importDefault(require("util"));
const constants_1 = require("../constants");
const helpers_1 = require("../helpers");
// class to logCreate configs environements
class Log {
    debugFile = false;
    line = (nb) => "=".repeat(nb);
    logAll = (input, colors) => typeof input === "object" ? util_1.default.inspect(input, { showHidden: false, depth: null, colors: colors || false, }) : input;
    separator = (title, nb) => `${(0, constants_1.color)(32 /* EColor.Green */)} ${this.line(nb)} ${(0, constants_1.color)(33 /* EColor.Yellow */)} ${title} ${(0, constants_1.color)(32 /* EColor.Green */)} ${this.line(nb)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    logCleInfos = (cle, infos) => `${(0, constants_1.color)(32 /* EColor.Green */)} ${cle} ${(0, constants_1.color)(37 /* EColor.White */)} : ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${this.logAll(infos, this.debugFile)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    errorMsg(...data) {
        if ((0, helpers_1.isTest)())
            return;
        return util_1.default.format.apply(null, data);
    }
    booting(cle, value) {
        return `\x1b[${36 /* EColor.Cyan */}m ${cle} \x1b[${37 /* EColor.White */}m ${value}\x1b[${0 /* EColor.Reset */}m`;
    }
    create(cle, value) {
        return `${(0, constants_1.color)(37 /* EColor.White */)} -->${(0, constants_1.color)(36 /* EColor.Cyan */)} ${cle} ${(0, constants_1.color)(37 /* EColor.White */)} ${(0, constants_1.showAll)(value)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    message(cle, infos) {
        return `${(0, constants_1.color)(33 /* EColor.Yellow */)} ${cle} ${(0, constants_1.color)(37 /* EColor.White */)}:${(0, constants_1.color)(36 /* EColor.Cyan */)} ${(0, constants_1.showAll)(infos)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    query(sql) {
        if (constants_1._DEBUG)
            return `${(0, constants_1.color)(93 /* EColor.Code */)}${"=".repeat(5)}[ Query Start ]${"=".repeat(5)}\n${(0, constants_1.color)(92 /* EColor.Sql */)} ${(0, constants_1.showAll)(sql)}\n${(0, constants_1.color)(92 /* EColor.Sql */)}${(0, constants_1.color)(93 /* EColor.Code */)}\n${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    queryError(query, error) {
        return `${(0, constants_1.color)(32 /* EColor.Green */)} ${"=".repeat(15)} ${(0, constants_1.color)(36 /* EColor.Cyan */)} ERROR ${(0, constants_1.color)(32 /* EColor.Green */)} ${"=".repeat(15)}${(0, constants_1.color)(0 /* EColor.Reset */)}
      ${(0, constants_1.color)(31 /* EColor.Red */)} ${error} ${(0, constants_1.color)(34 /* EColor.Blue */)}
      ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${(0, constants_1.showAll)(query, false)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    // Usefull for id not used ;)
    oData(infos) {
        if (infos && constants_1._DEBUG) {
            const tmp = `${(0, constants_1.color)(37 /* EColor.White */)} ${infos} ${(0, constants_1.color)(0 /* EColor.Reset */)}`;
            return `${(0, constants_1.color)(31 /* EColor.Red */)} ${"=".repeat(8)} ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${new Error().stack?.split("\n")[2].trim().split("(")[0].split("at ")[1].trim()} ${tmp}${(0, constants_1.color)(31 /* EColor.Red */)} ${"=".repeat(8)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
        }
        return infos;
    }
    // log an object or json
    object(title, input) {
        if (constants_1._DEBUG) {
            const res = [this.head(title)];
            Object.keys(input).forEach((cle) => {
                res.push(this.logCleInfos("  " + cle, input[cle]));
            });
            return res.join("\n");
        }
    }
    url(link) {
        return `${"\uD83C\uDF0D" /* EChar.web */} ${(0, constants_1.color)(39 /* EColor.Default */)} : ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${link}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    head(cle, infos) {
        if (constants_1._DEBUG)
            return infos ? `${(0, constants_1.color)(32 /* EColor.Green */)} ${this.line(12)} ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${cle} ${(0, constants_1.color)(37 /* EColor.White */)} ${this.logAll(infos, this.debugFile)} ${(0, constants_1.color)(32 /* EColor.Green */)} ${this.line(12)}${(0, constants_1.color)(0 /* EColor.Reset */)}` : this.separator(cle, 12);
    }
    infos(cle, input) {
        if (constants_1._DEBUG)
            return `${this.separator(cle, 30)} ${(0, constants_1.color)(33 /* EColor.Yellow */)} ${this.logAll(input, true)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    debug(cle, infos) {
        if (constants_1._DEBUG)
            return `${(0, constants_1.color)(32 /* EColor.Green */)} ${cle} ${(0, constants_1.color)(37 /* EColor.White */)} : ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${this.logAll(infos, this.debugFile)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    result(cle, infos) {
        if (constants_1._DEBUG)
            return `${(0, constants_1.color)(32 /* EColor.Green */)}     >>${(0, constants_1.color)(30 /* EColor.Black */)} ${cle} ${(0, constants_1.color)(39 /* EColor.Default */)} : ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${this.logAll(infos, this.debugFile)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    error(cle, infos) {
        return infos
            ? `${(0, constants_1.color)(31 /* EColor.Red */)} ${cle} ${(0, constants_1.color)(34 /* EColor.Blue */)} : ${(0, constants_1.color)(33 /* EColor.Yellow */)} ${this.logAll(infos, this.debugFile)}${(0, constants_1.color)(0 /* EColor.Reset */)}`
            : `${(0, constants_1.color)(31 /* EColor.Red */)} Error ${(0, constants_1.color)(34 /* EColor.Blue */)} : ${(0, constants_1.color)(33 /* EColor.Yellow */)} ${this.logAll(cle)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    whereIam(infos) {
        const tmp = infos ? `${(0, constants_1.color)(39 /* EColor.Default */)} ${infos} ${(0, constants_1.color)(0 /* EColor.Reset */)}` : '';
        if (constants_1._DEBUG)
            return `${(0, constants_1.color)(31 /* EColor.Red */)} ${this.line(4)} ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${new Error().stack?.split("\n")[2].trim().split("(")[0].split("at ")[1].trim()} ${tmp}${(0, constants_1.color)(31 /* EColor.Red */)} ${this.line(4)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    test() {
        return `${(0, constants_1.color)(33 /* EColor.Yellow */)} ${this.line(4)} ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${new Error().stack?.split("\n")[2].trim().split(" ")[1]} ${(0, constants_1.color)(33 /* EColor.Yellow */)} ${this.line(4)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
}
exports.log = new Log();
