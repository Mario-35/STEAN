"use strict";
/**
 * Log class
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Log class -----------------------------------!");
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.log = void 0;
const fs_1 = __importDefault(require("fs"));
const util_1 = __importDefault(require("util"));
const constants_1 = require("../constants");
const helpers_1 = require("../helpers");
// class to logCreate configs environements
class Log {
    static logFile;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    errorMsg(...data) {
        if ((0, helpers_1.isTest)())
            return;
        Log.logFile = fs_1.default.createWriteStream(constants_1._ERRORFILE, { flags: "a" });
        Log.logFile.write(util_1.default.format.apply(null, data).replace(/\u001b[^m]*?m/g, "") + "\n");
        process.stdout.write(util_1.default.format.apply(null, data) + "\n");
        return data;
    }
    booting(cle, value) {
        process.stdout.write(`\x1b[${36 /* EColor.FgCyan */}m ${cle} \x1b[${37 /* EColor.FgWhite */}m ${value}\x1b[${0 /* EColor.Reset */}m\n`);
    }
    error(cle, infos) {
        process.stdout.write(`${(0, constants_1.color)(31 /* EColor.FgRed */)} ${cle} ${(0, constants_1.color)(34 /* EColor.FgBlue */)} : ${(0, constants_1.color)(33 /* EColor.FgYellow */)} ${(0, constants_1.showAll)(infos, true)}${(0, constants_1.color)(0 /* EColor.Reset */)}\n`);
    }
    create(cle, value) {
        process.stdout.write(`${(0, constants_1.color)(37 /* EColor.FgWhite */)} -->${(0, constants_1.color)(36 /* EColor.FgCyan */)} ${cle} ${(0, constants_1.color)(37 /* EColor.FgWhite */)} ${(0, constants_1.showAll)(value)}${(0, constants_1.color)(0 /* EColor.Reset */)}\n`);
    }
    message(cle, infos) {
        return `${(0, constants_1.color)(33 /* EColor.FgYellow */)} ${cle} ${(0, constants_1.color)(37 /* EColor.FgWhite */)}:${(0, constants_1.color)(36 /* EColor.FgCyan */)} ${(0, constants_1.showAll)(infos)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    query(sql) {
        if (constants_1._DEBUG)
            process.stdout.write(`${(0, constants_1.color)(33 /* EColor.FgYellow */)}${"=".repeat(20)}[ Query ]${"=".repeat(20)}\n${(0, constants_1.color)(36 /* EColor.FgCyan */)} ${(0, constants_1.showAll)(sql)}${(0, constants_1.color)(0 /* EColor.Reset */)}\n`);
    }
    queryError(query, error) {
        process.stdout.write(`${(0, constants_1.color)(32 /* EColor.FgGreen */)} ${"=".repeat(15)} ${(0, constants_1.color)(36 /* EColor.FgCyan */)} ERROR ${(0, constants_1.color)(32 /* EColor.FgGreen */)} ${"=".repeat(15)}${(0, constants_1.color)(0 /* EColor.Reset */)}
      ${(0, constants_1.color)(31 /* EColor.FgRed */)} ${error} ${(0, constants_1.color)(34 /* EColor.FgBlue */)}
      ${(0, constants_1.color)(36 /* EColor.FgCyan */)} ${(0, constants_1.showAll)(query, false)}${(0, constants_1.color)(0 /* EColor.Reset */)}`);
    }
    // Usefull for id not used ;)
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    oData(infos) {
        if (infos && constants_1._DEBUG) {
            const tmp = `${(0, constants_1.color)(39 /* EColor.FgFadeWhite */)} ${infos} ${(0, constants_1.color)(0 /* EColor.Reset */)}`;
            process.stdout.write(`${(0, constants_1.color)(31 /* EColor.FgRed */)} ${"=".repeat(8)} ${(0, constants_1.color)(36 /* EColor.FgCyan */)} ${new Error().stack?.split("\n")[2].trim().split("(")[0].split("at ")[1].trim()} ${tmp}${(0, constants_1.color)(31 /* EColor.FgRed */)} ${"=".repeat(8)}${(0, constants_1.color)(0 /* EColor.Reset */)}`);
        }
        return infos;
    }
    init() {
        console.log(this.message("Log", "ready " + constants_1._OK));
    }
}
exports.log = new Log();
