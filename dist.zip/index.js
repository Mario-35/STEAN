"use strict";
/**
 * Index of The API.
 *
 * @copyright 2020-present Inrae
 * @review 29-01-2024
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Index of The API. -----------------------------------!");
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.server = exports.app = void 0;
const path_1 = __importDefault(require("path"));
const koa_1 = __importDefault(require("koa"));
const koa_bodyparser_1 = __importDefault(require("koa-bodyparser"));
const koa_logger_1 = __importDefault(require("koa-logger"));
const koa_helmet_1 = __importDefault(require("koa-helmet"));
const koa_compress_1 = __importDefault(require("koa-compress"));
const koa_json_1 = __importDefault(require("koa-json"));
const cors_1 = __importDefault(require("@koa/cors"));
const koa_static_1 = __importDefault(require("koa-static"));
const constants_1 = require("./constants");
const koa_favicon_1 = __importDefault(require("koa-favicon"));
const zlib_1 = require("zlib");
const log_1 = require("./log");
const routes_1 = require("./routes/");
const configuration_1 = require("./configuration");
const models_1 = require("./models");
const helpers_1 = require("./helpers");
const helper_1 = require("./routes/helper");
// new koa server https://koajs.com/
exports.app = new koa_1.default();
exports.app.use((0, koa_favicon_1.default)(__dirname + '/favicon.ico'));
// add public folder [static]
exports.app.use((0, koa_static_1.default)(path_1.default.join(__dirname, "/apidoc")));
// helmet protection https://github.com/venables/koa-helmet
exports.app.use(koa_helmet_1.default.contentSecurityPolicy({ directives: constants_1.HELMET_CONFIG }));
// bodybarser https://github.com/koajs/bodyparser
exports.app.use((0, koa_bodyparser_1.default)({ enableTypes: ["json", "text", "form"] }));
exports.app.use((0, koa_compress_1.default)({
    filter: function (content_type) {
        return (/json/i.test(content_type) || /text/i.test(content_type));
    },
    threshold: 1024,
    gzip: {
        flush: zlib_1.constants.Z_NO_FLUSH,
        level: zlib_1.constants.Z_BEST_COMPRESSION
    }
}));
// router
exports.app.use(routes_1.routerHandle);
// logger https://github.com/koajs/logger
if (!(0, helpers_1.isTest)())
    exports.app.use((0, koa_logger_1.default)((str) => process.stdout.write(`${new Date().toLocaleString()}${str + "\n"}`)));
// add json capabilities to KOA server
exports.app.use((0, koa_json_1.default)());
// add cors capabilities to KOA server
exports.app.use((0, cors_1.default)());
// free routes
exports.app.use(routes_1.unProtectedRoutes.routes());
// app key
exports.app.use((ctx, next) => {
    ctx.state.secret = constants_1.APP_KEY;
    ctx.body = ctx.request.body;
    return next();
});
// authenticated routes
exports.app.use(routes_1.protectedRoutes.routes());
// Initialisation of models
models_1.models.init();
// Initialisation of custom logs
log_1.log.init();
// Start server initialisaion
exports.server = (0, helpers_1.isTest)()
    ? exports.app.listen(configuration_1.serverConfig.getConfig(constants_1.TEST).port, async () => {
        await configuration_1.serverConfig
            .connection(constants_1.ADMIN) `${(0, helper_1.sqlStopDbName)('test')}`
            .then(async () => {
            await configuration_1.serverConfig.connection(constants_1.ADMIN) `DROP DATABASE IF EXISTS test`;
            process.stdout.write(`DROP DATABASE IF EXISTS test\n`);
        });
        console.log(log_1.log.message(`${constants_1.APP_NAME} version : ${constants_1.APP_VERSION}`, "ready " + constants_1._OK));
    })
    : configuration_1.serverConfig.init();
