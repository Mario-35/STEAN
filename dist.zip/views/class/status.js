"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.Status=void 0;const configuration_1=require("../../configuration"),enums_1=require("../../enums"),core_1=require("./core");class Status extends core_1.CoreHtmlView{constructor(e,t){super(e),this.status(e,t)}status(e,t){var s=configuration_1.serverConfig.getConfigNameFromDatabase(t.database),a=this.ctx.decodedUrl.linkbase+"/"+this.ctx.config.apiVersion,e=e.config.extensions.includes(enums_1.EExtensions.users);this._HTMLResult=[`<!DOCTYPE html>
        <html> 
            ${this.head("Status","user")}
            <body>
                <div class="login-wrap">
                    <div class="login-html">
                        ${this.title("Status")}
                        <h3>Username : ${t.username}</h3> 
                        <h3>Hosting : ${"all"==t.database?"all":s?configuration_1.serverConfig.getConfig(s).pg.host:"Not Found"}</h3>
                        <h3>Database : ${t.database}</h3>
                        <h3>Status : ${!(t.id&&0<t.id)&&e?"❌":"✔️️"}</h3> 
                        <h3>Post : ${!0!==t.canPost&&e?"❌":"✔️️"}</h3>
                        <h3>Delete : ${!0!==t.canDelete&&e?"❌":"✔️️"}</h3>
                        <h3>Create User: ${!0!==t.canCreateUser&&e?"❌":"✔️️"}</h3>
                        <h3>Create Service : ${!0!==t.canCreateDb&&e?"❌":"✔️️"}</h3>
                        <h3>Admin : ${!0!==t.admin&&e?"❌":"✔️️"}</h3>
                        <h3>Super admin : ${!0!==t.superAdmin&&e?"❌":"✔️️"}</h3>
                        ${this.foot([{href:a+"/Logout",class:"button-logout",name:"Logout"},{href:a+"/Query",class:"button-query",name:"Query"}])}
                    </div>
                </div>
            </body>
        </html>`]}}exports.Status=Status;