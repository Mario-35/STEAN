"use strict";
/**
 * HTML Views Status for API
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- HTML Views Status for API -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.Status = void 0;
const configuration_1 = require("../../configuration");
const constants_1 = require("../../constants");
const enums_1 = require("../../enums");
const core_1 = require("./core");
class Status extends core_1.CoreHtmlView {
    constructor(ctx, datas) {
        super(ctx);
        this.status(ctx, datas);
    }
    status(ctx, user) {
        const config = configuration_1.serverConfig.getConfigNameFromDatabase(user.database);
        const url = `${this.ctx.decodedUrl.linkbase}/${this.ctx.config.apiVersion}`;
        const sec = ctx.config.extensions.includes(enums_1.EnumExtensions.users);
        this._HTMLResult = [`<!DOCTYPE html>
        <html> 
            ${this.head("Status", "user")}
            <body>
                <div class="login-wrap">
                    <div class="login-html">
                        ${this.title("Status")}
                        <h3>Username : ${user.username}</h3> 
                        <h3>Hosting : ${user.database == "all" ? "all" : config ? configuration_1.serverConfig.getConfig(config).pg.host : "Not Found"}</h3>
                        <h3>Database : ${user.database}</h3>
                        <h3>Status : ${user.id && user.id > 0 ? constants_1._OK : !sec ? constants_1._OK : constants_1._NOTOK}</h3> 
                        <h3>Post : ${user.canPost === true ? constants_1._OK : !sec ? constants_1._OK : constants_1._NOTOK}</h3>
                        <h3>Delete : ${user.canDelete === true ? constants_1._OK : !sec ? constants_1._OK : constants_1._NOTOK}</h3>
                        <h3>Create User: ${user.canCreateUser === true ? constants_1._OK : !sec ? constants_1._OK : constants_1._NOTOK}</h3>
                        <h3>Create Service : ${user.canCreateDb === true ? constants_1._OK : !sec ? constants_1._OK : constants_1._NOTOK}</h3>
                        <h3>Admin : ${user.admin === true ? constants_1._OK : !sec ? constants_1._OK : constants_1._NOTOK}</h3>
                        <h3>Super admin : ${user.superAdmin === true ? constants_1._OK : !sec ? constants_1._OK : constants_1._NOTOK}</h3>
                        ${this.foot([
                { href: `${url}/Logout`, class: "button-logout", name: "Logout" },
                { href: `${url}/Query`, class: "button-query", name: "Query" }
            ])}
                    </div>
                </div>
            </body>
        </html>`];
    }
    ;
}
exports.Status = Status;
