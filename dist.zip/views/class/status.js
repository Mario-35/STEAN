"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.Status=void 0;const configuration_1=require("../../configuration"),constants_1=require("../../constants"),enums_1=require("../../enums"),core_1=require("./core");class Status extends core_1.CoreHtmlView{constructor(t,s){super(t),this.status(t,s)}status(t,s){var e=configuration_1.serverConfig.getConfigNameFromDatabase(s.database),n=this.ctx.decodedUrl.linkbase+"/"+this.ctx.config.apiVersion,t=t.config.extensions.includes(enums_1.EnumExtensions.users);this._HTMLResult=[`<!DOCTYPE html>
        <html> 
            ${this.head("Status","user")}
            <body>
                <div class="login-wrap">
                    <div class="login-html">
                        ${this.title("Status")}
                        <h3>Username : ${s.username}</h3> 
                        <h3>Hosting : ${"all"==s.database?"all":e?configuration_1.serverConfig.getConfig(e).pg.host:"Not Found"}</h3>
                        <h3>Database : ${s.database}</h3>
                        <h3>Status : ${!(s.id&&0<s.id)&&t?constants_1._NOTOK:constants_1._OK}</h3> 
                        <h3>Post : ${!0!==s.canPost&&t?constants_1._NOTOK:constants_1._OK}</h3>
                        <h3>Delete : ${!0!==s.canDelete&&t?constants_1._NOTOK:constants_1._OK}</h3>
                        <h3>Create User: ${!0!==s.canCreateUser&&t?constants_1._NOTOK:constants_1._OK}</h3>
                        <h3>Create Service : ${!0!==s.canCreateDb&&t?constants_1._NOTOK:constants_1._OK}</h3>
                        <h3>Admin : ${!0!==s.admin&&t?constants_1._NOTOK:constants_1._OK}</h3>
                        <h3>Super admin : ${!0!==s.superAdmin&&t?constants_1._NOTOK:constants_1._OK}</h3>
                        ${this.foot([{href:n+"/Logout",class:"button-logout",name:"Logout"},{href:n+"/Query",class:"button-query",name:"Query"}])}
                    </div>
                </div>
            </body>
        </html>`]}}exports.Status=Status;