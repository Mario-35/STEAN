"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.UserEdit=void 0;const core_1=require("./core");class UserEdit extends core_1.CoreHtmlView{constructor(e,t){super(e),this.userEdit(t)}userEdit=e=>{var t,d=e.body;return`<!DOCTYPE html>
              <html>
              ${this.head("Edit","user")}    
              <body>
                  <div class="login-wrap">
                    <div class="login-html">
                      <div class="login-form">
                        <form action="/user" method="post">
                            <input id="id" name="id" type="hidden" class="input"value="${d.id}">
                            ${this.addTextInput({name:"username",label:"Username",value:d.username||""})}
                            ${this.addTextInput({name:"email",label:"Email address",value:e.body&&e.body.email?e.body.email:"",alert:(t="email",e.why&&e.why[t]?`<div class="alert">${e.why[t]}</div>`:""),toolType:"A valid email address"})}
                            ${this.addTextInput({name:"database",label:"Database",value:d.database||""})}
                            <table>
                              <tbody>
                                <tr>
                                  <td>${this.addCheckBox({name:"canPost",checked:d.canPost})}</td>
                                  <td>${this.addCheckBox({name:"canDelete",checked:d.canDelete})}</td>
                                </tr>
                                <tr>
                                  <td>${this.addCheckBox({name:"canCreateUser",checked:d.canCreateUser})}</td>
                                  <td>${this.addCheckBox({name:"canCreateDb",checked:d.canCreateDb})}</td>
                                </tr>
                                <tr>
                                  <td>${this.addCheckBox({name:"admin",checked:d.admin})}</td>
                                  <td>${this.addCheckBox({name:"superAdmin",checked:d.superAdmin})}</td>
                                </tr>
                              </tbody>
                            </table>
                            <div class="group">
                              <input type="submit" class="button" value="Update infos">
                            </div>
                        </form>
                      </div>
                    </div>
                  </div>
              </body>
          </html>`}}exports.UserEdit=UserEdit;