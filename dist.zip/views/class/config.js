"use strict";
/**
 * HTML Views First for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- HTML Views First for API. -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.Config = void 0;
const enums_1 = require("../../enums");
const core_1 = require("./core");
class Config extends core_1.CoreHtmlView {
    constructor(ctx, datas) {
        super(ctx);
        this.first(datas);
    }
    first(datas) {
        datas.url = '/Configs';
        const alert = (name) => {
            return datas.why && datas.why[name] ? `<div class="alert">${datas.why[name]}</div>` : "";
        };
        this._HTMLResult = [`
          <!DOCTYPE html>
            <html>
              ${this.head("Login", "user")}    
            <body>
            <div class="login-wrap">
            <div class="login-html"> ${this.title(this.ctx.config.name)}
                    <input  id="tab-1" 
                            type="radio" 
                            name="tab" 
                            class="sign-in" checked>
                    <label for="tab-1" class="tab">Service</label>
                    <input  id="tab-2" 
                            type="radio" 
                            name="tab" 
                            class="sign-up">
                    <label for="tab-2" class="tab">Options</label>
                    <div class="login-form">
                      <form action="${datas.url}" method="patch">
                        <div class="sign-in-htm">
                        ${this.addTextInput({ name: "apiversion", label: "Version", value: datas.body && datas.body.apiversion || this.ctx.config.apiVersion, alert: alert("apiversion"), toolType: Object.values(enums_1.EVersion).join() })}
                        ${this.addTextInput({ name: "date_format", label: "Date format", value: datas.body && datas.body.date_format || this.ctx.config.date_format, alert: alert("date_format"), toolType: "Host must be at least 2 words" })}
                        ${this.addTextInput({ name: "webSite", label: "Web Site", value: datas.body && datas.body.regwebSite || this.ctx.config.webSite, alert: alert("webSite"), toolType: "Name must be at least 2 words" })}
                        ${this.addTextInput({ name: "nb_page", label: "nb page", value: datas.body && datas.body.nb_page || this.ctx.config.nb_page, alert: alert("nb_page"), toolType: "Name must be at least 2 words" })}
                        </div>
                        <div class="sign-up-htm">
                        ${this.addCheckBox({ name: "stripNull", checked: datas.body && datas.body.stripNull === true || this.ctx.config.options.includes(enums_1.EOptions.stripNull), label: " strip Null" })}
                        ${this.addCheckBox({ name: "forceHttps", checked: datas.body && datas.body.forceHttps === true || this.ctx.config.options.includes(enums_1.EOptions.forceHttps), label: " force Https" })}
                        ${this.addCheckBox({ name: "canDrop", checked: datas.body && datas.body.canDrop === true || this.ctx.config.options.includes(enums_1.EOptions.canDrop), label: " can Drop Database" })}
                        ${this.addSubmitButton("Save options")}
                        </div>
                      </form>
                  </div>
                </div>
              </div>
            </body>                  
          </html>`];
    }
    ;
}
exports.Config = Config;
