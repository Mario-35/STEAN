"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoreHtmlView = void 0;
const css_1 = require("../css");
class CoreHtmlView {
    ctx;
    _HTMLResult;
    constructor(ctx, datas) {
        this.ctx = ctx;
        this._HTMLResult = datas ? typeof datas === 'string' ? [datas] : datas : [];
    }
    makeIdName(name) {
        return `reg${name}`;
    }
    css(name) {
        return name.toLowerCase() === "user" ? (0, css_1.addCssFile)("userForm.css") : (0, css_1.addCssFile)("query.css");
    }
    title(message) {
        return `<div class="title">${message}</div>`;
    }
    hr() {
        return '<div class="hr"></div>';
    }
    head(title, name) {
        return `<head>
                <meta charset="utf-8">
                <style>${this.css(name)}</style>
                <title>${title}</title>
              </head>`;
    }
    ;
    foot(links) {
        const returnValue = [this.hr()];
        links.forEach((element) => {
            returnValue.push(`
          <div class="inner">
            <a  href="${element.href}" 
                class="${element.class}">${element.name}</a>
          </div>`);
        });
        return returnValue.join();
    }
    ;
    addSubmitButton(label) {
        return `<div class="group">
                <input type="submit" class="button" value="${label}">
              </div>`;
    }
    addButton(action, label) {
        return `<div class="group">
                <a href="${action}" class="button" >${label}</a>
              </div>`;
    }
    addCheckBox(input) {
        const idName = this.makeIdName(input.name);
        return `<div class="group"> 
                <input  id="${idName}"
                        name="${input.name}"
                        type="checkbox" 
                        class="check"${input.checked === true ? ' checked' : ''}> 
                <label for="${idName}"><span class="icon"></span>${input.label ? input.label : input.name}</label>
              </div>`;
    }
    multiSelectItemCheck(name, list) {
        const res = [];
        list.forEach((e) => {
            res.push(`<label for="${e}"> <input type="checkbox" name="${name}${e}" />${e}</label>`);
        });
        return res.join("");
    }
    multiSelectItem(list) {
        const res = [];
        list.forEach((e, n) => {
            res.push(`<option value="${e}">${e}</option>`);
        });
        return res.join("");
    }
    addSelect(input) {
        const idName = this.makeIdName(input.name);
        return `<div class="group">
                <label  for="${idName}" class="label">
                 ${input.message}
                </label>
                <select class="select" id="${idName}" name="${input.name}">
                  ${this.multiSelectItem(input.list)}
                </select>
              </div>`;
    }
    addMultiSelect(input) {
        const idName = this.makeIdName(input.name);
        return `
                <div class="group selectBox" onclick="showCheckboxes(${idName})">
                <select>
                  <option >${input.message}</option>
                </select>
                <div class="overSelect"></div>
              </div>
              <div id="${idName}" class="checkboxes" checked="checked">
                ${this.multiSelectItemCheck(input.name, input.list)} 
            </div>`;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    addTextInput(input) {
        const idName = this.makeIdName(input.name);
        return `<div class="group">
                <label  for="${idName}" class="label">${input.label} </label>
                <input  id="${idName}" 
                        name="${input.name}" 
                        type="${input.password ? input.password == true ? 'password' : 'text' : 'text'}" 
                        class="input" 
                        value="${input.value}">
              </div>`;
    }
    toArray() {
        return this._HTMLResult;
    }
    toString() {
        return this._HTMLResult.filter(e => e !== "").join("");
    }
}
exports.CoreHtmlView = CoreHtmlView;
