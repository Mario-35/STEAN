"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.CoreHtmlView=void 0;const css_1=require("../css");class CoreHtmlView{ctx;_HTMLResult;constructor(e,s){this.ctx=e,this._HTMLResult=s?"string"==typeof s?[s]:s:[]}makeIdName(e){return"reg"+e}css(e){return"user"===e.toLowerCase()?(0,css_1.addCssFile)("userForm.css"):(0,css_1.addCssFile)("query.css")}title(e){return`<div class="title">${e}</div>`}hr(){return'<div class="hr"></div>'}head(e,s){return`<head>
                <meta charset="utf-8">
                <style>${this.css(s)}</style>
                <title>${e}</title>
              </head>`}foot(e){const s=[this.hr()];return e.forEach(e=>{s.push(`
          <div class="inner">
            <a  href="${e.href}" 
                class="${e.class}">${e.name}</a>
          </div>`)}),s.join()}addSubmitButton(e){return`<div class="group">
                <input type="submit" class="button" value="${e}">
              </div>`}addButton(e,s){return`<div class="group">
                <a href="${e}" class="button" >${s}</a>
              </div>`}addCheckBox(e){var s=this.makeIdName(e.name);return`<div class="group"> 
                <input  id="${s}"
                        name="${e.name}"
                        type="checkbox" 
                        class="check"${!0===e.checked?" checked":""}> 
                <label for="${s}"><span class="icon"></span>${e.label||e.name}</label>
              </div>`}multiSelectItemCheck(s,e){const t=[];return e.forEach(e=>{t.push(`<label for="${e}"> <input type="checkbox" name="${s}${e}" />${e}</label>`)}),t.join("")}multiSelectItem(e){const t=[];return e.forEach((e,s)=>{t.push(`<option value="${e}">${e}</option>`)}),t.join("")}addSelect(e){var s=this.makeIdName(e.name);return`<div class="group">
                <label  for="${s}" class="label">
                 ${e.message}
                </label>
                <select class="select" id="${s}" name="${e.name}">
                  ${this.multiSelectItem(e.list)}
                </select>
              </div>`}addMultiSelect(e){var s=this.makeIdName(e.name);return`
                <div class="group selectBox" onclick="showCheckboxes(${s})">
                <select>
                  <option>${e.message}</option>
                </select>
                <div class="overSelect"></div>
              </div>
              <div id="${s}" class="checkboxes">
                ${this.multiSelectItemCheck(e.name,e.list)}
            </div>`}addTextInput(e){var s=this.makeIdName(e.name);return`<div class="group">
                <label  for="${s}" class="label">${e.label} </label>
                <input  id="${s}" 
                        name="${e.name}" 
                        type="${e.password&&1==e.password?"password":"text"}" 
                        class="input" 
                        value="${e.value}">
              </div>`}toArray(){return this._HTMLResult}toString(){return this._HTMLResult.filter(e=>""!==e).join("")}}exports.CoreHtmlView=CoreHtmlView;