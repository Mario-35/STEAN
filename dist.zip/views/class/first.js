"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.First=void 0;const enums_1=require("../../enums"),core_1=require("./core");class First extends core_1.CoreHtmlView{constructor(e,t){super(e),this.first(t)}first(t){t.url="/create";var e=e=>t.why&&t.why[e]?`<div class="alert">${t.why[e]}</div>`:"";this._HTMLResult=[`
          <!DOCTYPE html>
            <html>
              ${this.head("Login","user")}    
            <body>
            <script>
            var expanded = false;

            function showCheckboxes(checkboxes) {
              if (!expanded) {
                checkboxes.style.display = "block";
                expanded = true;
              } else {
                checkboxes.style.display = "none";
                expanded = false;
              }
            }
            </script> 
            <div class="login-wrap">
            <div class="login-html">
            ${this.title("First Install")}
                    <input  id="tab-1" 
                            type="radio" 
                            name="tab" 
                            class="sign-in" checked>
                    <label for="tab-1" class="tab">Service</label>
                    <input  id="tab-2" 
                            type="radio" 
                            name="tab" 
                            class="sign-up">
                    <label for="tab-2" class="tab">Admin</label>
                    <div class="login-form">
                      <form action="${t.url}" method="post">
                        <div class="sign-in-htm">
                        <table>
                          <tr>
                          <td> ${this.addTextInput({name:"servicename",label:"Service name",value:t.body&&t.body.regservice||"",alert:e("service"),toolType:"Name must be at least 5 chars"})} </td>
                          <td> ${this.addTextInput({name:"serviceport",label:"Port",value:t.body&&t.body.regservice||"5432",alert:e("service"),toolType:"Name must be have 4 numbers"})} </td>
                          </tr>
                          <tr>
                            <td> ${this.addTextInput({name:"servicehost",label:"Host name",value:t.body&&t.body.regservicehost||"localhost",alert:e("host"),toolType:"Host must be at least 5 chars"})} </td>
                            <td> ${this.addTextInput({name:"serviceusername",label:"Username",value:t.body&&t.body.regserviceusername||"",alert:e("username"),toolType:"Name must be at least 5 chars"})} </td>
                            </tr>
                          <tr>
                            <td> ${this.addTextInput({name:"servicepassword",label:"Password",password:!0,value:t.body&&t.body.service||"",alert:e("password"),toolType:"At least one number, one lowercase and one uppercase letter, at least six characters that are letters, numbers or the underscore"})} </td>
                            <td> ${this.addTextInput({name:"servicerepeat",label:"Repeat password",password:!0,value:"",alert:e("repeat"),toolType:"Same as password"})} </td>
                            </tr>
                            <tr>
                            <td> ${this.addTextInput({name:"servicedatabase",label:"Database name",value:"",alert:e("database"),toolType:"name of psotgresSql database"})} </td>
                            <td> ${this.addSelect({name:"serviceversion",list:(0,enums_1.enumKeys)(enums_1.EnumVersion).map(e=>e.replace("_",".")),message:"Select version",password:!0,value:"",alert:e("repeat"),toolType:"Same as password"})} </td>
                          </tr>
                          <tr>
                            <td class="onTop">
                            ${this.addMultiSelect({name:"serviceextensions",list:(0,enums_1.enumKeys)(enums_1.EnumExtensions),message:"Select extensions"})}                            
                            </td>
                            <td class="onTop">
                            ${this.addMultiSelect({name:"serviceoptions",list:(0,enums_1.enumKeys)(enums_1.EnumOptions),message:"Select Options"})}                            
                            </td>
                          </tr>
                          </table>
                        </div> 
                        <div class="sign-up-htm">
                        ${this.addTextInput({name:"host",label:"Host name",value:t.body&&t.body.host||"localhost",alert:e("host"),toolType:"Host must be at least 5 chars"})}
                        ${this.addTextInput({name:"username",label:"Username",value:t.body&&t.body.username||"",alert:e("username"),toolType:"Name must be at least 5 chars"})}
                        ${this.addTextInput({name:"password",label:"Password",password:!0,value:t.body&&t.body.password||"",alert:e("password"),toolType:"At least one number, one lowercase and one uppercase letter, at least six characters that are letters, numbers or the underscore"})}
                        ${this.addTextInput({name:"repeat",label:"Repeat password",password:!0,value:"",alert:e("repeat"),toolType:"Same as password"})}
                        ${this.addSubmitButton("Create configuration")}
                        </div>
                      </form>
                  </div>
                </div>
              </div>
            </body>                  
          </html>`]}}exports.First=First;