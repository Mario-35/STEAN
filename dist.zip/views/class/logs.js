"use strict";var __importDefault=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(exports,"__esModule",{value:!0}),exports.HtmlLogs=void 0;const core_1=require("./core"),fs_1=__importDefault(require("fs")),path_1=__importDefault(require("path"));var Convert=require("ansi-to-html");class HtmlLogs extends core_1.CoreHtmlView{constructor(e,t){var r=fs_1.default.readFileSync(path_1.default.resolve(__dirname,"../../logs.txt"),"utf8");super(e),this.logs(r)}logs(e){var t=new Convert({fg:"#FFF",bg:"#000",newline:!0,escapeXML:!1,stream:!1});this._HTMLResult=[`
        <!DOCTYPE html>
            <html>
            <body style="background-color:Silver;">
                ${t.toHtml(e)}

                    </body>
                </html>`]}}exports.HtmlLogs=HtmlLogs;