"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HtmlLogs = void 0;
const core_1 = require("./core");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const helpers_1 = require("../helpers");
class HtmlLogs extends core_1.CoreHtmlView {
    constructor(ctx, datas) {
        const fileContent = fs_1.default.readFileSync(path_1.default.resolve(__dirname, "../../logs.txt"), "utf8");
        super(ctx);
        this.logs(fileContent);
    }
    logs(message) {
        this._HTMLResult = [`
        <!DOCTYPE html>
            <html>
            <body style="background-color:#A49C9C;">
                ${(0, helpers_1.logToHtml)(message)}

                    </body>
                </html>`];
    }
    ;
}
exports.HtmlLogs = HtmlLogs;
