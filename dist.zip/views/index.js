"use strict";
/**
 * HTML Views Index for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- HTML Views Index for API -----------------------------------!");
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createQueryHtml = exports.UserEdit = exports.Status = exports.HtmlError = exports.Login = exports.First = exports.Config = void 0;
const fs_1 = __importDefault(require("fs"));
const helpers_1 = require("./helpers");
var config_1 = require("./class/config");
Object.defineProperty(exports, "Config", { enumerable: true, get: function () { return config_1.Config; } });
var first_1 = require("./class/first");
Object.defineProperty(exports, "First", { enumerable: true, get: function () { return first_1.First; } });
var login_1 = require("./class/login");
Object.defineProperty(exports, "Login", { enumerable: true, get: function () { return login_1.Login; } });
var error_1 = require("./class/error");
Object.defineProperty(exports, "HtmlError", { enumerable: true, get: function () { return error_1.HtmlError; } });
var status_1 = require("./class/status");
Object.defineProperty(exports, "Status", { enumerable: true, get: function () { return status_1.Status; } });
var userEdit_1 = require("./class/userEdit");
Object.defineProperty(exports, "UserEdit", { enumerable: true, get: function () { return userEdit_1.UserEdit; } });
const createQueryHtml = (params) => (0, helpers_1.createQueryHtmlString)(fs_1.default.readFileSync(__dirname + "/html/query.html").toString(), params);
exports.createQueryHtml = createQueryHtml;
