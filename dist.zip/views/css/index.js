"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.listaddCssFiles = exports.addCssFile = void 0;
/**
 * Index Css.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Index Css. -----------------------------------!");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const addCssFile = (name) => (fs_1.default.existsSync(__dirname + `/${name}`)) ? fs_1.default.readFileSync(__dirname + `/${name}`, "utf-8") : fs_1.default.readFileSync(__dirname + `/${name.replace(".css", ".min.css")}`, "utf-8");
exports.addCssFile = addCssFile;
const listaddCssFiles = () => {
    const result = [];
    fs_1.default.readdirSync(path_1.default.join(__dirname)).filter((e) => e.endsWith(".css")).forEach(file => {
        result.push(file);
    });
    return result;
};
exports.listaddCssFiles = listaddCssFiles;
