
function updateForm() {
	header("updateForm");
	toggleShowHide(logout, _PARAMS.user.canPost);
	buttonGo();
	const tempOptions = getFormatOptions();
	populateSelect(resultFormatOption, tempOptions, getDefaultValue(resultFormatOption, tempOptions));
	getElement("actionForm").action = `${optHost.value}/${optVersion.value}/${entityOption.value}${entityOption.value === "CreateObservations" || isObservation() ? "" : `` }`;
	// getElement("actionForm").action = `${optHost.value}/${optVersion.value}/${entityOption.value}${entityOption.value === "CreateObservations" || isObservation() ? "" : `(${idOption.value})/CreateFile` }`;
	tabEnabledDisabled("propertyTab", isAdmin === false && (idOption.value != ""));
	tabEnabledDisabled("importTab", isAdmin === false && _PARAMS.user.canPost);
	tabEnabledDisabled("observationsTab", isAdmin === false && isObservation());
	tabEnabledDisabled("queryBuilderTab", isAdmin === false);
	tabEnabledDisabled("expandTab", isAdmin === false);
	tabEnabledDisabled("AdminTab", (_PARAMS.user.admin || _PARAMS.user.superAdmin));
	tabEnabledDisabled("AdminTab", (_PARAMS.user.admin || _PARAMS.user.superAdmin));
}


function refresh() {
	header("refresh");
	const tempEntity = SubOrNot();
	populateMultiSelect("selectOption", getColumnsList(tempEntity).filter(e => !e.includes("_")), "all");
	populateMultiSelect("orderbyOption", getColumnsList(tempEntity));
	populateSelect(propertyOption, getColumnsList(tempEntity), _PARAMS.property != undefined ? _PARAMS.property : _NONE, true);
	populateMultiSelect("expandOption", getRelationsList(tempEntity));
	updateForm();
	updateBuilder();
	canShowQueryButton();
	toggleShowHide(getElement("payloadPartTab"), entityOption.value === "Decoders");
	toggleShowHide(getElement("logsPartTab"), entityOption.value === "Logs");
}

function refresh_entity() {
	const relations = getRelationsList(entityOption.value);
	if (!relations.includes(subentityOption.value)) {
		subentityOption.options.length = 0;
		if ((entityOption.value.includes("createDB") && _PARAMS.user.canCreateDb == true) || importFile) methodOption.value = "POST";
		else if (entityOption.value === "createDB") methodOption.value = "POST";
		else {
			if (relations) populateSelect(subentityOption, relations, relations.includes(_PARAMS.subentityOption) ? _PARAMS.subentityOption : _NONE, true);
			populateSelect(methodOption, entityOption.value == "Loras" ? ["GET", "POST"] : _PARAMS.methods, methodOption.value !== "" ? methodOption.value : "GET");
		}
	}
}

