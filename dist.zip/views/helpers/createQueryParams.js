"use strict";
/**
 * createQueryParams
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- createQueryParams -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.createQueryParams = void 0;
const authentication_1 = require("../../authentication");
const configuration_1 = require("../../configuration");
const log_1 = require("../../log");
const models_1 = require("../../models");
const decodeUrl_1 = require("../../routes/helper/decodeUrl");
const blankUser_1 = require("./blankUser");
async function createQueryParams(ctx) {
    console.log(log_1.log.whereIam());
    const model = models_1.models.filteredModelFromConfig(ctx.config);
    let user = await (0, authentication_1.getAuthenticatedUser)(ctx);
    user = user ? user : (0, blankUser_1.blankUser)(ctx);
    const listEntities = user.superAdmin === true
        ? Object.keys(model)
        : user.admin === true
            ? Object.keys(model).filter((elem) => ctx.model[elem].order > 0 || ctx.model[elem].createOrder === 99 || ctx.model[elem].createOrder === -1)
            : user.canPost === true
                ? Object.keys(model).filter((elem) => ctx.model[elem].order > 0 || ctx.model[elem].createOrder === 99 || ctx.model[elem].createOrder === -1)
                : Object.keys(model).filter((elem) => ctx.model[elem].order > 0);
    listEntities.push("Configs");
    const decodedUrl = (0, decodeUrl_1.decodeUrl)(ctx);
    if (decodedUrl)
        return {
            methods: ["GET"],
            decodedUrl: decodedUrl,
            entity: "",
            options: ctx.querystring ? ctx.querystring : "",
            user: user,
            graph: ctx.url.includes("$resultFormat=graph"),
            admin: ctx.config.name === 'admin',
            services: configuration_1.serverConfig.getInfosForAll(ctx),
            _DATAS: Object.fromEntries(Object.entries(model).filter(([k, v]) => listEntities.includes(k) && v.order > 0)),
        };
}
exports.createQueryParams = createQueryParams;
;
