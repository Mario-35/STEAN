"use strict";
/**
 * createQueryHtmlString
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- createQueryHtmlString -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.createQueryHtmlString = void 0;
const logger_1 = require("../../logger");
const helpers_1 = require("../../helpers");
const css_1 = require("../css");
const js_1 = require("../js");
const constants_1 = require("../../constants");
function createQueryHtmlString(input, params) {
    console.log(logger_1.formatLog.head("commonHtml"));
    // if js or css .min
    const fileWithOutMin = (input) => input.replace(".min", '');
    // Split files for better search and replace
    const result = input
        .replace(/<link /g, '\n<link ')
        .replace(/<script /g, '\n<script ')
        .replace(/<\/script>/g, '</script>\n')
        .replace(/\r\n/g, '\n')
        .split('\n')
        .map((e) => e.trim())
        .filter(e => e.trim() != "");
    // replace in result
    const replaceInReturnResult = (searhText, content) => {
        let index = result.indexOf(searhText);
        if (index > 0)
            result[index] = content;
        else {
            index = result.indexOf((0, helpers_1.removeAllQuotes)(searhText));
            if (index > 0)
                result[index] = content;
        }
    };
    // users possibilities
    if (params.user.canPost) {
        params.methods.push("POST");
        params.methods.push("PATCH");
        if (params.user.canDelete)
            params.methods.push("DELETE");
    }
    // Format params
    if (params.options) {
        let tempOptions = params.options;
        if (params.options.includes("options=")) {
            const temp = params.options.split("options=");
            params.options = temp[1];
            tempOptions = temp[0];
        }
        else
            params.options = "";
        const splitOptions = tempOptions.split("&");
        const valid = ["method", "id", "entity", "subentity", "property", "onlyValue"];
        splitOptions.forEach((element) => {
            if (element.includes("=")) {
                const temp = element.split("=");
                if (temp[0] && temp[1]) {
                    // @ts-ignore
                    if (valid.includes(temp[0]))
                        params[temp[0]] = (0, helpers_1.cleanUrl)(temp[1]);
                    else if (temp[0] == "datas")
                        params.datas = JSON.parse(unescape(temp[1]));
                }
            }
        });
    }
    // process all css files
    (0, css_1.listaddCssFiles)().forEach((item) => {
        replaceInReturnResult(`<link rel="stylesheet" href="${fileWithOutMin(item)}">`, `<style>${(0, css_1.addCssFile)(item)}</style>`);
    });
    // process all js files
    (0, js_1.listaddJsFiles)().forEach((item) => {
        replaceInReturnResult(`<script src="${fileWithOutMin(item)}"></script>`, `<script>${(0, js_1.addJsFile)(item)}</script>`);
    });
    // return html as a string
    return result.join("").replace("_PARAMS={}", "_PARAMS=" + JSON.stringify(params, helpers_1.bigIntReplacer))
        // execute a start of query
        .replace("// @start@", params.results ? "jsonObj = JSON.parse(`" + params.results + "`); jsonViewer.showJSON(jsonObj);" : "")
        // App version on query
        .replace("@version@", constants_1.APP_VERSION)
        // default action form
        .replace("@action@", `${params.decodedUrl.root}/${params.decodedUrl.version}/CreateObservations`);
}
exports.createQueryHtmlString = createQueryHtmlString;
;
