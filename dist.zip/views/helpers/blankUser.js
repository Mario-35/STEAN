"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.blankUser = void 0;
/**
 * blankUser
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- blankUser -----------------------------------!");
const enums_1 = require("../../enums");
function blankUser(ctx) {
    return {
        id: 0,
        username: "query",
        password: "",
        email: "",
        database: ctx.config.pg.database,
        canPost: !!ctx.config.extensions.includes(enums_1.EExtensions.security),
        canDelete: !!ctx.config.extensions.includes(enums_1.EExtensions.security),
        canCreateUser: !!ctx.config.extensions.includes(enums_1.EExtensions.security),
        canCreateDb: !!ctx.config.extensions.includes(enums_1.EExtensions.security),
        admin: false,
        superAdmin: false
    };
}
exports.blankUser = blankUser;
;
