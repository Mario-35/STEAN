"use strict";
/**
 * userAuthenticated
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- userAuthenticated -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.userAuthenticated = void 0;
const _1 = require(".");
const enums_1 = require("../enums");
const userAuthenticated = (ctx) => {
    if (ctx.config.extensions.includes(enums_1.EExtensions.users)) {
        const token = (0, _1.decodeToken)(ctx);
        return (token && +token.id > 0);
    }
    else
        return true;
};
exports.userAuthenticated = userAuthenticated;
