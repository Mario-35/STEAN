"use strict";
/**
 * decodeToken
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- decodeToken -----------------------------------!");
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.decodeToken = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const userToken_1 = require("../types/userToken");
const decodeToken = (ctx) => {
    if (ctx.request.hasOwnProperty("token")) {
        // @ts-ignore
        const token = jsonwebtoken_1.default.decode(ctx.request["token"]);
        if (token && token["data"]["id"] > 0)
            return Object.freeze({
                id: +token["data"]["id"],
                username: token["data"]["username"],
                password: token["data"]["password"],
                PDCUAS: token["data"]["PDCUAS"],
            });
    }
    return userToken_1.blankUserToken;
};
exports.decodeToken = decodeToken;
