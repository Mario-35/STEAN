"use strict";
/**
 * loginUser
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- loginUser -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.loginUser = void 0;
const _1 = require(".");
const configuration_1 = require("../configuration");
const helpers_1 = require("../helpers");
const loginUser = async (ctx) => {
    const body = ctx.request.body;
    if (body["username"] && body["password"]) {
        const query = await configuration_1.serverConfig.connection(ctx.config.name) `SELECT * FROM "user" WHERE username = ${body["username"]} LIMIT 1`;
        if (query.length === 1) {
            const user = { ...query[0] };
            if (user && body && body["password"].match((0, helpers_1.decrypt)(user.password)) !== null) {
                const token = (0, _1.createToken)(user, body["password"]);
                ctx.cookies.set("jwt-session", token);
                user.token = token;
                return Object.freeze(user);
            }
        }
        else
            ctx.throw(404);
    }
    else
        ctx.throw(401);
};
exports.loginUser = loginUser;
