"use strict";
/**
 * IvisitRessource interface
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- IvisitRessource interface -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
;
