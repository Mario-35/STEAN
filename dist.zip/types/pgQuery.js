"use strict";
/**
 * pgQuery interface
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- pgQuery interface -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
