"use strict";
/**
 * Index Types
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Index Types -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.typeExtensions = exports.typeOptions = void 0;
const enums_1 = require("../enums");
exports.typeOptions = Object.keys(enums_1.EnumOptions);
exports.typeExtensions = Object.keys(enums_1.EnumExtensions);
