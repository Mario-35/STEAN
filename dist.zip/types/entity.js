"use strict";
/**
 * Entity interface
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Entity interface -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
