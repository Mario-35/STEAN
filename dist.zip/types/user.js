"use strict";
/**
 * user interface
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- user interface -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
