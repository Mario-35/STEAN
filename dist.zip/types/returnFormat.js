"use strict";
/**
 * returnFormat interface
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- returnFormat interface -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
