"use strict";
/**
 * returnResult interface
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- returnResult interface -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
