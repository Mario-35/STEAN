"use strict";
/**
 * oData parser
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// console.log("!----------------------------------- oData parser -----------------------------------!");
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.literal = exports.keys = exports.filter = exports.query = exports.resourcePath = exports.odataUri = exports.parserFactory = void 0;
const primitiveLiteral_1 = __importDefault(require("./primitiveLiteral"));
const expressions_1 = __importDefault(require("./expressions"));
const query_1 = __importDefault(require("./query"));
const resourcePath_1 = __importDefault(require("./resourcePath"));
const odataUri_1 = __importDefault(require("./odataUri"));
const logger_1 = require("../../logger");
// Odata Main parser
const parserFactory = function (fn) {
    console.log(logger_1.formatLog.whereIam());
    return function (source, options) {
        options = options || {};
        const raw = new Uint16Array(source.length);
        const pos = 0;
        for (let i = 0; i < source.length; i++) {
            raw[i] = source.charCodeAt(i);
        }
        const result = fn(raw, pos, options.metadata);
        if (!result)
            throw new Error("Fail at " + pos);
        if (result.next < raw.length)
            throw new Error(`Unexpected character at [${source}]` + result.next);
        return result;
    };
};
exports.parserFactory = parserFactory;
function odataUri(source, options) {
    return (0, exports.parserFactory)(odataUri_1.default.odataUri)(source, options);
}
exports.odataUri = odataUri;
function resourcePath(source, options) {
    return (0, exports.parserFactory)(resourcePath_1.default.resourcePath)(source, options);
}
exports.resourcePath = resourcePath;
function query(source, options) {
    return (0, exports.parserFactory)(query_1.default.queryOptions)(source, options);
}
exports.query = query;
function filter(source, options) {
    return (0, exports.parserFactory)(expressions_1.default.boolCommonExpr)(source, options);
}
exports.filter = filter;
function keys(source, options) {
    return (0, exports.parserFactory)(expressions_1.default.keyPredicate)(source, options);
}
exports.keys = keys;
function literal(source, options) {
    return (0, exports.parserFactory)(primitiveLiteral_1.default.primitiveLiteral)(source, options);
}
exports.literal = literal;
__exportStar(require("./types"), exports);
