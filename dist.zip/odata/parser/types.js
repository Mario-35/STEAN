"use strict";
/**
 * oData QueryOptionsNode
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- oData QueryOptionsNode -----------------------------------!")
Object.defineProperty(exports, "__esModule", { value: true });
