"use strict";
/**
 * oData Token
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- oData Token -----------------------------------!")
Object.defineProperty(exports, "__esModule", { value: true });
