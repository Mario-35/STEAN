"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createOdata = void 0;
/**
 * pgVisitor index.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- pgVisitor index. -----------------------------------!");
const parser_1 = require("./parser/parser");
const helpers_1 = require("../helpers");
const configuration_1 = require("../configuration");
const queries_1 = require("../db/queries");
const visitor_1 = require("./visitor");
const doSomeWarkAfterCreateAst = async (input, ctx) => {
    if ((input.returnFormat === helpers_1.returnFormats.csv && input.entity === "Observations" && input.parentEntity?.endsWith('atastreams') && input.parentId && input.parentId > 0) ||
        (input.splitResult && input.splitResult[0].toUpperCase() == "ALL" && input.parentId && input.parentId > 0)) {
        const temp = await configuration_1.serverConfig.connection(ctx.config.name).unsafe(`${(0, queries_1.multiDatastreamKeys)(input.parentId)}`);
        input.splitResult = temp[0]["keys"];
    }
};
const escapesOdata = (input) => {
    const codes = { "/": "%252F", "\\": "%255C" };
    if (input.includes("%27")) {
        const pop = [];
        input.split("%27").forEach((v, i) => {
            if (i === 1)
                Object.keys(codes).forEach((code) => v = v.split(code).join(codes[code]));
            pop.push(v);
        });
        return pop.join("%27");
    }
    return input;
};
const createOdata = async (ctx) => {
    // blank url if not defined
    // init Ressource wich have to be tested first
    const options = {
        onlyValue: false,
        onlyRef: false,
        valueskeys: false,
    };
    // normalize href
    let urlSrc = `${ctx.decodedUrl.path}${ctx.decodedUrl.search}`;
    if (urlSrc && urlSrc.trim() != "")
        urlSrc = escapesOdata(urlSrc);
    // replace element  
    const clean = (replaceThis, by) => urlSrc = urlSrc.split(replaceThis).join(by ? by : "");
    // function to remove element in url
    const removeElement = (input) => {
        clean(`&${input}`);
        clean(input);
    };
    clean("geography%27", "%27");
    clean("@iot.");
    // clean id in url
    urlSrc = (0, helpers_1.cleanUrl)(clean("@iot.id", "id"));
    if (urlSrc === "/")
        return;
    if (urlSrc.includes("$"))
        urlSrc.split("$").forEach((element) => {
            switch (element) {
                case "value?":
                case "value":
                    options.onlyValue = true;
                    removeElement(`/$${element}`);
                    break;
                case "ref":
                    options.onlyRef = true;
                    removeElement(`/$${element}`);
                    break;
                case "valuesKeys=true":
                    options.valueskeys = true;
                    removeElement(`$${element}`);
                    break;
            }
        });
    const urlSrcSplit = (0, helpers_1.cleanUrl)(urlSrc).split("?");
    if (!urlSrcSplit[1])
        urlSrcSplit.push(`$top=${ctx.config.nb_page ? ctx.config.nb_page : 200}`);
    if (urlSrcSplit[0].split("(").length != urlSrcSplit[0].split(")").length)
        urlSrcSplit[0] += ")";
    const astRessources = (0, parser_1.resourcePath)(urlSrcSplit[0]);
    const astQuery = (0, parser_1.query)(decodeURIComponent(urlSrcSplit[1]));
    const temp = new visitor_1.RootPgVisitor(ctx, options, astRessources).start(astQuery);
    await doSomeWarkAfterCreateAst(temp, ctx);
    return temp;
};
exports.createOdata = createOdata;
