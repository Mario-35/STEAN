"use strict";
/**
 * Visitor for odata
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Visitor for odata -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.Visitor = void 0;
const helpers_1 = require("../../../helpers");
const builder_1 = require("../builder");
class Visitor {
    ctx;
    options;
    onlyRef = false;
    onlyValue = false;
    valueskeys = false;
    returnFormat = helpers_1.returnFormats.json;
    query = new builder_1.Query();
    includes;
    constructor(ctx, options = {}) {
        this.ctx = ctx;
        this.options = options;
        this.onlyRef = options.onlyRef;
        this.onlyValue = options.onlyValue;
        this.valueskeys = options.valueskeys;
        this.returnFormat = (options.onlyValue === true) ? helpers_1.returnFormats.txt : helpers_1.returnFormats.json;
    }
    addInclude(input) {
        this.includes.push(input);
    }
}
exports.Visitor = Visitor;
