"use strict";
/**
 * pgVisitor for odata
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- pgVisitor for odata -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.RootPgVisitor = void 0;
const helpers_1 = require("../../../helpers");
const logger_1 = require("../../../logger");
const helper_1 = require("../helper");
const enums_1 = require("../../../enums");
const models_1 = require("../../../models");
const log_1 = require("../../../log");
const constants_1 = require("../../../constants");
const _1 = require("../.");
class RootPgVisitor extends _1.PgVisitor {
    static root = true;
    constructor(ctx, options = {}, node) {
        console.log(logger_1.formatLog.whereIam());
        super(ctx, options);
        if (node)
            this.StartVisitRessources(node);
    }
    verifyRessources = () => {
        console.log(logger_1.formatLog.head("verifyRessources"));
    };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    VisitRessources(node, context) {
        const ressource = this[`VisitRessources${node.type}`];
        if (ressource) {
            // @ts-ignore
            ressource.call(this, node, context);
            if (this.debugOdata) {
                console.log(logger_1.formatLog.debug("VisitRessources", `VisitRessources${node.type}`));
                console.log(logger_1.formatLog.result("node.raw", node.raw));
            }
        }
        else {
            log_1.log.errorMsg(`Ressource Not Found ============> VisitRessources${node.type}`);
            throw new Error(`Unhandled node type: ${node.type}`);
        }
        return this;
    }
    VisitRessourcesResourcePath(node, context) {
        if (node.value.resource && node.value.resource.type == "EntitySetName") {
            this.entity = node.value.resource.raw;
        }
        if (node.value.navigation)
            this.VisitRessources(node.value.navigation, context);
    }
    VisitRessourcesEntitySetName(node, _context) {
        this.entity = node.value.raw;
    }
    VisitRessourcesRefExpression(node, _context) {
        if (node.type == "RefExpression" && node.raw == "/$ref")
            this.onlyRef = true;
    }
    VisitRessourcesValueExpression(node, _context) {
        if (node.type == "ValueExpression" && node.raw == "/$value")
            this.onlyValue = true;
    }
    VisitRessourcesCollectionNavigation(node, context) {
        if (node.value.path)
            this.VisitRessources(node.value.path, context);
    }
    VisitRessourcesCollectionNavigationPath(node, context) {
        if (node.value.predicate)
            this.VisitRessources(node.value.predicate, context);
        if (node.value.navigation)
            this.VisitRessources(node.value.navigation, context);
    }
    VisitRessourcesSimpleKey(node, context) {
        if (node.value.value.type === "KeyPropertyValue")
            this.VisitRessources(node.value.value, context);
    }
    VisitRessourcesKeyPropertyValue(node, _context) {
        this.id = this.ctx.decodedUrl.idStr
            ? this.ctx.decodedUrl.idStr
            : node.value == "Edm.SByte"
                ? BigInt(node.raw)
                : node.raw;
        this.query.where.init(this.ctx.decodedUrl.idStr ? `"lora"."deveui" = '${this.ctx.decodedUrl.idStr}'` : `id = ${this.id}`);
    }
    VisitRessourcesSingleNavigation(node, context) {
        if (node.value.path && node.value.path.type === "PropertyPath")
            this.VisitRessources(node.value.path, context);
    }
    VisitRessourcesPropertyPath(node, context) {
        let tempNode = node;
        if (node.type == "PropertyPath") {
            if (models_1.models.getRelationColumnTable(this.ctx.config, this.entity, node.value.path.raw) === enums_1.EColumnType.Relation) {
                this.parentId = this.id;
                this.id = BigInt(0);
                if (node.value.navigation && node.value.navigation.type == "CollectionNavigation") {
                    tempNode = node.value.navigation;
                    if (tempNode.value.path.type === "CollectionNavigationPath") {
                        tempNode = tempNode.value.path;
                        if (tempNode.value.predicate.type === "SimpleKey") {
                            tempNode = tempNode.value.predicate.value;
                            if (tempNode.value.type === "KeyPropertyValue")
                                this.id = tempNode.value.raw;
                        }
                    }
                }
                const tmpLink = this.ctx.model[this.entity].relations[node.value.path.raw].link
                    .split("$ID")
                    .join(this.parentId);
                const tmpLinkSplit = tmpLink.split("in (");
                if (BigInt(this.id) > 0) {
                    this.query.where.init(`${tmpLinkSplit[0]} = (SELECT id FROM (${tmpLinkSplit[1]} as l WHERE id = ${this.id})`);
                }
                else
                    this.query.where.init(tmpLink);
                this.parentEntity = this.entity;
                this.entity = node.value.path.raw;
            }
            else if (this.ctx.model[this.entity].columns[node.value.path.raw]) {
                this.query.select.add(`${(0, helpers_1.addDoubleQuotes)(node.value.path.raw)}${constants_1._COLUMNSEPARATOR}`);
                this.showRelations = false;
            }
            else
                this.entity = node.value.path.raw;
        }
    }
    VisitRessourcesODataUri(node, context) {
        this.VisitRessources(node.value.resource, context);
        this.VisitRessources(node.value.query, context);
    }
    StartVisitRessources(node) {
        console.log(logger_1.formatLog.head("INIT PgVisitor"));
        this.limit = this.ctx.config.nb_page || 200;
        this.numeric = this.ctx.config.extensions.includes(enums_1.EExtensions.resultNumeric);
        const temp = this.VisitRessources(node);
        this.verifyRessources();
        return temp;
    }
    getSql() {
        if (this.includes)
            this.includes.forEach((include) => {
                if (include.navigationProperty.includes("/")) {
                    const names = include.navigationProperty.split("/");
                    include.navigationProperty = names[0];
                    const visitor = new _1.PgVisitor(this.ctx, { ...this.options });
                    if (visitor) {
                        visitor.entity = names[0];
                        visitor.navigationProperty = names[1];
                        if (include.includes)
                            include.includes.push(visitor);
                        else
                            include.includes = [visitor];
                    }
                }
            });
        return this.onlyValue ? this.toString() : this.returnFormat.generateSql(this);
    }
    patchSql(datas) {
        try {
            return (0, helper_1.postSqlFromPgVisitor)(datas, this);
        }
        catch (error) {
            return undefined;
        }
    }
    postSql(datas) {
        try {
            return (0, helper_1.postSqlFromPgVisitor)(datas, this);
        }
        catch (error) {
            return undefined;
        }
    }
}
exports.RootPgVisitor = RootPgVisitor;
