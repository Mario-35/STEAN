"use strict";
/**
 * pgVisitor for odata
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- pgVisitor for odata -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.PgVisitor = void 0;
const helpers_1 = require("../../../helpers");
const literal_1 = require("../../parser/literal");
const sqlLiteral_1 = require("../../parser/sqlLiteral");
const logger_1 = require("../../../logger");
const helper_1 = require("../helper");
const messages_1 = require("../../../messages");
const enums_1 = require("../../../enums");
const models_1 = require("../../../models");
const log_1 = require("../../../log");
const constants_1 = require("../../../constants");
const visitor_1 = require("./visitor");
const constants_2 = require("../../../db/constants");
class PgVisitor extends visitor_1.Visitor {
    entity = "";
    // parent entity
    parentEntity = undefined;
    id = BigInt(0);
    parentId = BigInt(0);
    intervalColumns = undefined;
    splitResult;
    interval;
    payload;
    skip = 0;
    limit = 0;
    count = false;
    numeric = false;
    returnNull = false;
    navigationProperty;
    parameters = [];
    ast;
    showRelations = true;
    results = {};
    debugOdata = (0, helpers_1.isTest)() ? false : true;
    constructor(ctx, options = {}) {
        console.log(logger_1.formatLog.whereIam());
        super(ctx, options);
    }
    // ***********************************************************************************************************************************************************************
    // ***                                                           ROSSOURCES                                                                                            ***
    // ***********************************************************************************************************************************************************************
    noLimit() {
        this.limit = 0;
        this.skip = 0;
    }
    addToIntervalColumns(input) {
        // TODO test with create    
        if (input.endsWith('Time"'))
            input = `step AS ${input}`;
        else if (input === (0, helpers_1.addDoubleQuotes)(constants_2._ID))
            input = `coalesce(${(0, helpers_1.addDoubleQuotes)(constants_2._ID)}, 0) AS ${(0, helpers_1.addDoubleQuotes)(constants_2._ID)}`;
        else if (input.startsWith("CONCAT"))
            input = `${input}`;
        else if (input[0] !== "'")
            input = `${input}`;
        if (this.intervalColumns)
            this.intervalColumns.push(input);
        else
            this.intervalColumns = [input];
    }
    getColumn(input, operation, context) {
        console.log(logger_1.formatLog.whereIam(input));
        const tempEntity = context.target === enums_1.EnumQuery.Where && context.identifier
            ? models_1.models.getEntity(this.ctx.config, context.identifier.split(".")[0])
            : this.isSelect(context)
                ? models_1.models.getEntity(this.ctx.config, this.entity || this.parentEntity || this.navigationProperty)
                : undefined;
        const columnName = input === "result"
            ? this.formatColumnResult(context, operation)
            : tempEntity
                ? this.getColumnNameOrAlias(tempEntity, input, this.createDefaultOptions())
                : undefined;
        if (columnName)
            return columnName;
        if (this.isSelect(context) && tempEntity && tempEntity.relations[input]) {
            const entityName = models_1.models.getEntityName(this.ctx.config, input);
            return tempEntity && entityName
                ? `CONCAT('${this.ctx.decodedUrl.root}/${tempEntity.name}(', "${tempEntity.table}"."id", ')/${entityName}') AS "${entityName}${constants_2._NAVLINK}"`
                : undefined;
        }
    }
    // ***********************************************************************************************************************************************************************
    // ***                                                              QUERY                                                                                              ***
    // ***********************************************************************************************************************************************************************
    formatColumnResult(context, operation, ForceString) {
        switch (context.target) {
            case enums_1.EnumQuery.Where:
                const nbs = Array.from({ length: 5 }, (v, k) => k + 1);
                const translate = `TRANSLATE (SUBSTRING ("result"->>'value' FROM '(([0-9]+.*)*[0-9]+)'), '[]','')`;
                const isOperation = operation.trim() != "";
                return ForceString
                    ? `@EXPRESSIONSTRING@ ANY (ARRAY_REMOVE( ARRAY[\n${nbs.map(e => `${isOperation ? `${operation} (` : ''} SPLIT_PART ( ${translate}, ',', ${e}))`).join(",\n")}], null))`
                    : `@EXPRESSION@ ANY (ARRAY_REMOVE( ARRAY[\n${nbs.map(e => `${isOperation ? `${operation} (` : ''}NULLIF (SPLIT_PART ( ${translate}, ',', ${e}),'')::numeric${isOperation ? `)` : ''}`).join(",\n")}], null))`;
            default:
                return `CASE 
          WHEN JSONB_TYPEOF( "result"->'value') = 'number' THEN ("result"->${this.numeric == true ? '>' : ''}'value')::jsonb
          WHEN JSONB_TYPEOF( "result"->'value') = 'array'  THEN ("result"->'${this.valueskeys == true ? 'valueskeys' : 'value'}')::jsonb
      END${this.isSelect(context) === true ? ' AS "result"' : ''}`;
        }
    }
    getColumnNameOrAlias(entity, column, options) {
        let result = undefined;
        if (entity && column != "" && entity.columns[column]) {
            result = entity.columns[column].alias(this.ctx.config, options);
            if (!result)
                result = (0, helpers_1.addDoubleQuotes)(column);
        }
        return result ? `${options.table === true && result && result[0] === '"' ? `"${entity.table}".${result}` : result}` : undefined;
    }
    ;
    clear(input) {
        if (input.includes('@START@')) {
            input = input.split('@START@').join("(");
            input = input.split('@END@').join('') + ')';
        }
        return input;
    }
    start(node) {
        console.log(logger_1.formatLog.head("Start PgVisitor"));
        const temp = this.Visit(node);
        this.verifyQuery();
        // Logs.infos("PgVisitor", temp);
        temp.query.where.init(this.clear(temp.query.where.toString()));
        return temp;
    }
    verifyQuery = () => {
        console.log(logger_1.formatLog.head("verifyQuery"));
        const expands = [];
        if (this.includes)
            this.includes.forEach((element) => {
                if (element.ast.type === "ExpandItem")
                    expands.push(element.ast.raw.split("(")[0]);
            });
        expands.forEach((elem) => {
            const elems = elem.split("/");
            elems.unshift(this.entity);
            if (elems[0]) {
                if (!Object.keys(this.ctx.model[elems[0]].relations).includes(elems[1]))
                    this.ctx.throw(400, {
                        detail: `Invalid expand path ${elems[1]} for ${elems[0]}`,
                    });
            }
            else
                this.ctx.throw(400, { detail: (0, messages_1.msg)(messages_1.errors.invalid, "entity") + elems[0] });
        });
        if ((0, helpers_1.isObservation)(this.entity) === true && this.splitResult !== undefined && Number(this.parentId) == 0) {
            this.ctx.throw(400, { detail: messages_1.errors.splitNotAllowed });
        }
        if (this.returnFormat === helpers_1.returnFormats.dataArray && BigInt(this.id) > 0 && !this.parentEntity) {
            this.ctx.throw(400, { detail: messages_1.errors.dataArrayNotAllowed });
        }
    };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    Visit(node, context) {
        this.ast = this.ast || node;
        context = context || { target: enums_1.EnumQuery.Where };
        if (node) {
            const visitor = this[`Visit${node.type}`];
            if (visitor) {
                // @ts-ignore
                visitor.call(this, node, context);
                if (this.debugOdata) {
                    console.log(logger_1.formatLog.debug("Visit", `Visit${node.type}`));
                    console.log(logger_1.formatLog.result("node.raw", node.raw));
                    console.log(logger_1.formatLog.result("this.query.where", this.query.where.toString()));
                    console.log(logger_1.formatLog.debug("context", context));
                }
            }
            else {
                log_1.log.errorMsg(`Node error =================> Visit${node.type}`);
                log_1.log.errorMsg(node);
                throw new Error(`Unhandled node type: ${node.type}`);
            }
        }
        if (node == this.ast) {
            if (this.entity.startsWith("Lora")) {
                if (typeof this.id == "string") {
                    this.query.where.init(`"lora"."deveui" = '${this.id}'`);
                }
            }
        }
        return this;
    }
    isSelect = (context) => (context.target ? context.target === enums_1.EnumQuery.Select : false);
    VisitExpand(node, context) {
        node.value.items.forEach((item) => {
            const expandPath = item.value.path.raw;
            let visitor = this.includes ? this.includes.filter((v) => v.navigationProperty == expandPath)[0] : undefined;
            if (!visitor) {
                visitor = new PgVisitor(this.ctx, { ...this.options });
                this.includes ? this.includes.push(visitor) : this.includes = [visitor];
            }
            visitor.Visit(item);
        });
    }
    VisitEntity(node, context) {
        this.Visit(node.value.path, context);
        if (node.value.options)
            node.value.options.forEach((item) => this.Visit(item, context));
    }
    VisitSplitResult(node, context) {
        this.Visit(node.value.path, context);
        if (node.value.options)
            node.value.options.forEach((item) => this.Visit(item, context));
        this.splitResult = (0, helpers_1.removeAllQuotes)(node.value).split(",");
    }
    VisitInterval(node, context) {
        this.Visit(node.value.path, context);
        if (node.value.options)
            node.value.options.forEach((item) => this.Visit(item, context));
        this.interval = node.value;
        if (this.interval)
            this.noLimit();
    }
    VisitPayload(node, context) {
        this.Visit(node.value.path, context);
        if (node.value.options)
            node.value.options.forEach((item) => this.Visit(item, context));
        this.payload = node.value;
    }
    VisitDebug(node, context) {
        this.Visit(node.value.path, context);
        if (node.value.options)
            node.value.options.forEach((item) => this.Visit(item, context));
    }
    VisitResultFormat(node, context) {
        if (node.value.format)
            this.returnFormat = helpers_1.returnFormats[node.value.format];
        if ([helpers_1.returnFormats.dataArray, helpers_1.returnFormats.graph, helpers_1.returnFormats.graphDatas, helpers_1.returnFormats.csv].includes(this.returnFormat))
            this.noLimit();
        this.showRelations = false;
        if ((0, helpers_1.isGraph)(this)) {
            this.showRelations = false;
            this.query.orderBy.add('"resultTime" ASC');
        }
    }
    VisitExpandItem(node, context) {
        this.Visit(node.value.path, context);
        if (node.value.options)
            node.value.options.forEach((item) => this.Visit(item, context));
    }
    VisitExpandPath(node, context) {
        this.navigationProperty = node.raw;
    }
    // Start loop process
    VisitQueryOptions(node, context) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        node.value.options.forEach((option) => this.Visit(option, context));
    }
    VisitInlineCount(node, context) {
        this.count = literal_1.Literal.convert(node.value.value, node.value.raw);
    }
    VisitFilter(node, context) {
        context.target = enums_1.EnumQuery.Where;
        if (this.query.where.toString().trim() != "")
            this.query.where.add(" AND ");
        this.Visit(node.value, context);
    }
    VisitOrderBy(node, context) {
        context.target = enums_1.EnumQuery.OrderBy;
        node.value.items.forEach((item, i) => {
            this.Visit(item, context);
            if (i < node.value.items.length - 1)
                this.query.orderBy.add(", ");
        });
    }
    VisitOrderByItem(node, context) {
        this.Visit(node.value.expr, context);
        if (this.query.orderBy.notNull())
            this.query.orderBy.add(node.value.direction > 0 ? " ASC" : " DESC");
    }
    VisitSkip(node, context) {
        this.skip = +node.value.raw;
    }
    VisitTop(node, context) {
        this.limit = +node.value.raw;
    }
    VisitSelect(node, context) {
        context.target = enums_1.EnumQuery.Select;
        node.value.items.forEach((item) => {
            this.Visit(item, context);
        });
    }
    VisitSelectItem(node, context) {
        const tempColumn = this.getColumn(node.raw, "", context);
        context.identifier = tempColumn ? tempColumn : node.raw;
        if (context.target)
            // @ts-ignore
            this.query[context.target].add(tempColumn ? `${tempColumn}${constants_1._COLUMNSEPARATOR}` : `${(0, helpers_1.addDoubleQuotes)(node.raw)}${constants_1._COLUMNSEPARATOR}`);
        this.showRelations = false;
    }
    VisitAndExpression(node, context) {
        this.Visit(node.value.left, context);
        this.query.where.add(context.in && context.in === true ? " INTERSECT " : " AND ");
        this.Visit(node.value.right, context);
    }
    VisitOrExpression(node, context) {
        this.Visit(node.value.left, context);
        this.query.where.add(" OR ");
        this.Visit(node.value.right, context);
    }
    VisitNotExpression(node, context) {
        this.query.where.add(" NOT ");
        this.Visit(node.value, context);
    }
    VisitBoolParenExpression(node, context) {
        this.query.where.add("(");
        this.Visit(node.value, context);
        this.query.where.add(")");
    }
    VisitCommonExpression(node, context) {
        this.Visit(node.value, context);
    }
    VisitFirstMemberExpression(node, context) {
        this.Visit(node.value, context);
    }
    VisitMemberExpression(node, context) {
        this.Visit(node.value, context);
    }
    VisitPropertyPathExpression(node, context) {
        if (node.value.current && node.value.next) {
            // deterwine if its column AND JSON
            if (models_1.models.getRelationColumnTable(this.ctx.config, this.ctx.model[this.entity], node.value.current.raw) === enums_1.EnumColumnType.Column
                && models_1.models.isColumnType(this.ctx.config, this.ctx.model[this.entity], node.value.current.raw, "json")
                && node.value.next.raw[0] == "/") {
                this.query.where.add(`${(0, helpers_1.addDoubleQuotes)(node.value.current.raw)}->>${(0, helpers_1.addSimpleQuotes)(node.value.next.raw.slice(1))}`);
            }
            else if (node.value.next.raw[0] == "/") {
                this.Visit(node.value.current, context);
                context.identifier += ".";
                this.Visit(node.value.next, context);
            }
            else {
                this.Visit(node.value.current, context);
                context.identifier += ".";
                this.Visit(node.value.next, context);
            }
        }
        else
            this.Visit(node.value, context);
    }
    VisitSingleNavigationExpression(node, context) {
        if (node.value.current && node.value.next) {
            this.Visit(node.value.current, context);
            this.Visit(node.value.next, context);
        }
        else
            this.Visit(node.value, context);
    }
    VisitLesserThanExpression(node, context) {
        context.sign = "<";
        if (!this.VisitDateType(node, context)) {
            this.Visit(node.value.left, context);
            this.addExpressionToWhere(node, context);
            this.Visit(node.value.right, context);
        }
    }
    VisitLesserOrEqualsExpression(node, context) {
        context.sign = "<=";
        if (!this.VisitDateType(node, context)) {
            this.Visit(node.value.left, context);
            this.addExpressionToWhere(node, context);
            this.Visit(node.value.right, context);
        }
    }
    VisitDateType(node, context) {
        if (context.sign && models_1.models.getRelationColumnTable(this.ctx.config, this.ctx.model[this.entity], node.value.left.raw) === enums_1.EnumColumnType.Column && models_1.models.isColumnType(this.ctx.config, this.ctx.model[this.entity], node.value.left.raw, "date")) {
            const testIsDate = (0, helper_1.oDataDateFormat)(node, context.sign);
            const columnName = this.getColumnNameOrAlias(this.ctx.model[context.identifier || this.entity], node.value.left.raw, { table: true, as: true, cast: false, ...this.createDefaultOptions() });
            if (testIsDate) {
                this.query.where.add(`${columnName
                    ? columnName
                    : `${(0, helpers_1.addDoubleQuotes)(node.value.left.raw)}`}${testIsDate}`);
                return true;
            }
        }
        return false;
    }
    addExpressionToWhere(node, context) {
        if (this.query.where.toString().includes("@EXPRESSION@"))
            this.query.where.replace("@EXPRESSION@", `@EXPRESSION@ ${context.sign}`);
        else if (!this.query.where.toString().includes("@EXPRESSIONSTRING@") && context.sign)
            // Important to keep space
            this.query.where.add(" " + context.sign);
    }
    VisitGreaterThanExpression(node, context) {
        context.sign = ">";
        if (!this.VisitDateType(node, context)) {
            this.Visit(node.value.left, context);
            this.addExpressionToWhere(node, context);
            this.Visit(node.value.right, context);
        }
    }
    VisitGreaterOrEqualsExpression(node, context) {
        context.sign = ">=";
        if (!this.VisitDateType(node, context)) {
            this.Visit(node.value.left, context);
            this.addExpressionToWhere(node, context);
            this.Visit(node.value.right, context);
        }
    }
    createDefaultOptions() {
        return {
            valueskeys: this.valueskeys,
            numeric: this.numeric
        };
    }
    createComplexWhere(entity, node, context) {
        if (context.target) {
            const tempEntity = models_1.models.getEntity(this.ctx.config, entity);
            if (!tempEntity)
                return;
            const colType = models_1.models.getRelationColumnTable(this.ctx.config, tempEntity, node.value.name);
            if (colType === enums_1.EnumColumnType.Column) {
                if (context.relation) {
                    if (Object.keys(tempEntity.relations).includes(context.relation)) {
                        if (!context.key) {
                            context.key = tempEntity.relations[context.relation].entityColumn;
                            // @ts-ignore
                            this.query[context.target].add(context.key);
                            // this[context.target] += addDoubleQuotes(context.key);
                        }
                    }
                }
            }
            else if (colType === enums_1.EnumColumnType.Relation) {
                const tempEntity = models_1.models.getEntity(this.ctx.config, node.value.name);
                if (tempEntity) {
                    if (context.relation) {
                        context.sql = `${(0, helpers_1.addDoubleQuotes)(this.ctx.model[entity].table)}.${(0, helpers_1.addDoubleQuotes)(this.ctx.model[entity].relations[node.value.name].entityColumn)} IN (SELECT ${(0, helpers_1.addDoubleQuotes)(tempEntity.table)}.${(0, helpers_1.addDoubleQuotes)(this.ctx.model[entity].relations[node.value.name].relationKey)} FROM ${(0, helpers_1.addDoubleQuotes)(tempEntity.table)}`;
                    }
                    else
                        context.relation = node.value.name;
                    if (!context.key && context.relation) {
                        context.key = this.ctx.model[entity].relations[context.relation].entityColumn;
                        // @ts-ignore
                        this.query[context.target].add((0, helpers_1.addDoubleQuotes)(this.ctx.model[entity].relations[context.relation].entityColumn));
                    }
                    return;
                }
            }
        }
    }
    VisitODataIdentifier(node, context) {
        const alias = this.getColumn(node.value.name, "", context);
        node.value.name = alias ? alias : node.value.name;
        if (context.relation && context.identifier && models_1.models.isColumnType(this.ctx.config, this.ctx.model[context.relation], (0, helpers_1.removeAllQuotes)(context.identifier).split(".")[0], "json")) {
            context.identifier = `${(0, helpers_1.addDoubleQuotes)(context.identifier.split(".")[0])}->>${(0, helpers_1.addSimpleQuotes)(node.raw)}`;
        }
        else {
            if (context.target === enums_1.EnumQuery.Where)
                this.createComplexWhere(context.identifier ? context.identifier.split(".")[0] : this.entity, node, context);
            if (!context.relation && !context.identifier && alias && context.target) {
                // @ts-ignore
                this.query[context.target].add(alias);
            }
            else {
                context.identifier = node.value.name;
                if (context.target && !context.key) {
                    let alias = this.getColumnNameOrAlias(this.ctx.model[this.entity], node.value.name, this.createDefaultOptions());
                    alias = context.target === enums_1.EnumQuery.Where ? alias?.split(" AS ")[0] : enums_1.EnumQuery.OrderBy ? (0, helpers_1.addDoubleQuotes)(node.value.name) : alias;
                    // @ts-ignore
                    this.query[context.target].add(node.value.name.includes("->>") || node.value.name.includes("->") || node.value.name.includes("::")
                        ? node.value.name
                        : this.entity && this.ctx.model[this.entity]
                            ? alias
                                ? alias
                                : ''
                            : (0, helpers_1.addDoubleQuotes)(node.value.name));
                }
            }
        }
    }
    VisitEqualsExpression(node, context) {
        context.sign = "=";
        if (!this.VisitDateType(node, context)) {
            this.Visit(node.value.left, context);
            this.addExpressionToWhere(node, context);
            this.Visit(node.value.right, context);
            this.query.where.replace(/= null/, "IS NULL");
        }
    }
    VisitNotEqualsExpression(node, context) {
        context.sign = "<>";
        if (!this.VisitDateType(node, context)) {
            this.Visit(node.value.left, context);
            this.addExpressionToWhere(node, context);
            this.Visit(node.value.right, context);
            this.query.where.replace(/<> null$/, "IS NOT NULL");
        }
    }
    VisitLiteral(node, context) {
        if (context.relation && context.target === enums_1.EnumQuery.Where) {
            const temp = this.query.where.toString().split(" ").filter(e => e != "");
            context.sign = temp.pop();
            this.query.where.init(temp.join(" "));
            this.query.where.add(` ${context.in && context.in === true ? '' : ' IN @START@'}(SELECT ${this.ctx.model[this.entity].relations[context.relation] ? (0, helpers_1.addDoubleQuotes)(this.ctx.model[this.entity].relations[context.relation]["relationKey"]) : `${(0, helpers_1.addDoubleQuotes)(this.ctx.model[context.relation].table)}."id"`} FROM ${(0, helpers_1.addDoubleQuotes)(this.ctx.model[context.relation].table)} WHERE `);
            context.in = true;
            if (context.identifier) {
                if (context.identifier.startsWith("CASE") || context.identifier.startsWith("("))
                    this.query.where.add(`${context.identifier} ${context.sign} ${sqlLiteral_1.SQLLiteral.convert(node.value, node.raw)})`);
                else if (context.identifier.includes("@EXPRESSION@")) {
                    const tempEntity = models_1.models.getEntity(this.ctx.config, context.relation);
                    const alias = tempEntity ? this.getColumnNameOrAlias(tempEntity, context.identifier, this.createDefaultOptions()) : undefined;
                    this.query.where.add((context.sql)
                        ? `${context.sql} ${context.target} ${(0, helpers_1.addDoubleQuotes)(context.identifier)}))@END@`
                        : `${alias ? alias : `${context.identifier.replace("@EXPRESSION@", ` ${sqlLiteral_1.SQLLiteral.convert(node.value, node.raw)} ${context.sign}`)}`})`);
                }
                else {
                    const tempEntity = models_1.models.getEntity(this.ctx.config, context.relation);
                    const quotes = context.identifier[0] === '"' ? '' : '"';
                    const alias = tempEntity ? this.getColumnNameOrAlias(tempEntity, context.identifier, this.createDefaultOptions()) : undefined;
                    this.query.where.add((context.sql)
                        ? `${context.sql} ${context.target} ${(0, helpers_1.addDoubleQuotes)(context.identifier)} ${context.sign} ${sqlLiteral_1.SQLLiteral.convert(node.value, node.raw)}))@END@`
                        : `${alias ? '' : `${this.ctx.model[context.relation].table}.`}${alias ? alias : `${quotes}${context.identifier}${quotes}`} ${context.sign} ${sqlLiteral_1.SQLLiteral.convert(node.value, node.raw)})`);
                }
            }
        }
        else {
            const temp = context.literal = node.value == "Edm.Boolean" ? node.raw : sqlLiteral_1.SQLLiteral.convert(node.value, node.raw);
            if (this.query.where.toString().includes("@EXPRESSION@"))
                this.query.where.replace("@EXPRESSION@", temp);
            else if (this.query.where.toString().includes("@EXPRESSIONSTRING@"))
                this.query.where.replace("@EXPRESSIONSTRING@", `${temp} ${context.sign}`);
            else
                this.query.where.add(temp);
        }
    }
    VisitInExpression(node, context) {
        this.Visit(node.value.left, context);
        this.query.where.add(" IN (");
        this.Visit(node.value.right, context);
        this.query.where.add(":list)");
    }
    VisitArrayOrObject(node, context) {
        this.query.where.add(context.literal = sqlLiteral_1.SQLLiteral.convert(node.value, node.raw));
    }
    createGeoColumn(entity, column) {
        column = (0, helpers_1.removeAllQuotes)(column);
        let test = undefined;
        const tempEntity = (typeof entity === "string") ? this.ctx.model[entity] : entity;
        if (column.includes("/")) {
            const temp = column.split("/");
            if (tempEntity.relations.hasOwnProperty(temp[0])) {
                const rel = tempEntity.relations[temp[0]];
                column = `(SELECT ${(0, helpers_1.addDoubleQuotes)(temp[1])} FROM ${(0, helpers_1.addDoubleQuotes)(rel.tableName)} WHERE ${rel.expand} AND length(${(0, helpers_1.addDoubleQuotes)(temp[1])}::text) > 2)`;
                test = this.ctx.model[rel.entityName].columns[temp[1]].test;
                if (test)
                    test = `(SELECT ${(0, helpers_1.addDoubleQuotes)(test)} FROM ${(0, helpers_1.addDoubleQuotes)(rel.tableName)} WHERE ${rel.expand})`;
            }
        }
        else if (!tempEntity.columns.hasOwnProperty(column)) {
            if (tempEntity.relations.hasOwnProperty(column)) {
                const rel = tempEntity.relations[column];
                column = `(SELECT ${(0, helpers_1.addDoubleQuotes)(rel.entityColumn)} FROM ${(0, helpers_1.addDoubleQuotes)(rel.tableName)} WHERE ${rel.expand} AND length(${(0, helpers_1.addDoubleQuotes)(rel.entityColumn)}::text) > 2)`;
                test = this.ctx.model[rel.entityName].columns[rel.entityColumn].test;
            }
            else
                throw new Error(`Invalid column ${column}`);
        }
        else {
            // TODO ADD addDoubleQuotes
            test = (0, helpers_1.addDoubleQuotes)(tempEntity.columns[column].test);
            column = (0, helpers_1.addDoubleQuotes)(column);
        }
        if (test)
            column = `CASE WHEN ${test} LIKE '%geo+json' THEN ST_GeomFromEWKT(ST_GeomFromGeoJSON(coalesce(${column}->'geometry',${column}))) ELSE ST_GeomFromEWKT(${column}::text) END`;
        return column;
    }
    VisitMethodCallExpression(node, context) {
        const method = node.value.method;
        const params = node.value.parameters || [];
        const isColumn = (input) => {
            const entity = this.ctx.model[this.entity];
            const column = typeof input === "string" ? input : decodeURIComponent(literal_1.Literal.convert(params[input].value, params[input].raw));
            if (column.includes("/")) {
                const temp = column.split("/");
                if (entity.relations.hasOwnProperty(temp[0]))
                    return this.ctx.model[entity.relations[temp[0]].entityName].columns[temp[1]].test;
            }
            else if (entity.columns.hasOwnProperty(column))
                return column;
            else if (entity.relations.hasOwnProperty(column))
                return this.ctx.model[entity.relations[column].entityName].columns[entity.relations[column].entityColumn].test;
        };
        const columnOrData = (index, operation, ForceString) => {
            const test = decodeURIComponent(literal_1.Literal.convert(params[index].value, params[index].raw));
            if (test === "result")
                return this.formatColumnResult(context, operation, ForceString);
            const column = isColumn(test);
            // return `${operation.trim() != "" ? `${operation}(` : '' } ${column ? addDoubleQuotes(column) : addSimpleQuotes(geoColumnOrData(index, false))}${operation.trim() != "" ? ")" : "" }`;
            return column ? (0, helpers_1.addDoubleQuotes)(column) : (0, helpers_1.addSimpleQuotes)(geoColumnOrData(index, false));
        };
        const geoColumnOrData = (index, srid) => {
            const temp = decodeURIComponent(literal_1.Literal.convert(params[index].value, params[index].raw)).replace("geography", "");
            return this.ctx.model[this.entity].columns[temp]
                ? temp
                : `${srid === true ? "SRID=4326;" : ""}${(0, helpers_1.removeAllQuotes)(temp)}`;
        };
        const cleanData = (index) => params[index].value == "Edm.String"
            ? (0, helpers_1.removeAllQuotes)(literal_1.Literal.convert(params[index].value, params[index].raw))
            : literal_1.Literal.convert(params[index].value, params[index].raw);
        const order = params.length === 2 ? isColumn(0) ? [0, 1] : [1, 0] : [0];
        switch (method) {
            case "contains":
                this.Visit(params[0], context);
                this.query.where.add(` ~* '${sqlLiteral_1.SQLLiteral.convert(params[1].value, params[1].raw).slice(1, -1)}'`);
                break;
            case "containsAny":
                this.query.where.add("array_to_string(");
                this.Visit(params[0], context);
                this.query.where.add(`, ' ') ~* '${sqlLiteral_1.SQLLiteral.convert(params[1].value, params[1].raw).slice(1, -1)}'`);
                break;
            case "endswith":
                this.query.where.add(`${columnOrData(0, "", true)}  ILIKE '%${cleanData(1)}'`);
                break;
            case "startswith":
                this.query.where.add(`${columnOrData(0, "", true)} ILIKE '${cleanData(1)}%'`);
                break;
            case "substring":
                this.query.where.add((params.length == 3)
                    ? ` SUBSTR(${columnOrData(0, "", true)}, ${cleanData(1)} + 1, ${cleanData(2)})`
                    : ` SUBSTR(${columnOrData(0, "", true)}, ${cleanData(1)} + 1)`);
                break;
            case "substringof":
                this.query.where.add(`${columnOrData(0, "", true)} ILIKE '%${cleanData(1)}%'`);
                break;
            case "indexof":
                this.query.where.add(` POSITION('${cleanData(1)}' IN ${columnOrData(0, "", true)})`);
                break;
            case "concat":
                this.query.where.add(`(${columnOrData(0, "concat", true)} || '${cleanData(1)}')`);
                break;
            case "length":
                // possibilty calc length string of each result or result 
                this.query.where.add((decodeURIComponent(literal_1.Literal.convert(params[0].value, params[0].raw)) === "result")
                    ? `${columnOrData(0, "CHAR_LENGTH", true)}`
                    : `CHAR_LENGTH(${columnOrData(0, "CHAR_LENGTH", true)})`);
                break;
            case "tolower":
                this.query.where.add(`LOWER(${columnOrData(0, "", true)})`);
                break;
            case "toupper":
                this.query.where.add(`UPPER(${columnOrData(0, "", true)})`);
                break;
            case "year":
            case "month":
            case "day":
            case "hour":
            case "minute":
            case "second":
                this.query.where.add(`EXTRACT(${method.toUpperCase()} FROM ${columnOrData(0, "", false)})`);
                break;
            case "round":
            case "floor":
            case "ceiling":
                this.query.where.add(columnOrData(0, method.toUpperCase(), false));
                break;
            case "now":
                this.query.where.add("NOW()");
                break;
            case "date":
                this.query.where.add(`${method.toUpperCase()}(`);
                this.Visit(params[0], context);
                this.query.where.add(")");
                break;
            case "time":
                this.query.where.add(`(${columnOrData(0, "", true)})::time`);
                break;
            case "geo.distance":
            case "geo.contains":
            case "geo.crosses":
            case "geo.disjoint":
            case "geo.equals":
            case "geo.overlaps":
            case "geo.relate":
            case "geo.touches":
            case "geo.within":
                this.query.where.add(`${method.toUpperCase().replace("GEO.", "ST_")}(${this.createGeoColumn(this.entity, columnOrData(order[0], "", true))}), ${columnOrData(order[1], "", true)}')`);
                break;
            case "geo.length":
                this.query.where.add(`ST_Length(ST_MakeLine(ST_AsText(${this.createGeoColumn(this.entity, columnOrData(order[0], "", true))}), ${columnOrData(order[1], "", true)}'))`);
                break;
            case "geo.intersects":
                this.query.where.add(`st_intersects(ST_AsText(${this.createGeoColumn(this.entity, columnOrData(order[0], "", true))}), ${columnOrData(order[1], "", true)})`);
                break;
            case "trim":
                this.query.where.add(`TRIM(BOTH '${params.length == 2 ? cleanData(1) : " "}' FROM ${columnOrData(0, "", true)})`);
                break;
            case "mindatetime":
                this.query.where.add(`MIN(${this.query.where.toString().split('" ')[0]}")`);
                break;
        }
    }
    toString() {
        return this.query.toString(this);
    }
    toPgQuery() {
        return this.query.toPgQuery(this);
    }
}
exports.PgVisitor = PgVisitor;
