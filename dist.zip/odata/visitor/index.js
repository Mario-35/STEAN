"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RootPgVisitor = exports.PgVisitor = void 0;
/**
 * Index of PgVisitor.
 *
 * @copyright 2020-present Inrae
 * @review 29-01-2024
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Index of PgVisitor. -----------------------------------!");
var pgVisitor_1 = require("./pg/pgVisitor");
Object.defineProperty(exports, "PgVisitor", { enumerable: true, get: function () { return pgVisitor_1.PgVisitor; } });
var rootPgVisitor_1 = require("./pg/rootPgVisitor");
Object.defineProperty(exports, "RootPgVisitor", { enumerable: true, get: function () { return rootPgVisitor_1.RootPgVisitor; } });
