"use strict";
/**
 * blankRootPgVisitor
 *
 * @copyright 2022-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- blankRootPgVisitor -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.blankRootPgVisitor = void 0;
const __1 = require("..");
const log_1 = require("../../../log");
const parser_1 = require("../../parser/parser");
const blankRootPgVisitor = (ctx, entity) => {
    const astRessources = (0, parser_1.resourcePath)(entity.name);
    const astQuery = (0, parser_1.query)(decodeURIComponent(`$top=${ctx.config.nb_page ? ctx.config.nb_page : 200}`));
    try {
        return new __1.RootPgVisitor(ctx, {
            onlyValue: false,
            onlyRef: false,
            valueskeys: false,
        }, astRessources).start(astQuery);
    }
    catch (error) {
        log_1.log.errorMsg(error);
        return undefined;
    }
};
exports.blankRootPgVisitor = blankRootPgVisitor;
