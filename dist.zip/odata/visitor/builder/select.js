"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Select = void 0;
/**
 * select for query builder.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
const _1 = require(".");
// onsole.log("!----------------------------------- select for query builder. -----------------------------------!");
class Select extends _1.Core {
    constructor(input) {
        super(input);
    }
}
exports.Select = Select;
