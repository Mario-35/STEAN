"use strict";
/**
 * Join builder
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Where builder -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.Join = void 0;
const _1 = require(".");
class Join extends _1.Core {
    constructor(input) {
        super(input);
    }
}
exports.Join = Join;
