"use strict";
/**
 * Query builder
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Query builder -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.Query = void 0;
const constants_1 = require("../../../constants");
const logger_1 = require("../../../logger");
const helpers_1 = require("../../../helpers");
const queries_1 = require("../../../db/queries");
const models_1 = require("../../../models");
const enums_1 = require("../../../enums");
const _1 = require(".");
const messages_1 = require("../../../messages");
const constants_2 = require("../../../db/constants");
class Query {
    where;
    select;
    orderBy;
    groupBy;
    keyNames;
    _pgQuery = undefined;
    constructor() {
        console.log(logger_1.formatLog.whereIam());
        this.where = new _1.Where();
        this.select = new _1.Select();
        this.orderBy = new _1.OrderBy();
        this.groupBy = new _1.GroupBy();
        this.keyNames = new _1.Key([]);
    }
    columnList(tableName, main, element) {
        const testIn = (input) => ["CONCAT", "CASE", "COALESCE"].map(e => input.includes(e) ? true : false).filter(e => e === true).length > 0;
        /**
         *
         * @param config config
         * @param entity entity name
         * @param column column name
         * @param options options
         * @returns formated column or
         */
        function formatedColumn(config, entity, column, options) {
            console.log(logger_1.formatLog.whereIam(column));
            if (entity.columns[column]) {
                // is column have alias
                const alias = entity.columns[column].alias(config, options ? options : undefined);
                if (testIn(alias || column) === true)
                    return alias || column;
                if (options) {
                    if (alias && options["alias"] === true)
                        return alias;
                    let result = "";
                    if (options["table"] === true && (testIn(alias || column) === false))
                        result += `${(0, helpers_1.addDoubleQuotes)(entity.table)}.`;
                    result += alias || options["quoted"] === true ? (0, helpers_1.addDoubleQuotes)(column) : column;
                    if (options["as"] === true || (alias && alias.includes("->")))
                        result += ` AS ${(0, helpers_1.addDoubleQuotes)(column)}`;
                    return result;
                }
                else
                    return column;
            }
            else if (testIn(column) === true)
                return column;
            if (column === "selfLink")
                return column;
        }
        ;
        function extractColumnName(input) {
            const elem = input.split(input.includes(' AS ') ? ' AS ' : ".");
            elem.shift();
            return elem.join(".");
        }
        // get good entity name
        const tempEntity = models_1.models.getEntity(main.ctx.config, tableName);
        if (!tempEntity) {
            console.log(logger_1.formatLog.error("no entity For", tableName));
            return;
        }
        // Add ceil and return if graph
        if ((0, helpers_1.isGraph)(main))
            return [main.interval
                    ? `timestamp_ceil("resultTime", interval '${main.interval}') AS srcdate`
                    : `@GRAPH@`];
        // If array result add id 
        const returnValue = (0, helpers_1.isCsvOrArray)(main) && !element.query.select.toString().includes(`"id"${constants_1._COLUMNSEPARATOR}`) ? ["id"] : [];
        // create selfLink                                   
        const selfLink = `CONCAT('${main.ctx.decodedUrl.root}/${tempEntity.name}(', "${tempEntity.table}"."id", ')') AS ${(0, helpers_1.addDoubleQuotes)(constants_2._SELFLINK)}`;
        // if $ref return only selfLink
        if (element.onlyRef == true)
            return [selfLink];
        if (element.showRelations == true)
            returnValue.push(selfLink);
        // create list of columns
        const columns = (element.query.select.toString() === "*" || element.query.select.toString() === "")
            ? Object.keys(tempEntity.columns)
                .filter((word) => !word.includes("_"))
                .filter(e => !(e === "result" && element.splitResult))
                .filter(e => !tempEntity.columns[e].extensions || tempEntity.columns[e].extensions && (0, helpers_1.containsAll)(main.ctx.config.extensions, tempEntity.columns[e].extensions) === true || "")
            : element.query.select.toString().split(constants_1._COLUMNSEPARATOR).filter((word) => word.trim() != "").map(e => (0, helpers_1.removeDoubleQuotes)(e));
        // loop on columns
        columns.map((column) => {
            const force = ["id", "result"].includes(column) ? true : false;
            return formatedColumn(main.ctx.config, tempEntity, column, { valueskeys: element.valueskeys, quoted: true, table: true, alias: force, as: (0, helpers_1.isGraph)(main) ? false : true }) || "";
        }).filter(e => e != "").forEach((e) => {
            if (e === "selfLink")
                e = selfLink;
            const testIisCsvOrArray = (0, helpers_1.isCsvOrArray)(element);
            if (testIisCsvOrArray)
                this.keyNames.add(e);
            returnValue.push(e);
            if (main.interval)
                main.addToIntervalColumns(extractColumnName(e));
            if (e === "id" && (element.showRelations == true || (0, helpers_1.isCsvOrArray)(main))) {
                if (testIisCsvOrArray)
                    this.keyNames.add("id");
                else
                    returnValue.push(selfLink);
            }
            if (testIisCsvOrArray && ["payload", "deveui", "phenomenonTime"].includes((0, helpers_1.removeAllQuotes)(e)))
                this.keyNames.add(e);
        });
        // add interval if requested
        if (main.interval)
            main.addToIntervalColumns(`CONCAT('${main.ctx.decodedUrl.root}/${tempEntity.name}(', COALESCE("@iot.id", '0')::text, ')') AS ${(0, helpers_1.addDoubleQuotes)(constants_2._SELFLINK)}`);
        // If observation entity
        if ((0, helpers_1.isObservation)(tempEntity) === true && element.onlyRef === false) {
            if (main.interval && !(0, helpers_1.isGraph)(main))
                returnValue.push(`timestamp_ceil("resultTime", interval '${main.interval}') AS srcdate`);
            if (element.splitResult)
                element.splitResult.forEach((elem) => {
                    const one = element && element.splitResult && element.splitResult.length === 1;
                    const alias = one ? "result" : elem;
                    returnValue.push(`(result->>'valueskeys')::json->'${element.splitResult && one ? (0, helpers_1.removeAllQuotes)(element.splitResult[0]) : alias}' AS "${one ? elem : alias}"`);
                    this.keyNames.add(one ? elem : alias);
                });
        }
        return returnValue;
    }
    // Create SQL Query
    create(main, _element) {
        const element = _element ? _element : main;
        console.log(logger_1.formatLog.whereIam(element.entity || "blank"));
        if (element.entity.trim() !== "") {
            // get columns
            const select = this.columnList(element.entity, main, element);
            // if not null
            if (select) {
                // Get real entity name (plural)
                const realEntityName = models_1.models.getEntityName(main.ctx.config, element.entity);
                if (realEntityName) {
                    // Create relations list
                    const relations = Object.keys(main.ctx.model[realEntityName].relations);
                    // loop includes
                    if (element.includes)
                        element.includes.forEach((item) => {
                            const name = item.navigationProperty;
                            const index = relations.indexOf(name);
                            // if is relation
                            if (index >= 0) {
                                item.entity = name;
                                item.query.where.add(`${item.query.where.notNull() === true ? " AND " : ''}${main.ctx.model[realEntityName].relations[name].expand}`);
                                // create sql query    for this relatiion (IN JSON result)   
                                const query = this.pgQueryToString(this.create(item));
                                if (query)
                                    relations[index] = `(${(0, queries_1.asJson)({
                                        query: query,
                                        singular: models_1.models.isSingular(main.ctx.config, name),
                                        strip: main.ctx.config.options.includes(enums_1.EnumOptions.stripNull),
                                        count: false
                                    })}) AS ${(0, helpers_1.addDoubleQuotes)(name)}`;
                                else
                                    throw new Error(messages_1.errors.invalidQuery);
                            }
                        });
                    // create all relations Query
                    relations
                        .filter(e => e.includes('SELECT') || Object.keys(main.ctx.model).includes(models_1.models.getEntityName(main.ctx.config, e) || e))
                        .forEach((rel) => {
                        if (rel[0] == "(")
                            select.push(rel);
                        else if (element.showRelations == true && main.onlyRef == false) {
                            const tempTable = models_1.models.getEntityName(main.ctx.config, rel);
                            let stream = undefined;
                            if (tempTable && !main.ctx.model[realEntityName].relations[rel].relationKey.startsWith("_"))
                                if (main.ctx.config.options.includes(enums_1.EnumOptions.stripNull) && realEntityName === main.ctx.model[enums_1.allEntities.Observations].name && tempTable.endsWith(main.ctx.model[enums_1.allEntities.Datastreams].name))
                                    stream = `CASE WHEN ${main.ctx.model[tempTable].table}_id NOTNULL THEN`;
                            select.push(`${stream ? stream : ""} CONCAT('${main.ctx.decodedUrl.root}/${main.ctx.model[realEntityName].name}(', ${(0, helpers_1.addDoubleQuotes)(main.ctx.model[realEntityName].table)}."id", ')/${rel}') ${stream ? "END " : ""}AS "${rel}${constants_2._NAVLINK}"`);
                            main.addToIntervalColumns(`'${main.ctx.decodedUrl.root}/${main.ctx.model[realEntityName].name}(0)/${rel}' AS "${rel}${constants_2._NAVLINK}"`);
                        }
                    });
                    return {
                        select: select.join(",\n\t\t"),
                        from: main.ctx.model[realEntityName].table,
                        where: element.query.where.toString(),
                        groupBy: element.query.groupBy.notNull() === true ? element.query.groupBy.toString() : undefined,
                        orderBy: element.query.orderBy.notNull() === true ? element.query.orderBy.toString() : main.ctx.model[realEntityName].orderBy,
                        skip: element.skip,
                        limit: element.limit,
                        keys: this.keyNames.toArray(),
                        count: `SELECT COUNT (DISTINCT ${Object.keys(main.ctx.model[realEntityName].columns)[0]}) FROM (SELECT ${Object.keys(main.ctx.model[realEntityName].columns)[0]} FROM "${main.ctx.model[realEntityName].table}"${element.query.where.notNull() === true ? ` WHERE ${element.query.where.toString()}` : ''}) AS c`
                    };
                }
            }
        }
        return undefined;
    }
    pgQueryToString(input) {
        return input ?
            `SELECT ${input.select}\n FROM "${input.from}"\n ${input.where
                ? `WHERE ${input.where}\n`
                : ''}${input.groupBy
                ? `GROUP BY ${(0, helpers_1.cleanStringComma)(input.groupBy)}\n`
                : ''}${input.orderBy
                ? `ORDER BY ${(0, helpers_1.cleanStringComma)(input.orderBy, ["ASC", "DESC"])}\n`
                : ''}${input.skip && input.skip > 0
                ? `OFFSET ${input.skip}\n`
                : ''} ${input.limit && input.limit > 0
                ? `LIMIT ${input.limit}\n`
                : ''}`
            : undefined;
    }
    toString(main, _element) {
        console.log(logger_1.formatLog.whereIam());
        if (!this._pgQuery)
            this._pgQuery = this.create(main, _element);
        const query = this.pgQueryToString(this._pgQuery);
        if (query)
            return query;
        throw new Error(messages_1.errors.invalidQuery);
    }
    toPgQuery(main, _element) {
        console.log(logger_1.formatLog.whereIam());
        if (!this._pgQuery)
            this._pgQuery = this.create(main, _element);
        return this._pgQuery;
    }
}
exports.Query = Query;
