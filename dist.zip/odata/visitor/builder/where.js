"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Where = void 0;
/**
 * Where builder
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
const _1 = require(".");
// onsole.log("!----------------------------------- Where builder -----------------------------------!");
class Where extends _1.Core {
    constructor(input) {
        super(input);
    }
}
exports.Where = Where;
