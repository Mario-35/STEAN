"use strict";
/**
 * version Enum
 *
 * @copyright 2020-present Inrae
 * @review 29-10-2024
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- version Enum -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.EVersion = void 0;
var EVersion;
(function (EVersion) {
    EVersion["v1_0"] = "v1.0";
    EVersion["v1_1"] = "v1.1";
})(EVersion || (exports.EVersion = EVersion = {}));
