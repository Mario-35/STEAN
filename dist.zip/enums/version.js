"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnumVersion = void 0;
/**
 * version Enum.
 *
 * @copyright 2020-present Inrae
 * @review 29-10-2024
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- version Enum. -----------------------------------!");
var EnumVersion;
(function (EnumVersion) {
    EnumVersion["v1_0"] = "v1.0";
    EnumVersion["v1_1"] = "v1.1";
})(EnumVersion || (exports.EnumVersion = EnumVersion = {}));
