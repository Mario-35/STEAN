"use strict";
/**
 * Index Enums.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Index Enums. -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.typeOptions = exports.typeExtensions = exports.enumKeys = exports.EnumUserRights = exports.EnumQuery = exports.EnumUpdate = exports.EnumOptions = exports.EnumRelations = exports.EnumOperation = exports.EnumObservationType = exports.EnumVersion = exports.EnumResultFormats = exports.EnumExtensions = exports.filterEntities = exports.allEntities = exports.EnumDatesType = exports.EnumColumnType = exports.EnumColor = void 0;
const extensions_1 = require("./extensions");
const options_1 = require("./options");
var colors_1 = require("./colors");
Object.defineProperty(exports, "EnumColor", { enumerable: true, get: function () { return colors_1.EnumColor; } });
var colType_1 = require("./colType");
Object.defineProperty(exports, "EnumColumnType", { enumerable: true, get: function () { return colType_1.EnumColumnType; } });
var datesType_1 = require("./datesType");
Object.defineProperty(exports, "EnumDatesType", { enumerable: true, get: function () { return datesType_1.EnumDatesType; } });
var entities_1 = require("./entities");
Object.defineProperty(exports, "allEntities", { enumerable: true, get: function () { return entities_1.allEntities; } });
Object.defineProperty(exports, "filterEntities", { enumerable: true, get: function () { return entities_1.filterEntities; } });
var extensions_2 = require("./extensions");
Object.defineProperty(exports, "EnumExtensions", { enumerable: true, get: function () { return extensions_2.EnumExtensions; } });
var resultFormats_1 = require("./resultFormats");
Object.defineProperty(exports, "EnumResultFormats", { enumerable: true, get: function () { return resultFormats_1.EnumResultFormats; } });
var version_1 = require("./version");
Object.defineProperty(exports, "EnumVersion", { enumerable: true, get: function () { return version_1.EnumVersion; } });
var observationType_1 = require("./observationType");
Object.defineProperty(exports, "EnumObservationType", { enumerable: true, get: function () { return observationType_1.EnumObservationType; } });
var operation_1 = require("./operation");
Object.defineProperty(exports, "EnumOperation", { enumerable: true, get: function () { return operation_1.EnumOperation; } });
var relations_1 = require("./relations");
Object.defineProperty(exports, "EnumRelations", { enumerable: true, get: function () { return relations_1.EnumRelations; } });
var options_2 = require("./options");
Object.defineProperty(exports, "EnumOptions", { enumerable: true, get: function () { return options_2.EnumOptions; } });
var update_1 = require("./update");
Object.defineProperty(exports, "EnumUpdate", { enumerable: true, get: function () { return update_1.EnumUpdate; } });
var query_1 = require("./query");
Object.defineProperty(exports, "EnumQuery", { enumerable: true, get: function () { return query_1.EnumQuery; } });
var userRights_1 = require("./userRights");
Object.defineProperty(exports, "EnumUserRights", { enumerable: true, get: function () { return userRights_1.EnumUserRights; } });
const enumKeys = (input) => Object.keys(input).filter(prop => isNaN(parseInt(prop)));
exports.enumKeys = enumKeys;
exports.typeExtensions = Object.keys(extensions_1.EnumExtensions);
exports.typeOptions = Object.keys(options_1.EnumOptions);
