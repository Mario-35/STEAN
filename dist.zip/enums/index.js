"use strict";
/**
 * Index Enums.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Index Enums. -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.typeOptions = exports.typeExtensions = exports.enumKeys = exports.EUserRights = exports.EQuery = exports.EUpdate = exports.EOptions = exports.ERelations = exports.EOperation = exports.EObservationType = exports.EVersion = exports.EReturnFormats = exports.EExtensions = exports.filterEntities = exports.allEntities = exports.EDatesType = exports.EColumnType = exports.EColor = void 0;
const extensions_1 = require("./extensions");
const options_1 = require("./options");
var colors_1 = require("./colors");
Object.defineProperty(exports, "EColor", { enumerable: true, get: function () { return colors_1.EColor; } });
var colType_1 = require("./colType");
Object.defineProperty(exports, "EColumnType", { enumerable: true, get: function () { return colType_1.EColumnType; } });
var datesType_1 = require("./datesType");
Object.defineProperty(exports, "EDatesType", { enumerable: true, get: function () { return datesType_1.EDatesType; } });
var entities_1 = require("./entities");
Object.defineProperty(exports, "allEntities", { enumerable: true, get: function () { return entities_1.allEntities; } });
Object.defineProperty(exports, "filterEntities", { enumerable: true, get: function () { return entities_1.filterEntities; } });
var extensions_2 = require("./extensions");
Object.defineProperty(exports, "EExtensions", { enumerable: true, get: function () { return extensions_2.EExtensions; } });
var resultFormats_1 = require("./resultFormats");
Object.defineProperty(exports, "EReturnFormats", { enumerable: true, get: function () { return resultFormats_1.EReturnFormats; } });
var version_1 = require("./version");
Object.defineProperty(exports, "EVersion", { enumerable: true, get: function () { return version_1.EVersion; } });
var observationType_1 = require("./observationType");
Object.defineProperty(exports, "EObservationType", { enumerable: true, get: function () { return observationType_1.EObservationType; } });
var operation_1 = require("./operation");
Object.defineProperty(exports, "EOperation", { enumerable: true, get: function () { return operation_1.EOperation; } });
var relations_1 = require("./relations");
Object.defineProperty(exports, "ERelations", { enumerable: true, get: function () { return relations_1.ERelations; } });
var options_2 = require("./options");
Object.defineProperty(exports, "EOptions", { enumerable: true, get: function () { return options_2.EOptions; } });
var update_1 = require("./update");
Object.defineProperty(exports, "EUpdate", { enumerable: true, get: function () { return update_1.EUpdate; } });
var query_1 = require("./query");
Object.defineProperty(exports, "EQuery", { enumerable: true, get: function () { return query_1.EQuery; } });
var userRights_1 = require("./userRights");
Object.defineProperty(exports, "EUserRights", { enumerable: true, get: function () { return userRights_1.EUserRights; } });
const enumKeys = (input) => Object.keys(input).filter(prop => isNaN(parseInt(prop)));
exports.enumKeys = enumKeys;
exports.typeExtensions = Object.keys(extensions_1.EExtensions);
exports.typeOptions = Object.keys(options_1.EOptions);
