"use strict";
/**
 * EnumUpdate Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- EnumUpdate Enum -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnumUpdate = void 0;
var EnumUpdate;
(function (EnumUpdate) {
    EnumUpdate["beforeAll"] = "beforeAll";
    EnumUpdate["afterAll"] = "afterAll";
    EnumUpdate["decoders"] = "decoders";
    EnumUpdate["triggers"] = "triggers";
})(EnumUpdate || (exports.EnumUpdate = EnumUpdate = {}));
