"use strict";
/**
 * EUpdate Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- EUpdate Enum -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.EUpdate = void 0;
var EUpdate;
(function (EUpdate) {
    EUpdate["beforeAll"] = "beforeAll";
    EUpdate["afterAll"] = "afterAll";
    EUpdate["decoders"] = "decoders";
    EUpdate["triggers"] = "triggers";
})(EUpdate || (exports.EUpdate = EUpdate = {}));
