"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnumUserRights = void 0;
/**
 * userRights Enum.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- userRights Enum. -----------------------------------!");
var EnumUserRights;
(function (EnumUserRights) {
    EnumUserRights[EnumUserRights["Post"] = 0] = "Post";
    EnumUserRights[EnumUserRights["Delete"] = 1] = "Delete";
    EnumUserRights[EnumUserRights["Create"] = 2] = "Create";
    EnumUserRights[EnumUserRights["UserCreate"] = 3] = "UserCreate";
    EnumUserRights[EnumUserRights["Admin"] = 4] = "Admin";
    EnumUserRights[EnumUserRights["SuperAdmin"] = 5] = "SuperAdmin";
})(EnumUserRights || (exports.EnumUserRights = EnumUserRights = {}));
