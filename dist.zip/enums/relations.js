"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnumRelations = void 0;
/**
 * relations Enum.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- relations Enum. -----------------------------------!");
var EnumRelations;
(function (EnumRelations) {
    EnumRelations[EnumRelations["belongsTo"] = 0] = "belongsTo";
    EnumRelations[EnumRelations["belongsToMany"] = 1] = "belongsToMany";
    EnumRelations[EnumRelations["hasMany"] = 2] = "hasMany";
})(EnumRelations || (exports.EnumRelations = EnumRelations = {}));
