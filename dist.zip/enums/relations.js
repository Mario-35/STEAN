"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ERelations = void 0;
/**
 * relations Enum.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- relations Enum. -----------------------------------!");
var ERelations;
(function (ERelations) {
    ERelations[ERelations["belongsTo"] = 0] = "belongsTo";
    ERelations[ERelations["belongsToMany"] = 1] = "belongsToMany";
    ERelations[ERelations["hasMany"] = 2] = "hasMany";
})(ERelations || (exports.ERelations = ERelations = {}));
