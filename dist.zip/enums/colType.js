"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnumColumnType = void 0;
/**
 * columnType Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- columnType Enum -----------------------------------!");
var EnumColumnType;
(function (EnumColumnType) {
    EnumColumnType[EnumColumnType["Null"] = 0] = "Null";
    EnumColumnType[EnumColumnType["Column"] = 1] = "Column";
    EnumColumnType[EnumColumnType["SelfLink"] = 2] = "SelfLink";
    EnumColumnType[EnumColumnType["Relation"] = 3] = "Relation";
    EnumColumnType[EnumColumnType["Table"] = 4] = "Table";
})(EnumColumnType || (exports.EnumColumnType = EnumColumnType = {}));
