"use strict";
/**
 * fileName Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- fileName Enum -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.EFileName = void 0;
var EFileName;
(function (EFileName) {
    EFileName["logs"] = "logs.html";
    EFileName["logsBak"] = "logs.bak";
    EFileName["config"] = "configuration.json";
    EFileName["key"] = ".key";
})(EFileName || (exports.EFileName = EFileName = {}));
