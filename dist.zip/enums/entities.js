"use strict";
/**
 * entities Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- entities Enum -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.allEntities = exports.filterEntities = void 0;
const _1 = require(".");
var EnumBaseEntities;
(function (EnumBaseEntities) {
    EnumBaseEntities["Things"] = "Things";
    EnumBaseEntities["FeaturesOfInterest"] = "FeaturesOfInterest";
    EnumBaseEntities["Locations"] = "Locations";
    EnumBaseEntities["HistoricalLocations"] = "HistoricalLocations";
    EnumBaseEntities["locationsHistoricalLocations"] = "locationsHistoricalLocations";
    EnumBaseEntities["ObservedProperties"] = "ObservedProperties";
    EnumBaseEntities["Sensors"] = "Sensors";
    EnumBaseEntities["Datastreams"] = "Datastreams";
    EnumBaseEntities["Observations"] = "Observations";
    EnumBaseEntities["HistoricalObservations"] = "HistoricalObservations";
    EnumBaseEntities["ThingsLocations"] = "ThingsLocations";
    EnumBaseEntities["CreateObservations"] = "CreateObservations";
    EnumBaseEntities["CreateFile"] = "CreateFile";
    EnumBaseEntities["Configs"] = "Configs";
})(EnumBaseEntities || (EnumBaseEntities = {}));
var EnumMultiDatastreamEntities;
(function (EnumMultiDatastreamEntities) {
    EnumMultiDatastreamEntities["MultiDatastreams"] = "MultiDatastreams";
    EnumMultiDatastreamEntities["MultiDatastreamObservedProperties"] = "MultiDatastreamObservedProperties";
})(EnumMultiDatastreamEntities || (EnumMultiDatastreamEntities = {}));
var EnumUsersEntities;
(function (EnumUsersEntities) {
    EnumUsersEntities["Users"] = "Users";
})(EnumUsersEntities || (EnumUsersEntities = {}));
var EnumLoraEntities;
(function (EnumLoraEntities) {
    EnumLoraEntities["Decoders"] = "Decoders";
    EnumLoraEntities["Loras"] = "Loras";
})(EnumLoraEntities || (EnumLoraEntities = {}));
var EnumLogEntities;
(function (EnumLogEntities) {
    EnumLogEntities["Logs"] = "Logs";
})(EnumLogEntities || (EnumLogEntities = {}));
const filterEntities = (exts, name) => {
    // const exts = (typeof input === "string") ? input === "ALL" ? Object.keys(EnumExtensions) : serverConfig.getConfig(input).extensions : input.extensions;
    let res = EnumBaseEntities;
    if (exts.includes(_1.EnumExtensions.logs))
        res = { ...res, ...EnumLogEntities };
    if (exts.includes(_1.EnumExtensions.multiDatastream))
        res = { ...res, ...EnumMultiDatastreamEntities };
    if (exts.includes(_1.EnumExtensions.lora))
        res = { ...res, ...EnumLoraEntities };
    if (exts.includes(_1.EnumExtensions.users))
        res = { ...res, ...EnumUsersEntities };
    return res;
};
exports.filterEntities = filterEntities;
exports.allEntities = { ...EnumBaseEntities, ...EnumMultiDatastreamEntities, ...EnumUsersEntities, ...EnumLoraEntities, ...EnumLogEntities };
