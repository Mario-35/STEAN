"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnumOptions = void 0;
/**
 * EnumOptions Enum.
 *
 * @copyright 2020-present Inrae
 * @review 29-10-2024
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- EnumOptions Enum. -----------------------------------!");
var EnumOptions;
(function (EnumOptions) {
    EnumOptions["forceHttps"] = "forceHttps";
    EnumOptions["stripNull"] = "stripNull";
    EnumOptions["canDrop"] = "canDrop";
})(EnumOptions || (exports.EnumOptions = EnumOptions = {}));
