"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EDatesType = void 0;
/**
 * datesType Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- datesType Enum -----------------------------------!");
var EDatesType;
(function (EDatesType) {
    EDatesType["date"] = "YYYY-MM-DD\"T\"HH24:MI:SSZ";
    EDatesType["dateWithTimeZone"] = "YYYY-MM-DD HH:MI:SSTZH:TZM";
    EDatesType["dateWithOutTimeZone"] = "YYYY-MM-DDXHH24:MI:SS";
})(EDatesType || (exports.EDatesType = EDatesType = {}));
