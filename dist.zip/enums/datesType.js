"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnumDatesType = void 0;
/**
 * datesType Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- datesType Enum -----------------------------------!");
var EnumDatesType;
(function (EnumDatesType) {
    EnumDatesType["date"] = "YYYY-MM-DD\"T\"HH24:MI:SSZ";
    EnumDatesType["dateWithTimeZone"] = "YYYY-MM-DD HH:MI:SSTZH:TZM";
    EnumDatesType["dateWithOutTimeZone"] = "YYYY-MM-DDXHH24:MI:SS";
})(EnumDatesType || (exports.EnumDatesType = EnumDatesType = {}));
