"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnumOperation = void 0;
/**
 * operation Enum.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- operation Enum. -----------------------------------!");
var EnumOperation;
(function (EnumOperation) {
    EnumOperation[EnumOperation["Table"] = 0] = "Table";
    EnumOperation[EnumOperation["Relation"] = 1] = "Relation";
    EnumOperation[EnumOperation["Association"] = 2] = "Association";
})(EnumOperation || (exports.EnumOperation = EnumOperation = {}));
