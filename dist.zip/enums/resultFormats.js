"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnumResultFormats = void 0;
/**
 * formats Enum.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- formats Enum. -----------------------------------!");
var EnumResultFormats;
(function (EnumResultFormats) {
    EnumResultFormats["json"] = "json";
    EnumResultFormats["csv"] = "csv";
    EnumResultFormats["txt"] = "txt";
    EnumResultFormats["sql"] = "sql";
    EnumResultFormats["html"] = "html";
    EnumResultFormats["icon"] = "icon";
    EnumResultFormats["graph"] = "graph";
    EnumResultFormats["graphDatas"] = "graphDatas";
    EnumResultFormats["dataArray"] = "dataArray";
    EnumResultFormats["css"] = "css";
    EnumResultFormats["js"] = "js";
    EnumResultFormats["png"] = "png";
    EnumResultFormats["jpg"] = "jpg";
    EnumResultFormats["jpeg"] = "jpeg";
    EnumResultFormats["ico"] = "ico";
    EnumResultFormats["xlsx"] = "xlsx";
    EnumResultFormats["xml"] = "xml";
})(EnumResultFormats || (exports.EnumResultFormats = EnumResultFormats = {}));
