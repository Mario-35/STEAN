"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EColor = void 0;
/**
 * colors Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- colors Enum -----------------------------------!");
var EColor;
(function (EColor) {
    EColor[EColor["Reset"] = 0] = "Reset";
    EColor[EColor["Bright"] = 1] = "Bright";
    EColor[EColor["Dim"] = 2] = "Dim";
    EColor[EColor["Underscore"] = 4] = "Underscore";
    EColor[EColor["Blink"] = 5] = "Blink";
    EColor[EColor["Reverse"] = 7] = "Reverse";
    EColor[EColor["Hidden"] = 8] = "Hidden";
    EColor[EColor["FgBlack"] = 30] = "FgBlack";
    EColor[EColor["FgRed"] = 31] = "FgRed";
    EColor[EColor["FgGreen"] = 32] = "FgGreen";
    EColor[EColor["FgYellow"] = 33] = "FgYellow";
    EColor[EColor["FgBlue"] = 34] = "FgBlue";
    EColor[EColor["FgMagenta"] = 35] = "FgMagenta";
    EColor[EColor["FgCyan"] = 36] = "FgCyan";
    EColor[EColor["FgWhite"] = 37] = "FgWhite";
    EColor[EColor["FgFadeWhite"] = 39] = "FgFadeWhite";
    EColor[EColor["FgGray"] = 90] = "FgGray";
    EColor[EColor["BgBlack"] = 40] = "BgBlack";
    EColor[EColor["BgRed"] = 41] = "BgRed";
    EColor[EColor["BgGreen"] = 42] = "BgGreen";
    EColor[EColor["BgYellow"] = 43] = "BgYellow";
    EColor[EColor["BgBlue"] = 44] = "BgBlue";
    EColor[EColor["BgMagenta"] = 45] = "BgMagenta";
    EColor[EColor["BgCyan"] = 46] = "BgCyan";
    EColor[EColor["BgWhite"] = 47] = "BgWhite";
    EColor[EColor["BgGray"] = 100] = "BgGray";
})(EColor || (exports.EColor = EColor = {}));
