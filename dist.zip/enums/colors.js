"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnumColor = void 0;
/**
 * colors Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- colors Enum -----------------------------------!");
var EnumColor;
(function (EnumColor) {
    EnumColor[EnumColor["Reset"] = 0] = "Reset";
    EnumColor[EnumColor["Bright"] = 1] = "Bright";
    EnumColor[EnumColor["Dim"] = 2] = "Dim";
    EnumColor[EnumColor["Underscore"] = 4] = "Underscore";
    EnumColor[EnumColor["Blink"] = 5] = "Blink";
    EnumColor[EnumColor["Reverse"] = 7] = "Reverse";
    EnumColor[EnumColor["Hidden"] = 8] = "Hidden";
    EnumColor[EnumColor["FgBlack"] = 30] = "FgBlack";
    EnumColor[EnumColor["FgRed"] = 31] = "FgRed";
    EnumColor[EnumColor["FgGreen"] = 32] = "FgGreen";
    EnumColor[EnumColor["FgYellow"] = 33] = "FgYellow";
    EnumColor[EnumColor["FgBlue"] = 34] = "FgBlue";
    EnumColor[EnumColor["FgMagenta"] = 35] = "FgMagenta";
    EnumColor[EnumColor["FgCyan"] = 36] = "FgCyan";
    EnumColor[EnumColor["FgWhite"] = 37] = "FgWhite";
    EnumColor[EnumColor["FgFadeWhite"] = 39] = "FgFadeWhite";
    EnumColor[EnumColor["FgGray"] = 90] = "FgGray";
    EnumColor[EnumColor["BgBlack"] = 40] = "BgBlack";
    EnumColor[EnumColor["BgRed"] = 41] = "BgRed";
    EnumColor[EnumColor["BgGreen"] = 42] = "BgGreen";
    EnumColor[EnumColor["BgYellow"] = 43] = "BgYellow";
    EnumColor[EnumColor["BgBlue"] = 44] = "BgBlue";
    EnumColor[EnumColor["BgMagenta"] = 45] = "BgMagenta";
    EnumColor[EnumColor["BgCyan"] = 46] = "BgCyan";
    EnumColor[EnumColor["BgWhite"] = 47] = "BgWhite";
    EnumColor[EnumColor["BgGray"] = 100] = "BgGray";
})(EnumColor || (exports.EnumColor = EnumColor = {}));
