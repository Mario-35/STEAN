"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnumQuery = void 0;
/**
 * EnumQuery Enum.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- EnumQuery Enum. -----------------------------------!");
var EnumQuery;
(function (EnumQuery) {
    EnumQuery["Where"] = "where";
    EnumQuery["Select"] = "select";
    EnumQuery["GroubBy"] = "groubBy";
    EnumQuery["OrderBy"] = "orderBy";
})(EnumQuery || (exports.EnumQuery = EnumQuery = {}));
