"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnumObservationType = void 0;
/**
 * observationType Enum.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- observationType Enum. -----------------------------------!");
var EnumObservationType;
(function (EnumObservationType) {
    EnumObservationType["http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_CategoryObservation"] = "_resulttext";
    EnumObservationType["http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_CountObservation"] = "number";
    EnumObservationType["http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"] = "number";
    EnumObservationType["http://www.opengis.net/def/observation-type/ogc-om/2.0/om_complex-observation"] = "array";
    EnumObservationType["http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Observation"] = "any";
    EnumObservationType["http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_TruthObservation"] = "_resultBoolean";
    EnumObservationType["http://www.opengis.net/def/observation-type/ogc-omxml/2.0/swe-array-observation"] = "object";
})(EnumObservationType || (exports.EnumObservationType = EnumObservationType = {}));
