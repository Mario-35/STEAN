"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.writeToLog = void 0;
/**
 * writeToLog.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- writeToLog. -----------------------------------!");
const _1 = require(".");
const helpers_1 = require("../helpers");
const helpers_2 = require("../db/helpers");
const models_1 = require("../models");
const log_1 = require("../log");
const helpers_3 = require("../models/helpers");
const constants_1 = require("../db/constants");
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const writeToLog = async (ctx, ...error) => {
    console.log(_1.formatLog.whereIam("LOG"));
    if (error.length > 0)
        _1.formatLog.writeErrorInFile(ctx, error);
    if (ctx.log && ctx.log.method != "GET") {
        ctx.log.code = error && error["code"] ? +error["code"] : +ctx.response.status;
        ctx.log.error = error;
        ctx.log.datas = (0, helpers_1.hidePassword)(ctx.log.datas);
        try {
            if (ctx.body && ctx.body && typeof ctx.body === "string")
                ctx.log.returnid = JSON.parse(ctx.body)[constants_1._ID];
        }
        catch (error) {
            ctx.log.returnid = undefined;
        }
        const code = Math.floor(ctx.log.code / 100);
        if (code == 2 || code == 3)
            return;
        await (0, helpers_2.executeSqlValues)(ctx.config, `INSERT INTO ${(0, helpers_1.addDoubleQuotes)(models_1.models.DBFull(ctx.config).Logs.table)} ${(0, helpers_3.createInsertValues)(ctx.config, ctx.log, models_1.models.DBFull(ctx.config).Logs.name)} returning id`).then((res) => {
            if (!(0, helpers_1.isTest)())
                console.log(_1.formatLog.url(`${ctx.decodedUrl.root}/Logs(${res[0]})`));
        }).catch((error) => {
            log_1.log.errorMsg(error);
        });
    }
};
exports.writeToLog = writeToLog;
