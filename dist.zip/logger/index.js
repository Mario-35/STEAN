"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatLog = exports.writeToLog = void 0;
/**
 * Index Logs
 *
 * @copyright 2020-present Inrae
 * @review 29-01-2024
 * @author mario.adam@inrae.fr
 *
 */
const util_1 = __importDefault(require("util"));
const constants_1 = require("../constants");
const fs_1 = __importDefault(require("fs"));
var writeToLog_1 = require("./writeToLog");
Object.defineProperty(exports, "writeToLog", { enumerable: true, get: function () { return writeToLog_1.writeToLog; } });
// onsole.log("!----------------------------------- Index Logs -----------------------------------!");
class FormatLog {
    debugFile = false;
    line = (nb) => "=".repeat(nb);
    logAll = (input, colors) => typeof input === "object" ? util_1.default.inspect(input, { showHidden: false, depth: null, colors: colors || false, }) : input;
    separator = (title, nb) => `${(0, constants_1.color)(32 /* EColor.FgGreen */)} ${this.line(nb)} ${(0, constants_1.color)(33 /* EColor.FgYellow */)} ${title} ${(0, constants_1.color)(32 /* EColor.FgGreen */)} ${this.line(nb)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    logCleInfos = (cle, infos) => `${(0, constants_1.color)(32 /* EColor.FgGreen */)} ${cle} ${(0, constants_1.color)(37 /* EColor.FgWhite */)} : ${(0, constants_1.color)(36 /* EColor.FgCyan */)} ${this.logAll(infos, this.debugFile)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    constructor() {
        // override console log important in production build will remove all console.log
        console.log = (data) => {
            if (data && process.env.NODE_ENV?.trim() !== constants_1.TEST)
                this.write(data);
        };
    }
    write(data) {
        process.stdout.write(util_1.default.format.apply(null, [data]) + "\n");
    }
    // log an object or json
    object(title, input) {
        if (constants_1._DEBUG) {
            const res = [this.head(title)];
            Object.keys(input).forEach((cle) => {
                res.push(this.logCleInfos("  " + cle, input[cle]));
            });
            return res.join("\n");
        }
    }
    url(link) {
        return `${constants_1._WEB} ${(0, constants_1.color)(39 /* EColor.FgFadeWhite */)} : ${(0, constants_1.color)(36 /* EColor.FgCyan */)} ${link}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    head(cle, infos) {
        if (constants_1._DEBUG)
            return infos ? `${(0, constants_1.color)(32 /* EColor.FgGreen */)} ${this.line(12)} ${(0, constants_1.color)(36 /* EColor.FgCyan */)} ${cle} ${(0, constants_1.color)(37 /* EColor.FgWhite */)} ${this.logAll(infos, this.debugFile)} ${(0, constants_1.color)(32 /* EColor.FgGreen */)} ${this.line(12)}${(0, constants_1.color)(0 /* EColor.Reset */)}` : this.separator(cle, 12);
    }
    infos(cle, input) {
        if (constants_1._DEBUG)
            return `${this.separator(cle, 30)} ${(0, constants_1.color)(33 /* EColor.FgYellow */)} ${this.logAll(input, true)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    debug(cle, infos) {
        if (constants_1._DEBUG)
            return `${(0, constants_1.color)(32 /* EColor.FgGreen */)} ${cle} ${(0, constants_1.color)(37 /* EColor.FgWhite */)} : ${(0, constants_1.color)(36 /* EColor.FgCyan */)} ${this.logAll(infos, this.debugFile)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    result(cle, infos) {
        if (constants_1._DEBUG)
            return `${(0, constants_1.color)(32 /* EColor.FgGreen */)}     >>${(0, constants_1.color)(30 /* EColor.FgBlack */)} ${cle} ${(0, constants_1.color)(39 /* EColor.FgFadeWhite */)} : ${(0, constants_1.color)(36 /* EColor.FgCyan */)} ${this.logAll(infos, this.debugFile)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    error(cle, infos) {
        return infos
            ? `${(0, constants_1.color)(31 /* EColor.FgRed */)} ${cle} ${(0, constants_1.color)(34 /* EColor.FgBlue */)} : ${(0, constants_1.color)(33 /* EColor.FgYellow */)} ${this.logAll(infos, this.debugFile)}${(0, constants_1.color)(0 /* EColor.Reset */)}`
            : `${(0, constants_1.color)(31 /* EColor.FgRed */)} Error ${(0, constants_1.color)(34 /* EColor.FgBlue */)} : ${(0, constants_1.color)(33 /* EColor.FgYellow */)} ${this.logAll(cle)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    // Usefull for id not used ;)
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    whereIam(infos) {
        const tmp = infos ? `${(0, constants_1.color)(39 /* EColor.FgFadeWhite */)} ${infos} ${(0, constants_1.color)(0 /* EColor.Reset */)}` : '';
        if (constants_1._DEBUG)
            return `${(0, constants_1.color)(31 /* EColor.FgRed */)} ${this.line(4)} ${(0, constants_1.color)(36 /* EColor.FgCyan */)} ${new Error().stack?.split("\n")[2].trim().split("(")[0].split("at ")[1].trim()} ${tmp}${(0, constants_1.color)(31 /* EColor.FgRed */)} ${this.line(4)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    test() {
        return `${(0, constants_1.color)(33 /* EColor.FgYellow */)} ${this.line(4)} ${(0, constants_1.color)(36 /* EColor.FgCyan */)} ${new Error().stack?.split("\n")[2].trim().split(" ")[1]} ${(0, constants_1.color)(33 /* EColor.FgYellow */)} ${this.line(4)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    writeErrorInFile(ctx, ...data) {
        const errFile = fs_1.default.createWriteStream(constants_1._ERRORFILE, { flags: "a" });
        if (ctx) {
            errFile.write(`# ${(0, constants_1.TIMESTAMP)()} : ${ctx.request.url}\n`);
            errFile.write(util_1.default.inspect(ctx.request.body, { showHidden: false, depth: null, colors: false, }) + "\n");
            errFile.write(`${this.line(30)}\n`);
        }
        else
            errFile.write(`# ${this.line(10)} ${(0, constants_1.TIMESTAMP)()} ${this.line(10)}\n`);
        errFile.write(util_1.default.format.apply(null, data) + "\n");
    }
}
exports.formatLog = new FormatLog();
