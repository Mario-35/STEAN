"use strict";
/**
 * Index Logs
 *
 * @copyright 2020-present Inrae
 * @review 29-01-2024
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Index Logs -----------------------------------!");
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatLog = exports.writeToLog = void 0;
const util_1 = __importDefault(require("util"));
const constants_1 = require("../constants");
var writeToLog_1 = require("./writeToLog");
Object.defineProperty(exports, "writeToLog", { enumerable: true, get: function () { return writeToLog_1.writeToLog; } });
class FormatLog {
    debugFile = false;
    line = (nb) => "=".repeat(nb);
    logAll = (input, colors) => typeof input === "object" ? util_1.default.inspect(input, { showHidden: false, depth: null, colors: colors || false, }) : input;
    separator = (title, nb) => `${(0, constants_1.color)(32 /* EColor.Green */)} ${this.line(nb)} ${(0, constants_1.color)(33 /* EColor.Yellow */)} ${title} ${(0, constants_1.color)(32 /* EColor.Green */)} ${this.line(nb)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    logCleInfos = (cle, infos) => `${(0, constants_1.color)(32 /* EColor.Green */)} ${cle} ${(0, constants_1.color)(37 /* EColor.White */)} : ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${this.logAll(infos, this.debugFile)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    constructor() {
        // override console log important in production build will remove all console.log
        console.log = (data) => {
            if (data && process.env.NODE_ENV?.trim() !== constants_1.TEST)
                this.write(data);
        };
    }
    write(data) {
        process.stdout.write(util_1.default.format.apply(null, [data]) + "\n");
    }
    // log an object or json
    object(title, input) {
        if (constants_1._DEBUG) {
            const res = [this.head(title)];
            Object.keys(input).forEach((cle) => {
                res.push(this.logCleInfos("  " + cle, input[cle]));
            });
            return res.join("\n");
        }
    }
    url(link) {
        return `${constants_1._WEB} ${(0, constants_1.color)(39 /* EColor.Default */)} : ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${link}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    head(cle, infos) {
        if (constants_1._DEBUG)
            return infos ? `${(0, constants_1.color)(32 /* EColor.Green */)} ${this.line(12)} ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${cle} ${(0, constants_1.color)(37 /* EColor.White */)} ${this.logAll(infos, this.debugFile)} ${(0, constants_1.color)(32 /* EColor.Green */)} ${this.line(12)}${(0, constants_1.color)(0 /* EColor.Reset */)}` : this.separator(cle, 12);
    }
    infos(cle, input) {
        if (constants_1._DEBUG)
            return `${this.separator(cle, 30)} ${(0, constants_1.color)(33 /* EColor.Yellow */)} ${this.logAll(input, true)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    debug(cle, infos) {
        if (constants_1._DEBUG)
            return `${(0, constants_1.color)(32 /* EColor.Green */)} ${cle} ${(0, constants_1.color)(37 /* EColor.White */)} : ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${this.logAll(infos, this.debugFile)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    result(cle, infos) {
        if (constants_1._DEBUG)
            return `${(0, constants_1.color)(32 /* EColor.Green */)}     >>${(0, constants_1.color)(30 /* EColor.Black */)} ${cle} ${(0, constants_1.color)(39 /* EColor.Default */)} : ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${this.logAll(infos, this.debugFile)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    error(cle, infos) {
        return infos
            ? `${(0, constants_1.color)(31 /* EColor.Red */)} ${cle} ${(0, constants_1.color)(34 /* EColor.Blue */)} : ${(0, constants_1.color)(33 /* EColor.Yellow */)} ${this.logAll(infos, this.debugFile)}${(0, constants_1.color)(0 /* EColor.Reset */)}`
            : `${(0, constants_1.color)(31 /* EColor.Red */)} Error ${(0, constants_1.color)(34 /* EColor.Blue */)} : ${(0, constants_1.color)(33 /* EColor.Yellow */)} ${this.logAll(cle)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    whereIam(infos) {
        const tmp = infos ? `${(0, constants_1.color)(39 /* EColor.Default */)} ${infos} ${(0, constants_1.color)(0 /* EColor.Reset */)}` : '';
        if (constants_1._DEBUG)
            return `${(0, constants_1.color)(31 /* EColor.Red */)} ${this.line(4)} ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${new Error().stack?.split("\n")[2].trim().split("(")[0].split("at ")[1].trim()} ${tmp}${(0, constants_1.color)(31 /* EColor.Red */)} ${this.line(4)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
    test() {
        return `${(0, constants_1.color)(33 /* EColor.Yellow */)} ${this.line(4)} ${(0, constants_1.color)(36 /* EColor.Cyan */)} ${new Error().stack?.split("\n")[2].trim().split(" ")[1]} ${(0, constants_1.color)(33 /* EColor.Yellow */)} ${this.line(4)}${(0, constants_1.color)(0 /* EColor.Reset */)}`;
    }
}
exports.formatLog = new FormatLog();
