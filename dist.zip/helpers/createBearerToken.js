"use strict";
/**
 * createBearerToken
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- createBearerToken -----------------------------------!");
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBearerToken = void 0;
const cookie_parser_1 = __importDefault(require("cookie-parser"));
const constants_1 = require("../constants");
const messages_1 = require("../messages");
const cookie_1 = __importDefault(require("cookie"));
const getCookie = (serializedCookies, key) => cookie_1.default.parse(serializedCookies)[key] ?? false;
const createBearerToken = (ctx) => {
    const queryKey = "access_token";
    const bodyKey = "access_token";
    const headerKey = "Bearer";
    const cookie = true;
    if (cookie && !constants_1.APP_KEY) {
        throw new Error(messages_1.errors.tokenMissing);
    }
    const { body, header, query } = ctx.request;
    let count = 0;
    let token = undefined;
    if (query && query[queryKey]) {
        token = query[queryKey];
        count += 1;
    }
    // @ts-ignore
    if (body && body[bodyKey]) {
        // @ts-ignore
        token = body[bodyKey];
        count += 1;
    }
    if (header) {
        if (header.authorization) {
            const parts = header.authorization.split(" ");
            if (parts.length === 2 && parts[0] === headerKey) {
                [, token] = parts;
                count += 1;
            }
        }
        // cookie
        if (cookie && header.cookie) {
            const plainCookie = getCookie(header.cookie, "jwt-session"); // seeks the key
            if (plainCookie) {
                const cookieToken = cookie_parser_1.default.signedCookie(plainCookie, constants_1.APP_KEY);
                if (cookieToken) {
                    token = cookieToken;
                    count += 1;
                }
            }
        }
    }
    // RFC6750 states the access_token MUST NOT be provided
    // in more than one place in a single request.
    if (count > 1) {
        ctx.throw(400, "token_invalid", {
            message: messages_1.errors.tokenInvalid,
        });
    }
    // @ts-ignore
    if (token)
        ctx.request["token"] = token;
};
exports.createBearerToken = createBearerToken;
