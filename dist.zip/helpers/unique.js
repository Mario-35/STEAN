"use strict";
/**
 * unique
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- unique -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.unique = void 0;
function unique(input) {
    return input.filter((e) => e.trim() != "").reduce((unique, item) => unique.includes(item) ? unique : [...unique, item], []);
}
exports.unique = unique;
