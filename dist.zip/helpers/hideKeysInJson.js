"use strict";
/**
 * hideKeysInJson
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- hideKeysInJson -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.hideKeysInJson = void 0;
/**
 *
 * @param object string
 * @param key or array of keys to hide
 * @returns object without keys
 */
const hideKeysInJson = (obj, keys = "") => {
    if (typeof keys === "string")
        keys = [keys];
    for (const [k, v] of Object.entries(obj)) {
        keys.forEach((key) => {
            if (k.includes(key))
                delete obj[k];
            else if (k.includes("password"))
                obj[k] = "*****";
            else if (typeof v === "object")
                (0, exports.hideKeysInJson)(v, keys);
        });
    }
    return obj;
};
exports.hideKeysInJson = hideKeysInJson;
