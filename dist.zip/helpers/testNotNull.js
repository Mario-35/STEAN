"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isNull = void 0;
/**
 * testNotNull.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- testNotNull. -----------------------------------!");
/**
 *
 * @param input thing to test
 * @returns bollean test
 */
const isNull = (input) => {
    switch (typeof input) {
        case "string":
            if (input && input != "" && input != null)
                return true;
        case "object":
            if (input && Object.keys(input).length > 0)
                return true;
        default:
            return false;
    }
};
exports.isNull = isNull;
// onsole.log("!----------------------------------- testNotNull. -----------------------------------!");
