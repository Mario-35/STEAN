"use strict";
/**
 * Main Helpers.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Main Helpers -----------------------------------!");
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getKey = exports.upload = exports.removeEmpty = exports.unique = exports.returnFormats = exports.bigIntReplacer = exports.notNull = exports.hidePassword = exports.hideKeysInJson = exports.getUrlKey = exports.getBigIntFromString = exports.decrypt = exports.encrypt = exports.deepClone = exports.createBearerToken = exports.containsAll = exports.cleanUrl = exports.cleanStringComma = exports.asyncForEach = exports.unikeList = exports.removeAllQuotes = exports.getUserId = exports.addSimpleQuotes = exports.removeSimpleQuotes = exports.removeDoubleQuotes = exports.addDoubleQuotes = void 0;
const removeFirstOrEnd = (input, char) => {
    while (input[0] === char[0])
        input = input.slice(1).trim();
    while (input[input.length - 1] === char[0])
        input = input.slice(0, -1);
    return input;
};
const removeFirstAndEnd = (input, char) => input[0] === char && input[input.length - 1] === char[0] ? input.slice(0, -1).slice(1).trim() : input;
const addQuotes = (input, Quotes) => { input = removeFirstOrEnd(input, Quotes); return `${input[0] !== Quotes ? Quotes : ''}${input}${input[input.length - 1] !== Quotes ? Quotes : ''}`; };
const addDoubleQuotes = (input) => input ? addQuotes(input, '"') : "";
exports.addDoubleQuotes = addDoubleQuotes;
const removeDoubleQuotes = (input) => removeFirstAndEnd(input, '"');
exports.removeDoubleQuotes = removeDoubleQuotes;
const removeSimpleQuotes = (input) => removeFirstAndEnd(input, "'");
exports.removeSimpleQuotes = removeSimpleQuotes;
const addSimpleQuotes = (input) => addQuotes(input, "'");
exports.addSimpleQuotes = addSimpleQuotes;
const getUserId = (ctx) => ctx.state.user && ctx.state.user.id ? ctx.state.user.id : -1;
exports.getUserId = getUserId;
const removeAllQuotes = (input) => input.replace(/['"]+/g, "");
exports.removeAllQuotes = removeAllQuotes;
const unikeList = (input) => [...new Set(input)];
exports.unikeList = unikeList;
var asyncForEach_1 = require("./asyncForEach");
Object.defineProperty(exports, "asyncForEach", { enumerable: true, get: function () { return asyncForEach_1.asyncForEach; } });
var cleanStringComma_1 = require("./cleanStringComma");
Object.defineProperty(exports, "cleanStringComma", { enumerable: true, get: function () { return cleanStringComma_1.cleanStringComma; } });
var cleanUrl_1 = require("./cleanUrl");
Object.defineProperty(exports, "cleanUrl", { enumerable: true, get: function () { return cleanUrl_1.cleanUrl; } });
var containsAll_1 = require("./containsAll");
Object.defineProperty(exports, "containsAll", { enumerable: true, get: function () { return containsAll_1.containsAll; } });
var createBearerToken_1 = require("./createBearerToken");
Object.defineProperty(exports, "createBearerToken", { enumerable: true, get: function () { return createBearerToken_1.createBearerToken; } });
var deepClone_1 = require("./deepClone");
Object.defineProperty(exports, "deepClone", { enumerable: true, get: function () { return deepClone_1.deepClone; } });
var crypto_1 = require("./crypto");
Object.defineProperty(exports, "encrypt", { enumerable: true, get: function () { return crypto_1.encrypt; } });
Object.defineProperty(exports, "decrypt", { enumerable: true, get: function () { return crypto_1.decrypt; } });
var getBigIntFromString_1 = require("./getBigIntFromString");
Object.defineProperty(exports, "getBigIntFromString", { enumerable: true, get: function () { return getBigIntFromString_1.getBigIntFromString; } });
var getUrlKey_1 = require("./getUrlKey");
Object.defineProperty(exports, "getUrlKey", { enumerable: true, get: function () { return getUrlKey_1.getUrlKey; } });
var hideKeysInJson_1 = require("./hideKeysInJson");
Object.defineProperty(exports, "hideKeysInJson", { enumerable: true, get: function () { return hideKeysInJson_1.hideKeysInJson; } });
var hidePassword_1 = require("./hidePassword");
Object.defineProperty(exports, "hidePassword", { enumerable: true, get: function () { return hidePassword_1.hidePassword; } });
__exportStar(require("./tests"), exports);
var notNull_1 = require("./notNull");
Object.defineProperty(exports, "notNull", { enumerable: true, get: function () { return notNull_1.notNull; } });
var bigIntReplacer_1 = require("./bigIntReplacer");
Object.defineProperty(exports, "bigIntReplacer", { enumerable: true, get: function () { return bigIntReplacer_1.bigIntReplacer; } });
var returnFormats_1 = require("./returnFormats");
Object.defineProperty(exports, "returnFormats", { enumerable: true, get: function () { return returnFormats_1.returnFormats; } });
var unique_1 = require("./unique");
Object.defineProperty(exports, "unique", { enumerable: true, get: function () { return unique_1.unique; } });
var removeEmpty_1 = require("./removeEmpty");
Object.defineProperty(exports, "removeEmpty", { enumerable: true, get: function () { return removeEmpty_1.removeEmpty; } });
var upload_1 = require("./upload");
Object.defineProperty(exports, "upload", { enumerable: true, get: function () { return upload_1.upload; } });
var getKey_1 = require("./getKey");
Object.defineProperty(exports, "getKey", { enumerable: true, get: function () { return getKey_1.getKey; } });
