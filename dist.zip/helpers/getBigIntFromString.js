"use strict";
/**
 * getBigIntFromString
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- getBigIntFromString -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.getBigIntFromString = void 0;
const log_1 = require("../log");
/**
 *
 * @param input string or number search
 * @returns the bigint extract number
 */
const getBigIntFromString = (input) => {
    if (input) {
        try {
            if (typeof input === "string") {
                const testString = input.match(/\([^\d]*(\d+)[^\d]*\)/);
                return testString
                    ? BigInt(testString[1])
                    : BigInt(input.match(/[0-9]/g)?.join(""));
            }
            return BigInt(input);
        }
        catch (error) {
            log_1.log.errorMsg(error);
        }
    }
};
exports.getBigIntFromString = getBigIntFromString;
