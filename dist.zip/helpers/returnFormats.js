"use strict";
/**
 * returnFormats
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- returnFormats -----------------------------------!");
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.returnFormats = void 0;
const queries_1 = require("../db/queries");
const json2csv_1 = require("json2csv");
const css_1 = require("../views/css");
const js_1 = require("../views/js");
const util_1 = __importDefault(require("util"));
const enums_1 = require("../enums");
const _1 = require(".");
const constants_1 = require("../constants");
const log_1 = require("../log");
// Default "blank" function
const defaultFunction = (input) => input;
// Default "blank" format function
const defaultForwat = (input) => input.toString();
const generateFields = (input) => {
    let fields = [];
    if ((0, _1.isGraph)(input)) {
        const table = input.ctx.model[input.parentEntity ? input.parentEntity : input.entity].table;
        fields = [
            `(SELECT ${table}."description" FROM ${table} WHERE ${table}."id" = ${input.parentId ? input.parentId : input.id}) AS title, `,
        ];
    }
    return fields;
};
/**
 *
 * @param input PgVisitor
 * @returns sSQL Query for graph
 */
const generateGrahSql = (input) => {
    input.intervalColumns = ["id", "step as date", "result"];
    if ((0, _1.isGraph)(input))
        input.intervalColumns.push("concat");
    const table = input.ctx.model[input.parentEntity ? input.parentEntity : input.entity].table;
    const id = input.parentId ? input.parentId : input.id;
    return (0, queries_1.asJson)({
        query: table === input.ctx.model.Datastreams.table
            ? (0, queries_1.graphDatastream)(table, id, (0, queries_1.interval)(input))
            : (0, queries_1.graphMultiDatastream)(table, id, input.splitResult, (0, queries_1.interval)(input)),
        singular: false,
        strip: false,
        count: false,
    });
};
// all returns format functions
const _returnFormats = {
    xlsx: {
        name: "xlsx",
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        format: defaultFunction,
        generateSql: defaultForwat,
    },
    // IMPORTANT TO HAVE THIS BEFORE GRAPHDATAS
    json: {
        name: "json",
        type: "application/json",
        format: defaultFunction,
        generateSql(input) {
            return input.interval
                ? (0, queries_1.asJson)({ query: (0, queries_1.interval)(input), singular: false, strip: false, count: true })
                : (0, queries_1.asJson)({
                    query: input.toString(),
                    singular: false,
                    count: true,
                    strip: input.ctx.config.options.includes(enums_1.EnumOptions.stripNull),
                    fullCount: input.count === true ? input.toPgQuery()?.count : undefined,
                    fields: generateFields(input),
                });
        },
    },
    // IMPORTANT TO HAVE THIS BEFORE GRAPH
    graphDatas: {
        name: "graphDatas",
        type: "application/json",
        format: defaultFunction,
        generateSql(input) { return generateGrahSql(input); },
    },
    graph: {
        name: "graph",
        type: "text/html;charset=utf8",
        format(input, ctx) {
            const graphNames = [];
            const formatedDatas = [];
            const height = String(100 / Object.entries(input).length).split(".")[0];
            if (typeof input === "object") {
                Object.entries(input).forEach((element, index) => {
                    graphNames.push(`<button type="button" id="btngraph${index}" onclick="graph${index}.remove(); btngraph${index}.remove();">X</button>
           <div id="graph${index}" style="width:95%; height:${height}%;"></div>`);
                    const infos = element[1]["description"]
                        ? `${[element[1]["description"], element[1]["name"], element[1]["symbol"],].join('","')}`
                        : `${element[1]["infos"].split("|").join(constants_1.DOUBLEQUOTEDCOMA)}`;
                    const formatedData = `const value${index} = [${element[1]["datas"]}]; 
          const infos${index} = ["${infos}"];`;
                    formatedDatas.push(` ${formatedData} showGraph("graph${index}", infos${index}, value${index})`);
                });
            }
            return `<html lang="fr"> <head>
      <style>${(0, css_1.addCssFile)("dygraph.css")}</style> <!-- htmlmin:ignore --><script>${(0, js_1.addJsFile)("dygraph.js")}</script><!-- htmlmin:ignore -->
      ${graphNames.join("")}
        <script>
        ${(0, js_1.addJsFile)("graph.js")}
          const linkBase = "${ctx.decodedUrl.root}";
          ${formatedDatas.join(";")}                             
        </script>`;
        },
        generateSql(input) {
            return generateGrahSql(input);
        },
    },
    dataArray: {
        name: "dataArray",
        type: "application/json",
        format: defaultFunction,
        generateSql(input) {
            return (0, queries_1.asDataArray)(input);
        },
    },
    csv: {
        name: "csv",
        type: "text/csv",
        format: (input) => {
            const opts = {
                delimiter: ";",
                includeEmptyRows: true,
                escapedQuote: "",
                header: false,
            };
            if (input && typeof input === "object" && input[0].dataArray)
                try {
                    const parser = new json2csv_1.Parser(opts);
                    input[0].dataArray.unshift(input[0].component);
                    return parser.parse(input[0].dataArray);
                }
                catch (e) {
                    if (e instanceof Error) {
                        log_1.log.errorMsg(e);
                        return e.message;
                    }
                }
            return "No datas";
        },
        generateSql(input) {
            return (0, queries_1.asDataArray)(input);
        },
    },
    txt: {
        name: "txt",
        type: "text/plain",
        format: (input) => Object.entries(input).length > 0
            ? util_1.default.inspect(input, { showHidden: true, depth: 4 })
            : JSON.stringify(input),
        generateSql(input) {
            return (0, queries_1.asJson)({ query: input.toString(), singular: false, strip: false, count: false });
        },
    },
    sql: {
        name: "sql",
        type: "text/plain",
        format: defaultFunction,
        generateSql: defaultForwat,
    },
    html: {
        name: "html",
        type: "text/html;charset=utf8",
        format: defaultFunction,
        generateSql: defaultForwat,
    },
    css: {
        name: "css",
        type: "text/css;charset=utf8",
        format: defaultFunction,
        generateSql: defaultForwat,
    },
    js: {
        name: "js",
        type: "application/javascript;charset=utf8",
        format: defaultFunction,
        generateSql: defaultForwat,
    },
    png: {
        name: "png",
        type: "image/png",
        format: defaultFunction,
        generateSql: defaultForwat,
    },
    jpeg: {
        name: "jpeg",
        type: "image/jpeg",
        format: defaultFunction,
        generateSql: defaultForwat,
    },
    jpg: {
        name: "jpg",
        type: "image/jpeg",
        format: defaultFunction,
        generateSql: defaultForwat,
    },
    icon: {
        name: "icon",
        type: "image/x-icon",
        format: defaultFunction,
        generateSql: defaultForwat,
    },
    ico: {
        name: "ico",
        type: "image/x-icon",
        format: defaultFunction,
        generateSql: defaultForwat,
    },
    xml: {
        name: "xml",
        type: "application/xml",
        format: defaultFunction,
        generateSql: defaultForwat,
    },
};
exports.returnFormats = Object.freeze(_returnFormats);
