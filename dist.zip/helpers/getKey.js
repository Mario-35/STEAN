"use strict";
/**
 * getKey
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- getKey -----------------------------------!");
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getKey = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const enums_1 = require("../enums");
const getKey = () => {
    const _APP_KEY = "zLwX893Mtt9Rc0TKvlInDXuZTFj9rxDV";
    try {
        return fs_1.default.readFileSync(path_1.default.resolve(__dirname, "../configuration/", enums_1.EFileName.key), "utf8");
    }
    catch (error) {
        fs_1.default.writeFileSync(path_1.default.resolve(__dirname, "../configuration/", enums_1.EFileName.key), _APP_KEY, { encoding: "utf-8" });
        return _APP_KEY;
    }
};
exports.getKey = getKey;
