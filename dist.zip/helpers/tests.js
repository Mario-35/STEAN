"use strict";
/**
 * tests Is
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- tests Is -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.isArray = exports.isObject = exports.isIntegerNumber = exports.isNumber = exports.isBoolean = exports.isString = exports.isAllowedTo = exports.isAdmin = exports.isObservation = exports.isGraph = exports.isCsvOrArray = exports.isProduction = exports.isTest = void 0;
const constants_1 = require("../constants");
const enums_1 = require("../enums");
const returnFormats_1 = require("./returnFormats");
const isTest = () => process.env.NODE_ENV?.trim() === "test" || false;
exports.isTest = isTest;
const isProduction = () => process.env.NODE_ENV?.trim() === "production" || false;
exports.isProduction = isProduction;
const isCsvOrArray = (input) => [returnFormats_1.returnFormats.dataArray, returnFormats_1.returnFormats.csv].includes(input.returnFormat) ? true : undefined;
exports.isCsvOrArray = isCsvOrArray;
const isGraph = (input) => [returnFormats_1.returnFormats.graph, returnFormats_1.returnFormats.graphDatas].includes(input.returnFormat) ? true : undefined;
exports.isGraph = isGraph;
const isObservation = (input) => typeof input === "string" ? input === "Observations" : input.name === "Observations";
exports.isObservation = isObservation;
const isAdmin = (ctx) => ctx.config && ctx.config.name === constants_1.ADMIN;
exports.isAdmin = isAdmin;
const isAllowedTo = (ctx, what) => ctx.config.extensions.includes(enums_1.EnumExtensions.users) ? true : ctx.user && ctx.user.PDCUAS[what];
exports.isAllowedTo = isAllowedTo;
function isString(obj) {
    return (typeof obj) === 'string';
}
exports.isString = isString;
function isBoolean(obj) {
    return (typeof obj) === 'boolean';
}
exports.isBoolean = isBoolean;
function isNumber(obj) {
    return (typeof obj) === 'number';
}
exports.isNumber = isNumber;
function isIntegerNumber(obj) {
    return (typeof obj) === 'number' && Number.isInteger(obj);
}
exports.isIntegerNumber = isIntegerNumber;
function isObject(obj) {
    return obj != null && (typeof obj) === 'object' && !(obj instanceof Array);
}
exports.isObject = isObject;
function isArray(obj) {
    return (obj instanceof Array);
}
exports.isArray = isArray;
