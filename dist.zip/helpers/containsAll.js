"use strict";
/**
* containsAll
*
* @copyright 2020-present Inrae
* @author mario.adam@inrae.fr
*
*/
// onsole.log("!----------------------------------- containsAll -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.containsAll = void 0;
const containsAll = (arr1, arr2) => arr1 && arr2 ? arr1.every(i => arr2.includes(i)) : false;
exports.containsAll = containsAll;
