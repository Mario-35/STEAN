"use strict";
/**
 * isNullOrNotNull
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- isNullOrNotNull -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.notNull = void 0;
const isNullOrNotNull = (input, ret) => {
    switch (typeof input) {
        case "string":
            if (input && input != "" && input != null)
                return ret;
        case "object":
            if (input && Object.keys(input).length > 0)
                return ret;
        default:
            return !ret;
    }
};
const notNull = (input) => isNullOrNotNull(input, true);
exports.notNull = notNull;
