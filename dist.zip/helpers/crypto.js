"use strict";
/**
 * crypto
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- crypto -----------------------------------!");
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.decrypt = exports.encrypt = void 0;
const crypto_1 = __importDefault(require("crypto"));
const constants_1 = require("../constants");
const log_1 = require("../log");
/**
 *
 * @param input string
 * @returns encrypted string
 */
const encrypt = (input) => {
    const iv = crypto_1.default.randomBytes(16);
    const cipher = crypto_1.default.createCipheriv("aes-256-ctr", constants_1.APP_KEY, iv);
    const encrypted = Buffer.concat([cipher.update(input), cipher.final()]);
    return `${iv.toString("hex")}.${encrypted.toString("hex")}`;
};
exports.encrypt = encrypt;
/**
 *
 * @param input string
 * @returns decrypted string
 */
const decrypt = (input) => {
    input = input.split("\r\n").join("");
    if (typeof input === "string" && input[32] == ".") {
        try {
            const decipher = crypto_1.default.createDecipheriv("aes-256-ctr", constants_1.APP_KEY, Buffer.from(input.substring(32, 0), "hex"));
            const decrpyted = Buffer.concat([decipher.update(Buffer.from(input.slice(33), "hex")), decipher.final(),]);
            return decrpyted.toString();
        }
        catch (error) {
            log_1.log.errorMsg(error);
        }
    }
    return input;
};
exports.decrypt = decrypt;
