"use strict";
/**
 * asyncForEach.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 * https://gist.github.com/Atinux/fd2bcce63e44a7d3addddc166ce93fb2
 *
 */
// onsole.log("!----------------------------------- asyncForEach -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.asyncForEach = void 0;
/**
 *
 * @param array for loop
 * @param callback fn to execute in loop
 */
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function asyncForEach(array, callback) {
    for (let index = 0; index < array.length; index++) {
        // ATTENTION AWAIT Before callback is important (it send error BUT IS NOT)
        await callback(array[index], index, array);
    }
}
exports.asyncForEach = asyncForEach;
