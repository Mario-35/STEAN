"use strict";
/**
 * Index messages
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Index messages -----------------------------------!");
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getErrorCode = exports.infos = exports.errors = exports.msg = void 0;
const error_json_1 = __importDefault(require("./error.json"));
const infos_json_1 = __importDefault(require("./infos.json"));
const msg = (...args) => { for (let i = 1; i < args.length; i++)
    args[0] = args[0].replace(`$${i}`, args[i]); return args[0]; };
exports.msg = msg;
exports.errors = error_json_1.default;
exports.infos = infos_json_1.default;
const getErrorCode = (err, actual) => {
    if (err["where"] && err["where"].includes("verifyid"))
        return 404;
    return actual;
};
exports.getErrorCode = getErrorCode;
