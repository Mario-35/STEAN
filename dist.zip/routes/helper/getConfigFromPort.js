"use strict";
/**
 * getConfigFromPort for user admin
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- getConfigFromPort for user admin -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.getConfigFromPort = void 0;
const configuration_1 = require("../../configuration");
const constants_1 = require("../../constants");
const helpers_1 = require("../../helpers");
/**
 *
 * @param port of the request
 * @returns name of the configuration
 */
const getConfigFromPort = (port) => {
    if (port) {
        const databaseName = (0, helpers_1.isTest)()
            ? [constants_1.TEST]
            : configuration_1.serverConfig.getConfigs().filter((word) => (word != constants_1.TEST && configuration_1.serverConfig.getConfig(word).port) == port);
        if (databaseName && databaseName.length === 1)
            return databaseName[0];
    }
};
exports.getConfigFromPort = getConfigFromPort;
