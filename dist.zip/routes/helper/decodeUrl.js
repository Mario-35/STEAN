"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.decodeUrl = void 0;
/**
 * Helpers for user admin.
 *
 * @copyright 2020-present Inrae
 * @review 31-01-2024
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Helpers for user admin. -----------------------------------!");
const _1 = require(".");
const configuration_1 = require("../../configuration");
const constants_1 = require("../../constants");
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const logger_1 = require("../../logger");
const messages_1 = require("../../messages");
//   service root URI       resource path       query options
// __________|_________________ __|________________ ___|______________
//                             \                   \                  \
// http://example.org:8029/v1.1/Things(1)/Locations?$orderby=ID&$top=10
// _____/________________/____/___________________/___________________/
//   |           |         |              |                |
// protocol     host    version        pathname          search
const decodeUrl = (ctx, input) => {
    console.log(logger_1.formatLog.whereIam());
    // get input
    input = input || ctx.href;
    input = input;
    // debug mode
    (0, constants_1.setDebug)(input.includes("?$debug=true") || input.includes("&$debug=true"));
    // decode url
    const url = new URL((0, helpers_1.cleanUrl)(input.replace("$debug=true", "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")));
    // get configName from port    
    let configName = (0, _1.getConfigFromPort)(+url.port);
    // split path
    // path[0] : service
    // path[1] : version
    // path[...] : path
    const paths = url.pathname.split('/').filter(e => e != "");
    // no service
    if (paths[0])
        configName = configName || configuration_1.serverConfig.getConfigNameFromName(paths[0].toLowerCase());
    else
        throw new Error(messages_1.errors.noNameIdentified);
    // get getLinkBase from service
    if (configName) {
        const LinkBase = configuration_1.serverConfig.getInfos(ctx, configName);
        let idStr = undefined;
        let id = 0;
        // if nothing ===> root
        let path = "/";
        // id string or number
        if (paths[2]) {
            id = (paths[2].includes("(")) ? paths[2].split("(")[1].split(")")[0] : 0;
            idStr = (isNaN(+id)) ? String(id).toLocaleUpperCase() : undefined;
            path = paths.slice(2).join("/");
        }
        // result
        return {
            search: url.search,
            service: paths[0],
            version: paths[0] === constants_1.ADMIN ? enums_1.EnumVersion.v1_0 : paths[1],
            path: idStr ? path.replace(String(id), '0') : path,
            id: (isNaN(+id)) ? BigInt(0) : BigInt(id),
            idStr: idStr,
            configName: configName,
            linkbase: LinkBase.linkBase,
            root: LinkBase.root,
        };
    }
};
exports.decodeUrl = decodeUrl;
