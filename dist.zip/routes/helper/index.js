"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.firstInstall = exports.getConfigFromPort = exports.decodeUrl = exports.sqlStopDbName = exports.checkPassword = exports.emailIsValid = void 0;
/**
 * Routes Helpers.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Routes Helpers. -----------------------------------!");
const emailIsValid = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
exports.emailIsValid = emailIsValid;
// at least one number, one lowercase and one uppercase letter
// at least six characters that are letters, numbers or the underscore
const checkPassword = (str) => /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])\w{6,}$/.test(str);
exports.checkPassword = checkPassword;
const sqlStopDbName = (dbName) => `SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE pid <> pg_backend_pid() AND datname = ${dbName};`;
exports.sqlStopDbName = sqlStopDbName;
var decodeUrl_1 = require("./decodeUrl");
Object.defineProperty(exports, "decodeUrl", { enumerable: true, get: function () { return decodeUrl_1.decodeUrl; } });
var getConfigFromPort_1 = require("./getConfigFromPort");
Object.defineProperty(exports, "getConfigFromPort", { enumerable: true, get: function () { return getConfigFromPort_1.getConfigFromPort; } });
var firstInstall_1 = require("./firstInstall");
Object.defineProperty(exports, "firstInstall", { enumerable: true, get: function () { return firstInstall_1.firstInstall; } });
