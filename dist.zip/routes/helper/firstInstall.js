"use strict";
/**
 * firstInstall
 *
 * @copyright 2020-present Inrae
 * @review 31-01-2024
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- firstInstall -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.firstInstall = void 0;
const configuration_1 = require("../../configuration");
const helpers_1 = require("../../helpers");
const views_1 = require("../../views");
async function firstInstall(ctx) {
    // If Configuration file Not exist first Install
    if (configuration_1.serverConfig.configFileExist() === false) {
        // trap create post
        if (ctx.request.url.toUpperCase() === "/CREATE") {
            const src = JSON.parse(JSON.stringify(ctx.request.body, null, 2));
            const ext = ["base"];
            const opt = [""];
            const extStr = "serviceextensions";
            const optStr = "serviceoptions";
            Object.keys(src).forEach((e) => {
                if (e.startsWith(extStr) && src[e] === "on") {
                    ext.push(e.replace(extStr, ""));
                    delete src[e];
                }
                if (e.startsWith(optStr) && src[e] === "on") {
                    opt.push(e.replace(optStr, ""));
                    delete src[e];
                }
            });
            src["extensions"] = src["extensions"] ? (0, helpers_1.unique)([...src["extensions"], ...ext]) : (0, helpers_1.unique)(ext);
            src["options"] = src["options"] ? (0, helpers_1.unique)([...src["options"], ...opt]) : (0, helpers_1.unique)(opt);
            src["serviceversion"] = src["serviceversion"].startsWith("v") ? src["serviceversion"].replace("v", "") : src["serviceversion"];
            const confJson = {
                "admin": {
                    "name": "admin",
                    "port": 8029,
                    "pg": {
                        "host": src["host"],
                        "port": 5432,
                        "user": src["username"],
                        "password": src["password"],
                        "database": "postgres",
                        "retry": 2
                    },
                    "apiVersion": src["serviceversion"],
                    "date_format": "DD/MM/YYYY hh:mi:ss",
                    "webSite": "no web site",
                    "nb_page": 200,
                    "alias": [""],
                    "extensions": src["extensions"],
                    "options": src["options"]
                }
            };
            confJson[src["servicename"]] = {
                "name": src["servicename"],
                "port": 8029,
                "pg": {
                    "host": src["servicehost"],
                    "port": 5432,
                    "user": src["serviceusername"],
                    "password": src["servicepassword"],
                    "database": src["servicedatabase"] || src["servicename"],
                    "retry": 2
                },
                "apiVersion": src["serviceversion"],
                "date_format": "DD/MM/YYYY hh:mi:ss",
                "webSite": "",
                "nb_page": 200,
                "options": src["options"],
                "extensions": ["base"]
            };
            await configuration_1.serverConfig.init(JSON.stringify(confJson, null, 2));
        }
        // show first install screen
        else {
            const bodyFirst = new views_1.First(ctx, { login: false, url: ctx.request.url });
            ctx.type = helpers_1.returnFormats.html.type;
            ctx.body = bodyFirst.toString();
        }
        return;
    }
}
exports.firstInstall = firstInstall;
