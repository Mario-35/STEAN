"use strict";
/**
 * Protected Routes for API
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Protected Routes for API -----------------------------------!");
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.protectedRoutes = void 0;
const koa_router_1 = __importDefault(require("koa-router"));
const dataAccess_1 = require("../db/dataAccess");
const helpers_1 = require("../helpers");
const fs_1 = __importDefault(require("fs"));
const views_1 = require("../views/");
const odata_1 = require("../odata");
const messages_1 = require("../messages");
const enums_1 = require("../enums");
const authentication_1 = require("../authentication");
const constants_1 = require("../constants");
const helpers_2 = require("../db/helpers");
const configuration_1 = require("../configuration");
const helper_1 = require("./helper");
const views_2 = require("../views");
const helpers_3 = require("../views/helpers");
const log_1 = require("../log");
exports.protectedRoutes = new koa_router_1.default();
exports.protectedRoutes.post("/(.*)", async (ctx, next) => {
    switch (ctx.decodedUrl.path.toUpperCase()) {
        // login html page or connection login
        case "LOGIN":
            if (ctx.request["token"])
                ctx.redirect(`${ctx.decodedUrl.root}/status`);
            await (0, authentication_1.loginUser)(ctx).then((user) => {
                if (user) {
                    ctx.status = 200;
                    if (ctx.request.header.accept && ctx.request.header.accept.includes("text/html"))
                        ctx.redirect(`${ctx.decodedUrl.root}/Status`);
                    else
                        ctx.body = {
                            message: messages_1.infos.loginOk,
                            user: user.username,
                            token: user.token,
                        };
                }
                else {
                    ctx.throw(401);
                }
            });
            return;
        case "REGISTER":
            const why = {};
            // Username
            if (ctx.body["username"].trim() === "") {
                why["username"] = (0, messages_1.msg)(messages_1.errors.empty, "username");
            }
            else {
                const user = await (0, helpers_2.executeSqlValues)(configuration_1.serverConfig.getConfig(constants_1.ADMIN), `SELECT "username" FROM "user" WHERE username = '${ctx.body["username"]}' LIMIT 1`);
                if (user)
                    why["username"] = messages_1.errors.alreadyPresent;
            }
            // Email
            if (ctx.body["email"].trim() === "") {
                why["email"] = (0, messages_1.msg)(messages_1.errors.empty, "email");
            }
            else {
                if ((0, helper_1.emailIsValid)(ctx.body["email"]) === false)
                    why["email"] = (0, messages_1.msg)(messages_1.errors.invalid, "email");
            }
            // Password
            if (ctx.body["password"].trim() === "") {
                why["password"] = (0, messages_1.msg)(messages_1.errors.empty, "password");
            }
            // Repeat password
            if (ctx.body["repeat"].trim() === "") {
                why["repeat"] = (0, messages_1.msg)(messages_1.errors.empty, "repeat password");
            }
            else {
                if (ctx.body["password"] != ctx.body.repeat) {
                    why["repeat"] = messages_1.errors.passowrdDifferent;
                }
                else {
                    if ((0, helper_1.checkPassword)(ctx.body["password"]) === false)
                        why["password"] = (0, messages_1.msg)(messages_1.errors.invalid, "password");
                }
            }
            if (Object.keys(why).length === 0) {
                try {
                    await dataAccess_1.userAccess.post(ctx.config.name, ctx.body);
                }
                catch (error) {
                    ctx.redirect(`${ctx.decodedUrl.root}/error`);
                }
            }
            else {
                const createHtml = new views_2.Login(ctx, {
                    login: false,
                    body: ctx.request.body,
                    why: why,
                });
                ctx.type = helpers_1.returnFormats.html.type;
                ctx.body = createHtml.toString();
            }
            return;
    }
    if (!ctx.decodedUrl.version && ctx.decodedUrl.path === "/" && ctx.decodedUrl.service.toUpperCase() === "CREATE") {
        // intercept create
        return;
    }
    // Add new lora observation this is a special route without ahtorisatiaon to post (deveui and correct payload limit risks)
    if ((ctx.user && ctx.user.id > 0) || !ctx.config.extensions.includes(enums_1.EExtensions.users) || ctx.request.url.includes("/Lora")) {
        if (ctx.request.type.startsWith("application/json") && Object.keys(ctx.body).length > 0) {
            const odataVisitor = await (0, odata_1.createOdata)(ctx);
            if (odataVisitor)
                ctx.odata = odataVisitor;
            if (ctx.odata) {
                const objectAccess = new dataAccess_1.apiAccess(ctx);
                const returnValue = await objectAccess.post();
                if (returnValue) {
                    helpers_1.returnFormats.json.type;
                    ctx.status = 201;
                    ctx.body = returnValue.body;
                }
            }
            else
                ctx.throw(400);
        }
        else if (ctx.request.type.startsWith("multipart/")) {
            // If upload datas
            const getDatas = async () => {
                console.log(log_1.log.head("getDatas ..."));
                return new Promise(async (resolve, reject) => {
                    await (0, helpers_1.upload)(ctx)
                        .then((data) => {
                        resolve(data);
                    })
                        .catch((data) => {
                        reject(data["state"] = "ERROR");
                    });
                });
            };
            ctx.datas = await getDatas();
            const odataVisitor = await (0, odata_1.createOdata)(ctx);
            if (odataVisitor)
                ctx.odata = odataVisitor;
            if (ctx.odata) {
                console.log(log_1.log.head("POST FORM"));
                const objectAccess = new dataAccess_1.apiAccess(ctx);
                const returnValue = await objectAccess.post();
                if (ctx.datas)
                    fs_1.default.unlinkSync(ctx.datas["file"]);
                if (returnValue) {
                    if (ctx.datas["source"] == "query") {
                        const temp = await (0, helpers_3.createQueryParams)(ctx);
                        if (temp) {
                            ctx.type = "html";
                            ctx.body = (0, views_1.createQueryHtml)({
                                ...temp,
                                results: JSON.stringify({
                                    added: returnValue.total,
                                    value: returnValue.body,
                                }),
                            });
                        }
                    }
                    else {
                        helpers_1.returnFormats.json.type;
                        ctx.status = 201;
                        ctx.body = returnValue.body;
                    }
                }
                else {
                    ctx.throw(400);
                }
            }
        }
        else {
            // payload is malformed
            ctx.throw(400, { details: messages_1.errors.payloadIsMalformed });
        }
    }
    else
        ctx.throw(401);
});
exports.protectedRoutes.patch("/(.*)", async (ctx) => {
    if ((0, helpers_1.isAllowedTo)(ctx, enums_1.EUserRights.Post) === true &&
        Object.keys(ctx.body).length > 0) {
        const odataVisitor = await (0, odata_1.createOdata)(ctx);
        if (odataVisitor)
            ctx.odata = odataVisitor;
        if (ctx.odata) {
            console.log(log_1.log.head("PATCH"));
            const objectAccess = new dataAccess_1.apiAccess(ctx);
            if (ctx.odata.id) {
                const returnValue = await objectAccess.update(ctx.odata.id);
                if (returnValue) {
                    helpers_1.returnFormats.json.type;
                    ctx.status = 200;
                    ctx.body = returnValue.body;
                }
            }
            else {
                ctx.throw(400, { detail: messages_1.errors.idRequired });
            }
        }
        else {
            ctx.throw(404);
        }
    }
    else {
        ctx.throw(401);
    }
});
exports.protectedRoutes.delete("/(.*)", async (ctx) => {
    if ((0, helpers_1.isAllowedTo)(ctx, enums_1.EUserRights.Delete) === true) {
        const odataVisitor = await (0, odata_1.createOdata)(ctx);
        if (odataVisitor)
            ctx.odata = odataVisitor;
        if (ctx.odata) {
            console.log(log_1.log.head("DELETE"));
            const objectAccess = new dataAccess_1.apiAccess(ctx);
            if (!ctx.odata.id)
                ctx.throw(400, { detail: messages_1.errors.idRequired });
            const returnValue = await objectAccess.delete(ctx.odata.id);
            if (returnValue && returnValue.id && returnValue.id > 0) {
                helpers_1.returnFormats.json.type;
                ctx.status = 204;
            }
            else
                ctx.throw(404, { code: 404, detail: messages_1.errors.noId + ctx.odata.id });
        }
        else {
            ctx.throw(404);
        }
    }
    else {
        ctx.throw(401);
    }
});
