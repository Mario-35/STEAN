/**
 * Constants of API
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Constants of API -----------------------------------!");
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.APP_KEY = exports.addToStrings = exports._READY = exports._DEBUG = exports.showAll = exports.setReady = exports.setDebug = exports.VOIDTABLE = exports.TIMESTAMP = exports.TEST = exports.SIMPLEQUOTEDCOMA = exports.NODE_ENV = exports.HELMET_CONFIG = exports.ESCAPE_SIMPLE_QUOTE = exports.ESCAPE_ARRAY_JSON = exports._COLUMNSEPARATOR = exports._NEWLINE = exports.DOUBLEQUOTEDCOMA = exports.DEFAULT_DB = exports.color = exports.APP_VERSION = exports.APP_NAME = exports.ADMIN = exports._WEB = exports._WAIT = exports._UNLOCK = exports._TOOLS = exports._TIME = exports._SEARCH = exports._OK = exports._NOTOK = exports._NOTIMPLEMENTED = exports._LOCK = exports._KEY = exports._FORBIDDEN = exports._DEL = void 0;
const util_1 = __importDefault(require("util"));
const helpers_1 = require("./helpers");
exports._DEL = "🗑️";
exports._FORBIDDEN = "⛔️";
exports._KEY = "🔑";
exports._LOCK = "🔏";
exports._NOTIMPLEMENTED = "🚧";
exports._NOTOK = "❌";
exports._OK = "✔️️";
exports._SEARCH = "🔎";
exports._TIME = "⏲️";
exports._TOOLS = "🛠️";
exports._UNLOCK = "🔐";
exports._WAIT = "⏳";
exports._WEB = "🌍";
exports.ADMIN = "admin";
exports.APP_NAME = process.env.npm_package_name || "_STEAN";
exports.APP_VERSION = process.env.version || process.env.npm_package_version || "0";
const color = (col) => `\x1b[${col}m`;
exports.color = color;
exports.DEFAULT_DB = "postgres";
exports.DOUBLEQUOTEDCOMA = '",\n"';
exports._NEWLINE = '\r\n';
exports._COLUMNSEPARATOR = '@|@';
const ESCAPE_ARRAY_JSON = (input) => input ? input.replace("[", "{").replace("]", "}") : undefined;
exports.ESCAPE_ARRAY_JSON = ESCAPE_ARRAY_JSON;
const ESCAPE_SIMPLE_QUOTE = (input) => input.replace(/[']+/g, "''");
exports.ESCAPE_SIMPLE_QUOTE = ESCAPE_SIMPLE_QUOTE;
exports.HELMET_CONFIG = Object.freeze({
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'", "'unsafe-inline'", "cdnjs.cloudflare.com"],
    styleSrc: [
        "'self'",
        "'unsafe-inline'",
        "cdnjs.cloudflare.com",
        "fonts.googleapis.com",
    ],
});
exports.NODE_ENV = process.env.NODE_ENV ? process.env.NODE_ENV : "production";
exports.SIMPLEQUOTEDCOMA = "',\n'";
exports.TEST = "test";
const TIMESTAMP = () => { const d = new Date(); return d.toLocaleTimeString(); };
exports.TIMESTAMP = TIMESTAMP;
exports.VOIDTABLE = "spatial_ref_sys";
function setDebug(input) { exports._DEBUG = input; }
exports.setDebug = setDebug;
function setReady(input) { exports._READY = input; }
exports.setReady = setReady;
function showAll(input, colors) { return typeof input === "object" ? util_1.default.inspect(input, { showHidden: false, depth: null, colors: colors || false, }) : input; }
exports.showAll = showAll;
exports._DEBUG = false;
exports._READY = false;
function addToStrings(input, data) { if (input)
    input.push(data);
else
    input = [data]; }
exports.addToStrings = addToStrings;
exports.APP_KEY = (0, helpers_1.getKey)();
