"use strict";
/**
 * decodingPayload for odata
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- decodingPayload for odata -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.decodingPayload = void 0;
const log_1 = require("../log");
const messages_1 = require("../messages");
const decodingPayload = (decoder, payload) => {
    console.log(log_1.log.head("decodingPayload"));
    if (decoder.name && decoder.nomenclature && decoder.code != 'undefined') {
        try {
            const F = new Function("input", "nomenclature", `${String(decoder.code)}; return decode(input, nomenclature);`);
            let nomenclature = "";
            if (decoder.nomenclature.trim() != "")
                try {
                    nomenclature = JSON.parse(JSON.parse(decoder.nomenclature));
                }
                catch (error) {
                    nomenclature = JSON.parse(decoder.nomenclature);
                }
            const result = F(payload, decoder.nomenclature === "{}" || decoder.nomenclature === "" ? null : nomenclature);
            return { decoder: decoder.name, result: result };
        }
        catch (error) {
            log_1.log.errorMsg(error);
            return {
                decoder: decoder.name,
                result: undefined,
                error: messages_1.errors.DecodingPayloadError,
            };
        }
    }
};
exports.decodingPayload = decodingPayload;
