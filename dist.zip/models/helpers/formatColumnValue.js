"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatColumnValue = void 0;
/**
 * formatColumnValue.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- formatColumnValue. -----------------------------------!");
const constants_1 = require("../../constants");
const helpers_1 = require("../../helpers");
const logger_1 = require("../../logger");
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function formatColumnValue(columnName, value, type) {
    console.log(logger_1.formatLog.whereIam(`${columnName} [${type}] ==> ${value}`));
    switch (typeof value) {
        case "object":
            return value.hasOwnProperty("@iot.name")
                ? `(SELECT "id" FROM "${columnName.split("_")[0]}" WHERE "name" = '${(0, constants_1.ESCAPE_SIMPLE_QUOTE)(value["@iot.name"])}')`
                : value.hasOwnProperty("@iot.id")
                    ? value["@iot.id"]
                    : type === 'text[]'
                        ? (0, helpers_1.addSimpleQuotes)(`{${value.map((e) => (0, helpers_1.addDoubleQuotes)((0, helpers_1.removeSimpleQuotes)(e))).join(",")}}`)
                        : `'${(0, constants_1.ESCAPE_SIMPLE_QUOTE)(JSON.stringify(value))}'`;
        default:
            if (value)
                switch (value) {
                    case void 0:
                        return '';
                    case null:
                        return 'null';
                    case value.isRawInstance:
                        return value.toQuery();
                    default:
                        switch (type) {
                            case 'number':
                                return value;
                            case 'bool':
                                if (value === 'false')
                                    value = 0;
                                return `'${value ? 1 : 0}'`;
                            case 'json':
                            case 'jsonb':
                                return (0, helpers_1.addSimpleQuotes)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(JSON.stringify(value)));
                            case 'text[]':
                                const temp = (0, constants_1.ESCAPE_ARRAY_JSON)(String(value));
                                if (temp)
                                    return (0, helpers_1.addSimpleQuotes)(temp);
                                return "ARRAY ERROR";
                            case 'result':
                                return (0, helpers_1.addSimpleQuotes)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(JSON.stringify(value)));
                            default:
                                break;
                        }
                        if (String(value).startsWith("(SELECT"))
                            return `${value}`;
                        try {
                            return value.includes("'") ? (0, helpers_1.addSimpleQuotes)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(value)) : (0, helpers_1.addSimpleQuotes)(value);
                        }
                        catch (error) {
                            return (0, helpers_1.addSimpleQuotes)(value);
                        }
                }
    }
}
exports.formatColumnValue = formatColumnValue;
