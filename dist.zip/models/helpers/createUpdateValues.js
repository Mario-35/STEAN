"use strict";
/**
 * createUpdateValues
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- createUpdateValues -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUpdateValues = void 0;
const constants_1 = require("../../constants");
const helpers_1 = require("../../helpers");
const log_1 = require("../../log");
function createUpdateValues(input) {
    console.log(log_1.log.whereIam());
    const result = [];
    Object.keys(input).forEach((e) => {
        result.push(`${(0, helpers_1.addDoubleQuotes)(e)} = ${(0, helpers_1.addSimpleQuotes)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(input[e]))}`);
    });
    return result.join();
}
exports.createUpdateValues = createUpdateValues;
;
