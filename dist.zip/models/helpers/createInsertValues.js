"use strict";
/**
 * createInsertValues
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- createInsertValues -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.createInsertValues = void 0;
const _1 = require(".");
const __1 = require("..");
const constants_1 = require("../../constants");
const helpers_1 = require("../../helpers");
const logger_1 = require("../../logger");
// create postgresSql 
function createInsertValues(config, input, entityName) {
    console.log(logger_1.formatLog.whereIam());
    if (config && input) {
        const keys = [];
        const values = [];
        if (entityName) {
            const entity = __1.models.getEntity(config, entityName);
            if (!entity)
                return "";
            Object.keys(input).forEach((e) => {
                if (input[e] && entity.columns[e]) {
                    const temp = (0, _1.formatColumnValue)(e, input[e], entity.columns[e].type);
                    if (temp) {
                        keys.push((0, helpers_1.addDoubleQuotes)(e));
                        values.push(temp);
                    }
                }
                else if (input[e] && entity.relations[e]) {
                    const col = entity.relations[e].entityColumn;
                    if (entity.columns[col]) {
                        const temp = (0, _1.formatColumnValue)(col, input[e], entity.columns[col].type);
                        if (temp) {
                            keys.push((0, helpers_1.addDoubleQuotes)(col));
                            values.push(temp);
                        }
                    }
                }
            });
        }
        else {
            Object.keys(input).forEach((e) => {
                if (input[e]) {
                    if (input[e].startsWith && input[e].startsWith('"{') && input[e].endsWith('}"'))
                        input[e] = (0, helpers_1.removeDoubleQuotes)(input[e]);
                    else if (input[e].startsWith && input[e].startsWith('{"@iot.name"'))
                        input[e] = `(SELECT "id" FROM "${e.split("_")[0]}" WHERE "name" = '${JSON.parse((0, helpers_1.removeDoubleQuotes)(input[e]))["@iot.name"]}')`;
                    keys.push((0, helpers_1.addDoubleQuotes)(e));
                    values.push(typeof input[e] === "string"
                        ? input[e].startsWith("(SELECT")
                            ? input[e]
                            : (0, helpers_1.addSimpleQuotes)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(input[e].trim()))
                        : e === "result" ? `'{"value": ${input[e]}}'::jsonb` : (0, constants_1.ESCAPE_SIMPLE_QUOTE)(input[e].trim()));
                }
            });
        }
        return `(${keys.join()}) VALUES (${values.join()})`;
    }
    return "";
}
exports.createInsertValues = createInsertValues;
;
