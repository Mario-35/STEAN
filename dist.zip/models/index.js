"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.models = void 0;
const configuration_1 = require("../configuration");
const constants_1 = require("../constants");
const log_1 = require("../log");
const helpers_1 = require("../db/helpers");
const queries_1 = require("../db/queries");
const enums_1 = require("../enums");
const helpers_2 = require("../helpers");
const messages_1 = require("../messages");
const fs_1 = __importDefault(require("fs"));
const conformance_json_1 = __importDefault(require("./conformance.json"));
const entities_1 = require("./entities");
const testVersion = (input) => Object.keys(Models.models).includes(input);
class Models {
    static models = {};
    // Create Object FOR v1.0
    constructor() {
        Models.models[enums_1.EVersion.v1_0] = {
            Things: entities_1.Thing,
            FeaturesOfInterest: entities_1.FeatureOfInterest,
            Locations: entities_1.Location,
            HistoricalLocations: entities_1.HistoricalLocation,
            locationsHistoricalLocations: entities_1.LocationHistoricalLocation,
            ObservedProperties: entities_1.ObservedProperty,
            Sensors: entities_1.Sensor,
            Datastreams: entities_1.Datastream,
            MultiDatastreams: entities_1.MultiDatastream,
            MultiDatastreamObservedProperties: entities_1.MultiDatastreamObservedProperty,
            Observations: entities_1.Observation,
            HistoricalObservations: entities_1.HistoricalObservation,
            ThingsLocations: entities_1.ThingLocation,
            Decoders: entities_1.Decoder,
            Loras: entities_1.Lora,
            Logs: entities_1.Log,
            Users: entities_1.User,
            Configs: entities_1.Config,
            CreateObservations: entities_1.CreateObservation,
            CreateFile: entities_1.CreateFile,
        };
    }
    escape(input, ignore) {
        let pattern = "";
        const map = {
            '>': '&gt;',
            '<': '&lt;',
            "'": '&apos;',
            '"': '&quot;',
            '&': '&amp;'
        };
        if (input === null || input === undefined)
            return;
        ignore = (ignore || '').replace(/[^&"<>\']/g, '');
        pattern = '([&"<>\'])'.replace(new RegExp('[' + ignore + ']', 'g'), '');
        return input.replace(new RegExp(pattern, 'g'), function (str, item) {
            return map[item];
        });
    }
    // create drawIO Model
    getDraw(ctx) {
        const deleteId = (id) => {
            const start = `<mxCell id="${id}"`;
            const end = "</mxCell>";
            fileContent = fileContent.replace(`${start}${fileContent.split(start)[1].split(end)[0]}${end}`, "");
        };
        const entities = Models.models[ctx.config.apiVersion];
        let fileContent = fs_1.default.readFileSync(__dirname + `/model.drawio`, "utf8");
        fileContent = fileContent.replace('&gt;Version&lt;', `&gt;version : ${ctx.config.apiVersion}&lt;`);
        if (!ctx.config.extensions.includes(enums_1.EExtensions.logs))
            deleteId("124");
        if (!ctx.config.extensions.includes(enums_1.EExtensions.multiDatastream)) {
            ["114", "115", "117", "118", "119", "116", "120", "121"].forEach(e => deleteId(e));
            fileContent = fileContent.replace(`&lt;hr&gt;COLUMNS.${entities.MultiDatastreams.name}`, "");
            fileContent = fileContent.replace(`&lt;hr&gt;COLUMNS.${entities.MultiDatastreams.name}`, "");
            fileContent = fileContent.replace(`&lt;strong&gt;${entities.MultiDatastreams.singular}&lt;/strong&gt;`, "");
        }
        Object.keys(entities).forEach((strEntity) => {
            fileContent = fileContent.replace(`COLUMNS.${entities[strEntity].name}`, this.getColumnListNameWithoutId(entities[strEntity]).map((colName) => `&lt;p style=&quot;margin: 0px; margin-left: 8px;&quot;&gt;${colName}: ${entities[strEntity].columns[colName].type.toUpperCase()}&lt;/p&gt;`).join(""));
        });
        return fileContent;
    }
    async getInfos(ctx) {
        const temp = configuration_1.serverConfig.getInfos(ctx, ctx.config.name);
        const result = {
            ...temp,
            ready: ctx.config.connection ? true : false,
            Postgres: {}
        };
        const extensions = {};
        switch (ctx.config.apiVersion) {
            case enums_1.EVersion.v1_1:
                result["Ogc link"] = "https://docs.ogc.org/is/18-088/18-088.html";
                break;
            default:
                result["Ogc link"] = "https://docs.ogc.org/is/15-078r6/15-078r6.html";
                break;
        }
        if (ctx.config.extensions.includes(enums_1.EExtensions.tasking))
            extensions["tasking"] = "https://docs.ogc.org/is/17-079r1/17-079r1.html";
        if (ctx.config.extensions.includes(enums_1.EExtensions.logs))
            extensions["logs"] = `${ctx.decodedUrl.linkbase}/${ctx.config.apiVersion}/Logs`;
        result["extensions"] = extensions;
        result["options"] = ctx.config.options;
        await (0, helpers_1.executeSqlValues)(ctx.config, `
    select version(), 
    (SELECT ARRAY(SELECT extname||'-'||extversion AS extension FROM pg_extension) AS extension),
    (SELECT c.relname||'.'||a.attname FROM pg_attribute a JOIN pg_class c ON (a.attrelid=c.relfilenode) WHERE a.atttypid = 114)
    ;`).then(res => {
            result["Postgres"]["version"] = res[0];
            result["Postgres"]["extensions"] = res[1];
        });
        return result;
    }
    // Get multiDatastream or Datastrems infos in one function
    async getStreamInfos(config, input) {
        const stream = input["Datastream"] ? "Datastream" : input["MultiDatastream"] ? "MultiDatastream" : undefined;
        if (!stream)
            return undefined;
        const streamEntity = exports.models.getEntityName(config, stream);
        if (!streamEntity)
            return undefined;
        const foiId = input["FeaturesOfInterest"] ? input["FeaturesOfInterest"] : undefined;
        const searchKey = input[exports.models.DBFull(config)[streamEntity].name] || input[exports.models.DBFull(config)[streamEntity].singular];
        const streamId = isNaN(searchKey) ? searchKey["@iot.id"] : searchKey;
        if (streamId) {
            const query = `SELECT "id", "observationType", "_default_foi" FROM ${(0, helpers_2.addDoubleQuotes)(exports.models.DBFull(config)[streamEntity].table)} WHERE id = ${BigInt(streamId)} LIMIT 1`;
            return (0, helpers_1.executeSqlValues)(config, (0, queries_1.asJson)({ query: query, singular: true, strip: false, count: false }))
                .then((res) => {
                return res ? {
                    type: stream,
                    id: res[0]["id"],
                    observationType: res[0]["observationType"],
                    FoId: foiId ? foiId : res[0]["_default_foi"],
                } : undefined;
            })
                .catch((error) => {
                log_1.log.errorMsg(error);
                return undefined;
            });
        }
    }
    version1_1(input) {
        const makeJson = (name) => {
            return {
                create: "jsonb NULL",
                alias() {
                    return `"${name}"`;
                },
                type: "json"
            };
        };
        ["Things", "Locations", "FeaturesOfInterest", "ObservedProperties", "Sensors", "Datastreams", "MultiDatastreams"]
            .forEach((e) => { input[e].columns["properties"] = makeJson("properties"); });
        input.Locations.columns["geom"] = {
            create: "geometry NULL",
            alias() {
                return `"geom"`;
            },
            type: "json",
        };
        return input;
    }
    isVersionExist(nb) {
        if (testVersion(nb) === true)
            return true;
        if (this.createVersion(nb) === true)
            return true;
        throw new Error((0, messages_1.msg)(messages_1.errors.wrongVersion, nb));
    }
    createVersion(nb) {
        switch (nb) {
            case "1.1":
            case "v1.1":
            case enums_1.EVersion.v1_1:
                Models.models[enums_1.EVersion.v1_1] = this.version1_1((0, helpers_2.deepClone)(Models.models[enums_1.EVersion.v1_0]));
        }
        return testVersion(nb);
    }
    filtering(config) {
        return Object.fromEntries(Object.entries(Models.models[config.apiVersion]).filter(([, v]) => Object.keys((0, enums_1.filterEntities)(config.extensions)).includes(v.name)));
    }
    version(config) {
        if (config && config.apiVersion && testVersion(config.apiVersion))
            return config.apiVersion;
        throw new Error((0, messages_1.msg)(messages_1.errors.wrongVersion, config.apiVersion));
    }
    filteredModelFromConfig(config) {
        if (testVersion(config.apiVersion) === false)
            this.createVersion(config.apiVersion);
        return config.name === constants_1.ADMIN ? this.DBAdmin(config) : this.filtering(config);
    }
    DBFull(config) {
        if (typeof config === "string") {
            const nameConfig = configuration_1.serverConfig.getConfigNameFromName(config);
            if (!nameConfig)
                throw new Error(messages_1.errors.configName);
            if (testVersion(configuration_1.serverConfig.getConfig(nameConfig).apiVersion) === false)
                this.createVersion(configuration_1.serverConfig.getConfig(nameConfig).apiVersion);
            config = configuration_1.serverConfig.getConfig(nameConfig);
        }
        return Models.models[config.apiVersion];
    }
    DBAdmin(config) {
        const entities = Models.models[enums_1.EVersion.v1_0];
        return Object.fromEntries(Object.entries(entities));
        // return Object.fromEntries(Object.entries( Models.models[EVersion.v1_0]));
    }
    isSingular(config, input) {
        if (config && input) {
            const entityName = this.getEntityName(config, input);
            return entityName ? Models.models[config.apiVersion][entityName].singular == input : false;
        }
        return false;
    }
    getEntityName(config, search) {
        if (config && search) {
            const tempModel = Models.models[config.apiVersion];
            const testString = search
                .trim()
                .match(/[a-zA-Z_]/g)
                ?.join("");
            return tempModel && testString
                ? tempModel.hasOwnProperty(testString)
                    ? testString
                    : Object.keys(tempModel).filter((elem) => tempModel[elem].table == testString.toLowerCase() ||
                        tempModel[elem].singular == testString)[0]
                : undefined;
        }
    }
    getEntity = (config, entity) => {
        if (config && entity) {
            if (typeof entity === "string") {
                const entityName = this.getEntityName(config, entity.trim());
                if (!entityName)
                    return;
                entity = entityName;
            }
            return (typeof entity === "string") ? Models.models[config.apiVersion][entity] : Models.models[config.apiVersion][entity.name];
        }
    };
    getRelationColumnTable = (config, entity, test) => {
        if (config && entity) {
            const tempEntity = this.getEntity(config, entity);
            if (tempEntity)
                return tempEntity.relations.hasOwnProperty(test)
                    ? enums_1.EColumnType.Relation
                    : tempEntity.columns.hasOwnProperty(test)
                        ? enums_1.EColumnType.Column
                        : undefined;
        }
    };
    getSelectColumnList(input) {
        return Object.keys(input.columns).filter((word) => !word.includes("_")).map((e) => `${(0, helpers_2.addDoubleQuotes)(input.table)}.${(0, helpers_2.addDoubleQuotes)(e)}`);
    }
    getColumnListNameWithoutId(input) {
        return Object.keys(input.columns).filter((word) => !word.includes("_") && !word.includes("id"));
    }
    isColumnType(config, entity, column, test) {
        if (config && entity) {
            const tempEntity = this.getEntity(config, entity);
            return tempEntity && tempEntity.columns[column] ? (tempEntity.columns[column].type.toLowerCase() === test.toLowerCase()) : false;
        }
        return false;
    }
    getRoot(ctx) {
        console.log(log_1.log.whereIam());
        let expectedResponse = [];
        Object.keys(ctx.model)
            .filter((elem) => ctx.model[elem].order > 0)
            .sort((a, b) => (ctx.model[a].order > ctx.model[b].order ? 1 : -1))
            .forEach((value) => {
            expectedResponse.push({
                name: ctx.model[value].name,
                url: `${ctx.decodedUrl.linkbase}/${ctx.config.apiVersion}/${value}`,
            });
        });
        switch (ctx.config.apiVersion) {
            case enums_1.EVersion.v1_0:
                return {
                    value: expectedResponse.filter((elem) => Object.keys(elem).length)
                };
            case enums_1.EVersion.v1_1:
                expectedResponse = expectedResponse.filter((elem) => Object.keys(elem).length);
                const list = [];
                list.push(conformance_json_1.default["1.1"].root);
                list.push("https://docs.ogc.org/is/18-088/18-088.html#uri-components");
                list.push("https://docs.ogc.org/is/18-088/18-088.html#resource-path");
                list.push("https://docs.ogc.org/is/18-088/18-088.html#requesting-data");
                list.push("https://docs.ogc.org/is/18-088/18-088.html#create-update-delete");
                // conformance.push("https://docs.ogc.org/is/18-088/18-088.html#batch-requests");
                if (ctx.config.extensions.includes(enums_1.EExtensions.multiDatastream))
                    list.push("https://docs.ogc.org/is/18-088/18-088.html#multidatastream-extension");
                if (ctx.config.extensions.includes(enums_1.EExtensions.mqtt))
                    list.push("https://docs.ogc.org/is/18-088/18-088.html#create-observation-dataarray");
                // conformance.push("https://docs.ogc.org/is/18-088/18-088.html#mqtt-extension");
                list.push("http://docs.oasis-open.org/odata/odata-json-format/v4.01/odata-json-format-v4.01.html");
                list.push("https://datatracker.ietf.org/doc/html/rfc4180");
                return {
                    value: expectedResponse.filter((elem) => Object.keys(elem).length),
                    serverSettings: { "conformance": list }
                };
            default:
                break;
        }
    }
    init() {
        if ((0, helpers_2.isTest)()) {
            this.createVersion(configuration_1.serverConfig.getConfig(constants_1.TEST).apiVersion);
        }
    }
}
exports.models = new Models();
