"use strict";
/**
 * entity HistoricalLocation
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- entity HistoricalLocation -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.HistoricalLocation = void 0;
const _1 = require(".");
const enums_1 = require("../../enums");
const constants_1 = require("./constants");
const helpers_1 = require("../../helpers");
const constants_2 = require("../../db/constants");
exports.HistoricalLocation = (0, _1.createEntity)("HistoricalLocations", {
    createOrder: -1,
    order: 5,
    orderBy: `"id"`,
    columns: {
        id: {
            create: constants_1._idBig,
            alias(config, test) {
                return `"id"${test["alias"] && test["alias"] === true === true ? ` AS ${(0, helpers_1.addDoubleQuotes)(constants_2._ID)}` : ''}`;
            },
            type: "bigint"
        },
        time: {
            create: constants_1._tz,
            alias() { },
            type: "date"
        },
        thing_id: {
            create: constants_1._idRel,
            alias() { },
            type: "bigint"
        },
    },
    constraints: {
        historicallocation_pkey: 'PRIMARY KEY ("id")',
        historicallocation_thing_id_fkey: 'FOREIGN KEY ("thing_id") REFERENCES "thing"("id") ON UPDATE CASCADE ON DELETE CASCADE',
    },
    indexes: {
        historicallocation_thing_id: 'ON public."historicallocation" USING btree ("thing_id")',
    },
    relations: {
        Things: {
            type: enums_1.EnumRelations.belongsTo,
            expand: `"thing"."id" = "historicallocation"."thing_id"`,
            link: `"thing"."id" = (SELECT "historicallocation"."thing_id" from "historicallocation" WHERE "historicallocation"."id" = $ID)`,
            entityName: "Things",
            tableName: "thing",
            relationKey: "thing_id",
            entityColumn: "id",
            tableKey: "id",
        },
        Locations: {
            type: enums_1.EnumRelations.belongsToMany,
            expand: `"location"."id" in (SELECT "location"."id" from "location" WHERE "location"."id" in (SELECT "thinglocation"."location_id" from "thinglocation" WHERE "thinglocation"."thing_id" = "historicallocation"."thing_id"))`,
            link: `"location"."id" in (SELECT "location"."id" from "location" WHERE "location"."id" in (SELECT "thinglocation"."location_id" from "thinglocation" WHERE "thinglocation"."thing_id" in (SELECT "historicallocation"."thing_id" from "historicallocation" WHERE "historicallocation"."id" = $ID)))`,
            entityName: "locationsHistoricalLocations",
            tableName: "locationhistoricallocation",
            relationKey: "historicallocation_id",
            entityColumn: "location_id",
            tableKey: "location_id",
        },
    },
});
