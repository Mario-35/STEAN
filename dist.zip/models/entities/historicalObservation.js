"use strict";
/**
 * entity HistoricalObservation.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- entity HistoricalObservation -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.HistoricalObservation = void 0;
const _1 = require(".");
const enums_1 = require("../../enums");
const constants_1 = require("./constants");
const helpers_1 = require("../../helpers");
const constants_2 = require("../../db/constants");
exports.HistoricalObservation = (0, _1.createEntity)("HistoricalObservations", {
    createOrder: -1,
    order: -1,
    orderBy: `"id"`,
    columns: {
        id: {
            create: constants_1._idBig,
            alias(config, test) {
                return `"id"${test["alias"] && test["alias"] === true === true ? ` AS ${(0, helpers_1.addDoubleQuotes)(constants_2._ID)}` : ''}`;
            },
            type: "bigint"
        },
        validTime: {
            create: "timestamptz DEFAULT CURRENT_TIMESTAMP",
            alias() { },
            type: "date"
        },
        _result: {
            create: "JSONB NULL",
            alias() { },
            type: "json"
        },
        observation_id: {
            create: "BIGINT NULL",
            alias() { },
            type: "bigint"
        },
    },
    constraints: {
        HistoricalObservations_pkey: 'PRIMARY KEY ("id")',
        HistoricalObservations_id_fkey: 'FOREIGN KEY ("observation_id") REFERENCES "observation"("id") ON UPDATE CASCADE ON DELETE CASCADE',
    },
    indexes: {
        HistoricalObservations_observation_id: 'ON public."historicalobservation" USING btree ("observation_id")',
    },
    relations: {
        Observations: {
            type: enums_1.ERelations.belongsTo,
            expand: `"observation"."id" = "historicalobservation"."observation_id"`,
            link: "err: 501 : Not Implemented.",
            entityName: "Observations",
            tableName: "observation",
            relationKey: "observation_id",
            entityColumn: "id",
            tableKey: "id",
        },
    },
});
