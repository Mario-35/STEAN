"use strict";
/**
 * entity User.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- entity User -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.User = void 0;
const _1 = require(".");
const constants_1 = require("./constants");
exports.User = (0, _1.createEntity)("Users", {
    createOrder: -1,
    order: 21,
    orderBy: `"name"`,
    columns: {
        id: {
            create: constants_1._idBig,
            alias() { },
            type: "bigint"
        },
        username: {
            create: "text NOT NULL UNIQUE",
            alias() { },
            type: "string"
        },
        email: {
            create: (0, constants_1._text)(),
            alias() { },
            type: "string"
        },
        password: {
            create: (0, constants_1._text)(),
            alias() { },
            type: "string"
        },
        database: {
            create: (0, constants_1._text)(),
            alias() { },
            type: "string"
        },
        canPost: {
            create: "bool NULL",
            alias() { },
            type: "boolean"
        },
        canDelete: {
            create: "bool NULL",
            alias() { },
            type: "boolean"
        },
        canCreateUser: {
            create: "bool NULL",
            alias() { },
            type: "boolean"
        },
        canCreateDb: {
            create: "bool NULL",
            alias() { },
            type: "boolean"
        },
        admin: {
            create: "bool NULL",
            alias() { },
            type: "boolean"
        },
        superAdmin: {
            create: "bool NULL",
            alias() { },
            type: "boolean"
        },
    },
    relations: {},
});
