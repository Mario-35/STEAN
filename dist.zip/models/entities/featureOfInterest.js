"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FeatureOfInterest = void 0;
/**
 * entity FeatureOfInterest.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- entity FeatureOfInterest. -----------------------------------!");
const _1 = require(".");
const enums_1 = require("../../enums");
const constants_1 = require("./constants");
const helpers_1 = require("../../helpers");
const constants_2 = require("../../db/constants");
exports.FeatureOfInterest = (0, _1.createEntity)("FeaturesOfInterest", {
    createOrder: 4,
    order: 4,
    orderBy: `"id"`,
    columns: {
        id: {
            create: constants_1._idBig,
            alias(config, test) {
                return `"id"${test["alias"] && test["alias"] === true === true ? ` AS ${(0, helpers_1.addDoubleQuotes)(constants_2._ID)}` : ''}`;
            },
            type: "number",
        },
        name: {
            create: (0, constants_1._text)('no name'),
            alias() { },
            type: "text",
        },
        description: {
            create: (0, constants_1._text)('no description'),
            alias() { },
            type: "text",
        },
        encodingType: {
            create: (0, constants_1._text)(),
            alias() { },
            type: "text",
        },
        feature: {
            create: "jsonb NOT NULL",
            alias() { },
            type: "json",
            test: "encodingType",
        }
    },
    relations: {
        Observations: {
            type: enums_1.ERelations.hasMany,
            expand: `"observation"."id" in (SELECT "observation"."id" from "observation" WHERE "observation"."featureofinterest_id" = "featureofinterest"."id")`,
            link: `"observation"."id" in (SELECT "observation"."id" from "observation" WHERE "observation"."featureofinterest_id" = $ID)`,
            entityName: "Observations",
            tableName: "observation",
            relationKey: "featureofinterest_id",
            entityColumn: "id",
            tableKey: "id",
        },
        Datastreams: {
            type: enums_1.ERelations.hasMany,
            expand: `"datastream"."id" in (SELECT "datastream"."id" from "datastream" WHERE "datastream"."_default_foi" = "featureofinterest"."id")`,
            link: `"datastream"."id" in (SELECT "datastream"."id" from "datastream" WHERE "datastream"."_default_foi" = $ID)`,
            entityName: "Datastreams",
            tableName: "datastream",
            relationKey: "_default_foi",
            entityColumn: "id",
            tableKey: "id",
        },
    },
    constraints: {
        featureofinterest_pkey: 'PRIMARY KEY ("id")',
        featureofinterest_unik_name: 'UNIQUE ("name")',
    },
    after: "INSERT INTO featureofinterest (name, description, \"encodingType\", feature) VALUES ('Default Feature of Interest', 'Default Feature of Interest', 'application/vnd.geo+json', '{}');",
});
