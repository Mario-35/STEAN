"use strict";
/**
 * entity Log
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- entity Log -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.Log = void 0;
const _1 = require(".");
const constants_1 = require("./constants");
const helpers_1 = require("../../helpers");
const constants_2 = require("../../db/constants");
exports.Log = (0, _1.createEntity)("Logs", {
    createOrder: -1,
    order: -1,
    orderBy: `"date DESC"`,
    columns: {
        id: {
            create: constants_1._idBig,
            alias(config, test) {
                return `"id"${test["alias"] && test["alias"] === true === true ? ` AS ${(0, helpers_1.addDoubleQuotes)(constants_2._ID)}` : ''}`;
            },
            type: "number",
        },
        date: {
            create: "timestamptz DEFAULT CURRENT_TIMESTAMP",
            alias() { },
            type: "date",
        },
        user_id: {
            create: "BIGINT NULL",
            alias() { },
            type: "number",
        },
        method: {
            create: "TEXT NULL",
            alias() { },
            type: "text",
        },
        code: {
            create: "INT NULL",
            alias() { },
            type: "number",
        },
        url: {
            create: (0, constants_1._text)(),
            alias() { },
            type: "text",
        },
        datas: {
            create: "JSONB NULL",
            alias() { },
            type: "json",
        },
        database: {
            create: "TEXT NULL",
            alias() { },
            type: "text",
        },
        returnid: {
            create: "TEXT NULL",
            alias() { },
            type: "text",
        },
        error: {
            create: "JSONB NULL",
            alias() { },
            type: "json",
        },
    },
    relations: {},
});
