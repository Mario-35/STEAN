"use strict";
/**
 * entity Datastream
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- entity Datastream -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.Datastream = void 0;
const _1 = require(".");
const enums_1 = require("../../enums");
const constants_1 = require("./constants");
const helpers_1 = require("../../helpers");
const constants_2 = require("../../db/constants");
exports.Datastream = (0, _1.createEntity)("Datastreams", {
    createOrder: 7,
    order: 1,
    orderBy: `"id"`,
    columns: {
        id: {
            create: constants_1._idBig,
            alias(config, test) {
                return `"id"${test["alias"] && test["alias"] === true === true ? ` AS ${(0, helpers_1.addDoubleQuotes)(constants_2._ID)}` : ''}`;
            },
            type: "number",
        },
        name: {
            create: (0, constants_1._text)('no name'),
            alias() { },
            type: "text",
        },
        description: {
            create: (0, constants_1._text)('no description'),
            alias() { },
            type: "text",
        },
        observationType: {
            create: (0, constants_1._text)('http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement'),
            alias() { },
            type: "list",
            verify: {
                list: Object.keys(enums_1.EObservationType),
                default: "http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement",
            },
        },
        unitOfMeasurement: {
            create: "jsonb NOT NULL",
            alias() { },
            type: "json",
        },
        observedArea: {
            create: "geometry NULL",
            alias() { },
            type: "json",
        },
        phenomenonTime: {
            create: "",
            alias(config, test) {
                return `CONCAT(to_char("_phenomenonTimeStart",'${enums_1.EDatesType.date}'),'/',to_char("_phenomenonTimeEnd",'${enums_1.EDatesType.date}')) AS "phenomenonTime"`;
            },
            type: "text",
        },
        resultTime: {
            create: "",
            alias(config, test) {
                return `CONCAT(to_char("_resultTimeStart",'${enums_1.EDatesType.date}'),'/',to_char("_resultTimeEnd",'${enums_1.EDatesType.date}')) AS "resultTime"`;
            },
            type: "text",
        },
        _phenomenonTimeStart: {
            create: constants_1._tz,
            alias() { },
            type: "date",
        },
        _phenomenonTimeEnd: {
            create: constants_1._tz,
            alias() { },
            type: "date",
        },
        _resultTimeStart: {
            create: constants_1._tz,
            alias() { },
            type: "date",
        },
        _resultTimeEnd: {
            create: constants_1._tz,
            alias() { },
            type: "date",
        },
        thing_id: {
            create: constants_1._idRel,
            alias() { },
            type: "relation:Things",
        },
        observedproperty_id: {
            create: constants_1._idRel,
            alias() { },
            type: "relation:ObservedProperties",
        },
        sensor_id: {
            create: constants_1._idRel,
            alias() { },
            type: "relation:Sensor",
        },
        _default_foi: {
            create: "BIGINT NOT NULL DEFAULT 1",
            alias() { },
            type: "relation:FeaturesOfInterest",
        },
    },
    relations: {
        Thing: {
            type: enums_1.ERelations.belongsTo,
            expand: `"thing"."id" = "datastream"."thing_id"`,
            link: `"thing"."id" = (SELECT "datastream"."thing_id" from "datastream" WHERE "datastream"."id" =$ID)`,
            entityName: "Things",
            tableName: "datastream",
            relationKey: "id",
            entityColumn: "thing_id",
            tableKey: "id",
        },
        Sensor: {
            type: enums_1.ERelations.belongsTo,
            expand: `"sensor"."id" = "datastream"."sensor_id"`,
            link: `"sensor"."id" = (SELECT "datastream"."sensor_id" from "datastream" WHERE "datastream"."id" =$ID)`,
            entityName: "Sensors",
            tableName: "datastream",
            relationKey: "id",
            entityColumn: "sensor_id",
            tableKey: "id",
        },
        ObservedProperty: {
            type: enums_1.ERelations.belongsTo,
            expand: `"observedproperty"."id" = "datastream"."observedproperty_id"`,
            link: `"observedproperty"."id" = (SELECT "datastream"."observedproperty_id" from "datastream" WHERE "datastream"."id" =$ID)`,
            entityName: "ObservedProperties",
            tableName: "datastream",
            relationKey: "id",
            entityColumn: "observedproperty_id",
            tableKey: "id",
        },
        Observations: {
            type: enums_1.ERelations.hasMany,
            expand: `"observation"."id" in (SELECT "observation"."id" from "observation" WHERE "observation"."datastream_id" = "datastream"."id" ORDER BY "observation"."resultTime" ASC)`,
            link: `"observation"."id" in (SELECT "observation"."id" from "observation" WHERE "observation"."datastream_id" = $ID ORDER BY "observation"."resultTime" ASC)`,
            entityName: "Observations",
            tableName: "observation",
            relationKey: "datastream_id",
            entityColumn: "id",
            tableKey: "id",
        },
        Lora: {
            type: enums_1.ERelations.belongsTo,
            expand: `"lora"."id" = (SELECT "lora"."id" from "lora" WHERE "lora"."datastream_id" = "datastream"."id")`,
            link: `"lora"."id" = (SELECT "lora"."id" from "lora" WHERE "lora"."datastream_id" = $ID)`,
            entityName: "Loras",
            tableName: "lora",
            relationKey: "datastream_id",
            entityColumn: "id",
            tableKey: "id",
        },
        FeatureOfInterest: {
            type: enums_1.ERelations.belongsTo,
            expand: "",
            link: "",
            entityName: "FeaturesOfInterest",
            tableName: "featureofinterest",
            relationKey: "_default_foi",
            entityColumn: "id",
            tableKey: "id",
        },
    },
    constraints: {
        datastream_pkey: 'PRIMARY KEY ("id")',
        datastream_unik_name: 'UNIQUE ("name")',
        datastream_observedproperty_id_fkey: 'FOREIGN KEY ("observedproperty_id") REFERENCES "observedproperty"("id") ON UPDATE CASCADE ON DELETE CASCADE',
        datastream_sensor_id_fkey: 'FOREIGN KEY ("sensor_id") REFERENCES "sensor"("id") ON UPDATE CASCADE ON DELETE CASCADE',
        datastream_thing_id_fkey: 'FOREIGN KEY ("thing_id") REFERENCES "thing"("id") ON UPDATE CASCADE ON DELETE CASCADE',
        datastream_featureofinterest_id_fkey: 'FOREIGN KEY ("_default_foi") REFERENCES "featureofinterest"("id") ON UPDATE CASCADE ON DELETE CASCADE',
    },
    indexes: {
        datastream_observedproperty_id: 'ON public."datastream" USING btree ("observedproperty_id")',
        datastream_sensor_id: 'ON public."datastream" USING btree ("sensor_id")',
        datastream_thing_id: 'ON public."datastream" USING btree ("thing_id")',
    },
});
