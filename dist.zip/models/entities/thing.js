"use strict";
/**
 * entity Thing
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- entity Thing -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.Thing = void 0;
const _1 = require(".");
const enums_1 = require("../../enums");
const constants_1 = require("./constants");
const helpers_1 = require("../../helpers");
const constants_2 = require("../../db/constants");
exports.Thing = (0, _1.createEntity)("Things", {
    createOrder: 1,
    order: 10,
    orderBy: `"id"`,
    columns: {
        id: {
            create: constants_1._idBig,
            alias(config, test) {
                return `"id"${test["alias"] && test["alias"] === true === true ? ` AS ${(0, helpers_1.addDoubleQuotes)(constants_2._ID)}` : ''}`;
            },
            type: "number",
        },
        name: {
            create: (0, constants_1._text)('no name'),
            alias() { },
            type: "text",
        },
        description: {
            create: (0, constants_1._text)('no description'),
            alias() { },
            type: "text",
        }
    },
    constraints: {
        thing_pkey: 'PRIMARY KEY ("id")',
        thing_unik_name: 'UNIQUE ("name")',
    },
    relations: {
        Locations: {
            type: enums_1.ERelations.belongsToMany,
            expand: `"location"."id" in (SELECT "thinglocation"."location_id" from "thinglocation" WHERE "thinglocation"."thing_id" = "thing"."id")`,
            link: `"location"."id" in (SELECT "thinglocation"."location_id" from "thinglocation" WHERE "thinglocation"."thing_id" = $ID)`,
            entityName: "Locations",
            tableName: "thinglocation",
            relationKey: "location_id",
            entityColumn: "thing_id",
            tableKey: "thing_id",
        },
        HistoricalLocations: {
            type: enums_1.ERelations.hasMany,
            expand: `"historicallocation"."id" in (SELECT "historicallocation"."id" from "historicallocation" WHERE "historicallocation"."thing_id" = "thing"."id")`,
            link: `"historicallocation"."id" in (SELECT "historicallocation"."id" from "historicallocation" WHERE "historicallocation"."thing_id" = $ID)`,
            entityName: "HistoricalLocations",
            tableName: "historicalLocation",
            relationKey: "thing_id",
            entityColumn: "id",
            tableKey: "id",
        },
        Datastreams: {
            type: enums_1.ERelations.hasMany,
            expand: `"datastream"."id" in (SELECT "datastream"."id" from "datastream" WHERE "datastream"."thing_id" = "thing"."id")`,
            link: `"datastream"."id" in (SELECT "datastream"."id" from "datastream" WHERE "datastream"."thing_id" = $ID)`,
            entityName: "Datastreams",
            tableName: "datastream",
            relationKey: "thing_id",
            entityColumn: "id",
            tableKey: "id",
        },
        MultiDatastreams: {
            type: enums_1.ERelations.hasMany,
            expand: `"multidatastream"."id" in (SELECT "multidatastream"."id" from "multidatastream" WHERE "multidatastream"."thing_id" = "thing"."id")`,
            link: `"multidatastream"."id" in (SELECT "multidatastream"."id" from "multidatastream" WHERE "multidatastream"."thing_id" = $ID)`,
            entityName: "MultiDatastreams",
            tableName: "multidatastream",
            relationKey: "thing_id",
            entityColumn: "id",
            tableKey: "id",
        },
    },
});
