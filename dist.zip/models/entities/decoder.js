"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Decoder = void 0;
/**
 * entity Decoder.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- entity Decoder. -----------------------------------!");
const _1 = require(".");
const enums_1 = require("../../enums");
const constants_1 = require("./constants");
const helpers_1 = require("../../helpers");
const constants_2 = require("../../db/constants");
exports.Decoder = (0, _1.createEntity)("Decoders", {
    createOrder: 10,
    order: 12,
    orderBy: `"id"`,
    columns: {
        id: {
            create: constants_1._idBig,
            alias(config, test) {
                return `"id"${test["alias"] && test["alias"] === true === true ? ` AS ${(0, helpers_1.addDoubleQuotes)(constants_2._ID)}` : ''}`;
            },
            type: "number",
        },
        name: {
            create: (0, constants_1._text)('no name'),
            alias() { },
            type: "text",
        },
        hash: {
            create: "TEXT NULL",
            alias() { },
            type: "text",
        },
        code: {
            create: (0, constants_1._text)('const decoded = null; return decoded;'),
            alias() { },
            type: "text",
        },
        nomenclature: {
            create: (0, constants_1._text)('{}'),
            alias() { },
            type: "jsonb",
        },
        synonym: {
            create: "TEXT NULL",
            alias() { },
            type: "jsonb",
        },
    },
    constraints: {
        decoder_pkey: 'PRIMARY KEY ("id")',
        decoder_unik_name: 'UNIQUE ("name")',
    },
    relations: {
        Loras: {
            type: enums_1.ERelations.hasMany,
            expand: `"lora"."id" in (SELECT "lora"."id" from "lora" WHERE "lora"."decoder_id" = "decoder"."id")`,
            link: `"lora"."id" in (SELECT "lora"."id" from "lora" WHERE "lora"."decoder_id" = $ID)`,
            entityName: "Loras",
            tableName: "lora",
            relationKey: "decoder_id",
            entityColumn: "id",
            tableKey: "id",
        },
    },
});
