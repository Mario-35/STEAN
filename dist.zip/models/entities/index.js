"use strict";
/**
 * Index Entity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- Index Entity -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports.User = exports.ThingLocation = exports.Thing = exports.Sensor = exports.ObservedProperty = exports.Observation = exports.MultiDatastreamObservedProperty = exports.MultiDatastream = exports.Lora = exports.Log = exports.LocationHistoricalLocation = exports.Location = exports.HistoricalObservation = exports.HistoricalLocation = exports.FeatureOfInterest = exports.Decoder = exports.Datastream = exports.CreateObservation = exports.CreateFile = exports.Config = exports.createEntity = void 0;
const enums_1 = require("../../enums");
const messages_1 = require("../../messages");
const singular = (input) => {
    if (input.endsWith("ies"))
        input = input.slice(0, -3) + "y";
    if (input.endsWith("s"))
        input = input.slice(0, -1);
    return input.split("").map((e, i) => {
        if (!(e === "s" && /^[A-Z]*$/.test(input[i + 1])))
            return e;
    }).join("").trim();
};
const createEntity = (name, datas) => {
    const entity = enums_1.allEntities[name];
    if (entity) {
        const t = singular(entity);
        return (typeof datas !== "number") ? {
            name: name,
            singular: t,
            table: t.toLowerCase(),
            ...datas
        } : {
            name: name,
            singular: t,
            table: "",
            createOrder: 99,
            order: datas,
            orderBy: "",
            columns: {},
            relations: {},
            constraints: {},
            indexes: {},
        };
    }
    throw new Error((0, messages_1.msg)(messages_1.errors.noValidEntity, name));
};
exports.createEntity = createEntity;
exports.Config = (0, exports.createEntity)("Configs", 98);
exports.CreateFile = (0, exports.createEntity)("CreateFile", 0);
exports.CreateObservation = (0, exports.createEntity)("CreateObservations", 0);
var datastream_1 = require("./datastream");
Object.defineProperty(exports, "Datastream", { enumerable: true, get: function () { return datastream_1.Datastream; } });
var decoder_1 = require("./decoder");
Object.defineProperty(exports, "Decoder", { enumerable: true, get: function () { return decoder_1.Decoder; } });
var featureOfInterest_1 = require("./featureOfInterest");
Object.defineProperty(exports, "FeatureOfInterest", { enumerable: true, get: function () { return featureOfInterest_1.FeatureOfInterest; } });
var historicalLocation_1 = require("./historicalLocation");
Object.defineProperty(exports, "HistoricalLocation", { enumerable: true, get: function () { return historicalLocation_1.HistoricalLocation; } });
var historicalObservation_1 = require("./historicalObservation");
Object.defineProperty(exports, "HistoricalObservation", { enumerable: true, get: function () { return historicalObservation_1.HistoricalObservation; } });
var location_1 = require("./location");
Object.defineProperty(exports, "Location", { enumerable: true, get: function () { return location_1.Location; } });
var locationHistoricalLocation_1 = require("./locationHistoricalLocation");
Object.defineProperty(exports, "LocationHistoricalLocation", { enumerable: true, get: function () { return locationHistoricalLocation_1.LocationHistoricalLocation; } });
var log_1 = require("./log");
Object.defineProperty(exports, "Log", { enumerable: true, get: function () { return log_1.Log; } });
var lora_1 = require("./lora");
Object.defineProperty(exports, "Lora", { enumerable: true, get: function () { return lora_1.Lora; } });
var multiDatastream_1 = require("./multiDatastream");
Object.defineProperty(exports, "MultiDatastream", { enumerable: true, get: function () { return multiDatastream_1.MultiDatastream; } });
var multiDatastreamObservedProperty_1 = require("./multiDatastreamObservedProperty");
Object.defineProperty(exports, "MultiDatastreamObservedProperty", { enumerable: true, get: function () { return multiDatastreamObservedProperty_1.MultiDatastreamObservedProperty; } });
var observation_1 = require("./observation");
Object.defineProperty(exports, "Observation", { enumerable: true, get: function () { return observation_1.Observation; } });
var observedProperty_1 = require("./observedProperty");
Object.defineProperty(exports, "ObservedProperty", { enumerable: true, get: function () { return observedProperty_1.ObservedProperty; } });
var sensor_1 = require("./sensor");
Object.defineProperty(exports, "Sensor", { enumerable: true, get: function () { return sensor_1.Sensor; } });
var thing_1 = require("./thing");
Object.defineProperty(exports, "Thing", { enumerable: true, get: function () { return thing_1.Thing; } });
var thingLocation_1 = require("./thingLocation");
Object.defineProperty(exports, "ThingLocation", { enumerable: true, get: function () { return thingLocation_1.ThingLocation; } });
var user_1 = require("./user");
Object.defineProperty(exports, "User", { enumerable: true, get: function () { return user_1.User; } });
