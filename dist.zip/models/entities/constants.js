"use strict";
/**
 * entity Thing
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
// onsole.log("!----------------------------------- entity Thing -----------------------------------!");
Object.defineProperty(exports, "__esModule", { value: true });
exports._text = exports._tz = exports._idRel = exports._idBig = void 0;
exports._idBig = "BIGINT GENERATED ALWAYS AS IDENTITY";
exports._idRel = "BIGINT NOT NULL";
exports._tz = "TIMESTAMPTZ NULL";
function _text(def) { return `TEXT NOT NULL${def ? ` DEFAULT '${def}'::TEXT` : ''}`; }
exports._text = _text;
;
